//
//  PatientDashboardVC.swift
//  RemainderApp
//
//  Created by SAIL on 08/03/24.
//

import UIKit
import UserNotifications

class PatientDashboardVC: BasicViewController,SideMenuPatientTap {
    
    
    let hospitalId = UserDefaultsManager.shared.gethospitalId() ?? ""
    var notificationData: [NotificationData] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        notificationApi()
    }
    
    @IBAction func physioButton(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "PhysiotherephyVC") as! PhysiotherephyVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func positionsButton(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "PositionsVC") as! PositionsVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func bedSoresButton(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "BedSoresVC") as! BedSoresVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func feedsButton(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "FeedsVC") as! FeedsVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func foleysAndRylesButton(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "FoleysPatientVC") as! FoleysPatientVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func backButton(_ sender: Any) {
        guard let sideMenuController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SideMenuPatientVC") as? SideMenuPatientVC else {
            return
        }
        sideMenuController.delegate = self
        sideMenuController.modalPresentationStyle = .overFullScreen
        self.present(sideMenuController, animated: false, completion: nil)
    }
    func sendVc(int: Int) {
        switch int {
        case 1:
            navigateToMyProfile()
        case 2:
            navigateToLogout()
        default:
            break
        }
    }
    private func navigateToMyProfile() {
        let profileVC = self.storyboard?.instantiateViewController(withIdentifier: "PatientProfileVC") as! PatientProfileVC
        navigationController?.pushViewController(profileVC, animated: true)
    }
    private func navigateToLogout() {
        let alert = UIAlertController(title: "Logout", message: "Are you sure you want to logout?", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        alert.addAction(UIAlertAction(title: "Logout", style: .destructive, handler: { _ in
            self.performLogout()
        }))
        DispatchQueue.main.async {
            self.present(alert, animated: true, completion: nil)
        }
    }
    private func performLogout() {
        // Clear user session or perform any other logout actions here
        // For example, navigate to the login screen
        if let loginVC = self.storyboard?.instantiateViewController(withIdentifier: "ViewController") {
            if let navigationController = self.navigationController {
                navigationController.setViewControllers([loginVC], animated: true)
            }
        }
    }
    func notificationApi() {
        startIndicator()
        let apiURL = ApiList.NotificationURL
        let formData = ["hospital_id": UserDefaultsManager.shared.gethospitalId() ?? ""]
        
        APIHandler().postAPIValues(type: NotificationModel.self, apiUrl: apiURL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async {
                    self.notificationData = data.data
                    NotificationManager.scheduleNotifications(for: data.data)
                    self.stopIndicator()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    self.stopIndicator()
                    self.showAlert(title: "Failure", message: "Something Went Wrong", okActionHandler: {})
                }
            }
            
        }
    }
}

class NotificationManager {
   static func scheduleNotifications(for data: [NotificationData]) {
       for notificationData in data {
           scheduleNotification(title: "Reminder", body: notificationData.message, timeString: notificationData.timing, identifier: notificationData.id)
       }
   }
   
   private static func scheduleNotification(title: String, body: String, timeString: String, identifier: String) {
       let dateFormatter = DateFormatter()
       dateFormatter.dateFormat = "HH:mm:ss"
       
       guard let fireDate = dateFormatter.date(from: timeString) else {
           print("Invalid time format")
           return
       }
       
       let content = UNMutableNotificationContent()
       content.title = title
       content.body = body
       content.sound = UNNotificationSound.default
       
       let calendar = Calendar.current
       let dateComponents = calendar.dateComponents([.hour, .minute, .second], from: fireDate)
       
       let trigger = UNCalendarNotificationTrigger(dateMatching: dateComponents, repeats: false)
       let request = UNNotificationRequest(identifier: identifier, content: content, trigger: trigger)
       
       UNUserNotificationCenter.current().add(request) { error in
           if let error = error {
               print("Error scheduling notification: \(error.localizedDescription)")
           } else {
               print("Notification scheduled successfully")
           }
       }
   }
}
