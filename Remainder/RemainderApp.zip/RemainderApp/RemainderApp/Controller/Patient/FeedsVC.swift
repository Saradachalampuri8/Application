//
//  FeedsVC.swift
//  RemainderApp
//
//  Created by SAIL on 08/03/24.
//

import UIKit
import AVKit

class FeedsVC: BasicViewController {
    @IBOutlet weak var cb1Button: UIButton! // Connect this outlet to your cb1Button in the storyboard
    @IBOutlet weak var cb2Button: UIButton! // Connect this outlet to your cb2Button in the storyboard
    @IBOutlet weak var cb3Button: UIButton! // Connect this outlet to your cb1Button in the storyboard
    @IBOutlet weak var cb4Button: UIButton! // Connect this outlet to your cb2Button in the storyboard
    @IBOutlet weak var cb5Button: UIButton! // Connect this outlet to your cb1Button in the storyboard
    @IBOutlet weak var cb6Button: UIButton!
   
    
    let hospitalId = UserDefaultsManager.shared.gethospitalId() ?? ""
    var cb1Checked: Bool = false
    var cb2Checked: Bool = false
    var cb3Checked: Bool = false
    var cb4Checked: Bool = false
    var cb5Checked: Bool = false
    var cb6Checked: Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateButtonAvailability()
    }
    
    @IBAction func backButton(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
  
    @IBAction func feedsHistoryButton(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ViewPatientFeedsVC") as! ViewPatientFeedsVC
        vc.hospitalId = hospitalId
                    self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func cb1Button(_ sender: Any) {
        cb1Checked.toggle()
        updateCheckBoxImage(cbButton: cb1Button, isChecked: cb1Checked)
    }
    
    @IBAction func cb2Button(_ sender: Any) {
        cb2Checked.toggle()
        updateCheckBoxImage(cbButton: cb2Button, isChecked: cb2Checked)
    }
    @IBAction func cb3Button(_ sender: Any) {
        cb1Checked.toggle()
        updateCheckBoxImage(cbButton: cb3Button, isChecked: cb3Checked)
    }
    
    @IBAction func cb4Button(_ sender: Any) {
        cb4Checked.toggle()
        updateCheckBoxImage(cbButton: cb4Button, isChecked: cb4Checked)
    }
    @IBAction func cb5Button(_ sender: Any) {
        cb5Checked.toggle()
        updateCheckBoxImage(cbButton: cb5Button, isChecked: cb5Checked)
    }
    
    @IBAction func cb6Button(_ sender: Any) {
        cb6Checked.toggle()
        updateCheckBoxImage(cbButton: cb6Button, isChecked: cb6Checked)
    }
    @IBAction func submitButton(_ sender: Any) {
        getApi()
    }
    func updateCheckBoxImage(cbButton: UIButton, isChecked: Bool) {
        let checkedImage = UIImage(named: "check-box")
        let uncheckedImage = UIImage(named: "unchecked")
        
        cbButton.setImage(isChecked ? checkedImage : uncheckedImage, for: .normal)
    }
    
    func updateButtonAvailability() {
        let currentDate = Date()
        let calendar = Calendar.current
        let currentHour = calendar.component(.hour, from: currentDate)
        
        // Enable cb1Button if current time is between 8:00 AM and 9:00 AM
        let cb1Enabled = currentHour >= 8 && currentHour < 9
        cb1Button.isEnabled = cb1Enabled
        
        // Enable cb2Button if current time is between 4:00 PM and 5:00 PM
        let cb2Enabled = currentHour >= 11 && currentHour < 12
        cb2Button.isEnabled = cb2Enabled
        
        let cb3Enabled = currentHour >= 13 && currentHour < 14
        cb3Button.isEnabled = cb3Enabled
        let cb4Enabled = currentHour >= 16 && currentHour < 17
        cb4Button.isEnabled = cb4Enabled
        let cb5Enabled = currentHour >= 19 && currentHour < 20
        cb5Button.isEnabled = cb5Enabled
        let cb6Enabled = currentHour >= 21 && currentHour < 22
        cb6Button.isEnabled = cb6Enabled
    }
    
}
extension FeedsVC {
    
    func getApi() {
        startIndicator()
        let apiURL = ApiList.PatientPhysioURL
        
        var formData: [String: Any] = [
            "hospital_id": hospitalId
        ]
        
        // Determine the boolean values based on the checkbox images
        if cb1Checked {
            formData["feeds_1"] = 1
        }
        
        if cb2Checked {
            formData["feeds_2"] = 1
        }
        
        if cb3Checked {
            formData["feeds_3"] = 1
        }
        
        if cb4Checked {
            formData["feeds_4"] = 1
        }
        
        if cb5Checked {
            formData["feeds_5"] = 1
        }
        
        if cb6Checked {
            formData["feeds_6"] = 1
        }
        
        // Check if all checkboxes are unchecked
        if !cb1Checked && !cb2Checked && !cb3Checked && !cb4Checked && !cb5Checked && !cb6Checked {
            showAlert(title: "Error", message: "Please select at least one checkbox.")
            stopIndicator()
            return
        }
        
        APIHandler().postAPIValues(type: PatientPhysioModel.self, apiUrl: apiURL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let data):
                print("Status: \(data.status)")
                print("Message: \(data.message)")
                DispatchQueue.main.async { [self] in
                    if data.status == "success" {
                        showAlert(title: "Success", message: data.message, okActionHandler: {
                            self.pushToViewController(withIdentifier: "PatientDashboardVC")
                        })
                    } else {
                        showAlert(title: "Failure", message: data.message)
                    }
                    stopIndicator()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {  [self] in
                    stopIndicator()
                    showAlert(title: "Failure", message: error.localizedDescription)
                }
            }
        }
    }


}

