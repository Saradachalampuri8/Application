//
//  PatientProfileVC.swift
//  RemainderApp
//
//  Created by SAIL on 08/04/24.
//

import UIKit

class PatientProfileVC: BasicViewController {
    
    @IBOutlet weak var profileImage: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var hospitalIdLabel: UILabel!
    @IBOutlet weak var genderLabel: UILabel!
    @IBOutlet weak var ageLabel: UILabel!
    @IBOutlet weak var mobileNoLabel: UILabel!
    @IBOutlet weak var diagnosisLabel: UILabel!
    
    let hospitalId = UserDefaultsManager.shared.gethospitalId() ?? ""
    var patientDetailsData: [PatientDetailsData] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        postApi()
    }
    
    @IBAction func backButton(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
   
}
extension PatientProfileVC {
    func postApi() {
        self.startIndicator()
        let formData = ["hospital_id": hospitalId]
        APIHandler().postAPIValues(type: PatientDetailsModel.self, apiUrl: ApiList.PatientDetailsURL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async { [self] in
                    self.patientDetailsData = data.patients
                    nameLabel.text = patientDetailsData.first?.name
                    hospitalIdLabel.text = patientDetailsData.first?.hospitalID
                    genderLabel.text = patientDetailsData.first?.gender
                    ageLabel.text = patientDetailsData.first?.age
                    mobileNoLabel.text = patientDetailsData.first?.mobileNumber
                    diagnosisLabel.text = patientDetailsData.first?.diagnosis
                    
                    if let profileImageURL = URL(string: ApiList.baseUrl + (patientDetailsData.first?.profileImage ?? "")) {
                        loadImage(from: profileImageURL, into: profileImage)
                    }
                    
                    self.stopIndicator()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    self.stopIndicator()
                    self.showAlert(title: "Failure", message: "Something Went Wrong", okActionHandler: {})
                }
            }
        }
    }
}
