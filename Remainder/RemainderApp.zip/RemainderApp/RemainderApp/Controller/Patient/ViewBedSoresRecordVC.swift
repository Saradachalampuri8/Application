//
//  ViewBedSoresRecordVC.swift
//  RemainderApp
//
//  Created by SAIL on 08/03/24.
//

import UIKit

class ViewBedSoresRecordVC: BasicViewController {

    @IBOutlet weak var dayLabel: UILabel!
    @IBOutlet weak var monthNameLabel: UILabel!
    @IBOutlet weak var yearLabel: UILabel!
    @IBOutlet weak var cbmImageView: UIImageView!
    @IBOutlet weak var cbeImageView: UIImageView!
    
    var hospitalId: String = ""
    var day: String = ""
    var monthName: String = ""
    var year: String = ""
    
    var monitoringBSRecordData: [MonitoringBSRecordData] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        dayLabel.text = day
        monthNameLabel.text = monthName
        yearLabel.text = year
        
        getApi()
    }
    @IBAction func backButton(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
}
extension ViewBedSoresRecordVC {
    func getApi() {
        startIndicator()
        let apiURL = ApiList.MonitoringBedSoresRecordURL
        let formData = ["hospital_id": hospitalId,"day": day,"month_name": monthName,"year": year]
    
        APIHandler().postAPIValues(type: MonitoringBSRecordModel.self, apiUrl: apiURL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async {
                    self.monitoringBSRecordData = data.data
                    self.updateCheckBoxImages() // Update checkbox images after receiving API response
                    self.stopIndicator()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    self.stopIndicator()
                    self.showAlert(title: "Failure", message: "Something Went Wrong", okActionHandler: {})
                }
            }
        }
    }
    
    func updateCheckBoxImages() {
        guard let firstRecord = monitoringBSRecordData.first else {
            // No data received, set default images
            cbmImageView.image = UIImage(named: "unchecked") // Replace "unchecked" with the name of your unchecked image
            cbeImageView.image = UIImage(named: "unchecked") // Replace "unchecked" with the name of your unchecked image
            return
        }
        
        // Update images based on the fetched data
        if firstRecord.bedsores1 > 0 {
            if let checkedImage = UIImage(named: "check-box") {
                cbmImageView.image = checkedImage
            } else {
                print("Error: Unable to load 'checked' image.")
            }
        } else {
            if let uncheckedImage = UIImage(named: "unchecked") {
                cbmImageView.image = uncheckedImage
            } else {
                print("Error: Unable to load 'unchecked' image.")
            }
        }
        
        if firstRecord.bedsores2 > 0 {
            if let checkedImage = UIImage(named: "check-box") {
                cbeImageView.image = checkedImage
            } else {
                print("Error: Unable to load 'checked' image.")
            }
        } else {
            if let uncheckedImage = UIImage(named: "unchecked") {
                cbeImageView.image = uncheckedImage
            } else {
                print("Error: Unable to load 'unchecked' image.")
            }
        }
    }

}
