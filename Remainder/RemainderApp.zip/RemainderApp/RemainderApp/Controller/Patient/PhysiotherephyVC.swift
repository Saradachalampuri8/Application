//
//  PhysiotherephyVC.swift
//  RemainderApp
//
//  Created by SAIL on 08/03/24.
//
import UIKit
import AVKit

class PhysiotherephyVC: BasicViewController {
    
    
    @IBOutlet weak var cb1Button: UIButton! // Connect this outlet to your cb1Button in the storyboard
    @IBOutlet weak var cb2Button: UIButton! // Connect this outlet to your cb2Button in the storyboard
    @IBOutlet weak var subView: UIView!
    
    let hospitalId = UserDefaultsManager.shared.gethospitalId() ?? ""

    var cb1Checked: Bool = false
    var cb2Checked: Bool = false
    
    var videoUrl = String()



    
    var player: AVPlayer?
    var playerLayer: AVPlayerLayer?
    var captureSession: AVCaptureSession!
    var name = ""
    var descriptionName = ""
    var isPlaying = true
    
    override func viewDidLoad() {
        super.viewDidLoad()
        videoApi()
        updateButtonAvailability()
      
    }
    
    @IBAction func backButton(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func physioHistoryButton(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ViewPatientPhysioVC") as! ViewPatientPhysioVC
        vc.hospitalId = hospitalId
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func cb1Button(_ sender: Any) {
        cb1Checked.toggle()
        updateCheckBoxImage(cbButton: cb1Button, isChecked: cb1Checked)
    }
    
    @IBAction func cb2Button(_ sender: Any) {
        cb2Checked.toggle()
        updateCheckBoxImage(cbButton: cb2Button, isChecked: cb2Checked)
    }
    
    @IBAction func submitButton(_ sender: Any) {
        getApi()
    }
    
    func updateCheckBoxImage(cbButton: UIButton, isChecked: Bool) {
        let checkedImage = UIImage(named: "check-box")
        let uncheckedImage = UIImage(named: "unchecked")
        
        cbButton.setImage(isChecked ? checkedImage : uncheckedImage, for: .normal)
    }
    
    func updateButtonAvailability() {
        let currentDate = Date()
        let calendar = Calendar.current
        let currentHour = calendar.component(.hour, from: currentDate)
        
        // Enable cb1Button if current time is between 8:00 AM and 9:00 AM
        let cb1Enabled = currentHour >= 8 && currentHour < 9
        cb1Button.isEnabled = cb1Enabled
        
        // Enable cb2Button if current time is between 4:00 PM and 5:00 PM
        let cb2Enabled = currentHour >= 16 && currentHour < 17
        cb2Button.isEnabled = cb2Enabled
    }
}

extension PhysiotherephyVC {
    func videoApi() {
        startIndicator()
        let apiURL = ApiList.GetExerciseURL
        APIHandler().postAPIValues(type: GetExerciseModel.self, apiUrl: apiURL, method: "POST", formData: [:]) { result in
            switch result {
            case .success(let data):
                
                DispatchQueue.main.async { [self] in
                    if data.status {
                        playVideo(with: data.videos.first ?? "")
                    } else {
                        showAlert(title: "Failure", message: "Error in BackEnd")
                    }
                    stopIndicator()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {  [self] in
                    stopIndicator()
                    showAlert(title: "Failure", message: error.localizedDescription)
                }
            }
        }
    }
    func getApi() {
        startIndicator()
        let apiURL = ApiList.PatientPhysioURL
        
        var formData: [String: Any] = [
            "hospital_id": hospitalId
        ]
        
        // Determine the boolean values based on the checkbox images
        if cb1Checked {
            formData["physio_morning"] = 1
        }
        
        if cb2Checked {
            formData["physio_evening"] = 1
        }
        
        // Check if both checkboxes are unchecked
        if !cb1Checked && !cb2Checked {
            showAlert(title: "Error", message: "Please select at least one checkbox.")
            stopIndicator()
            return
        }
        
        APIHandler().postAPIValues(type: PatientPhysioModel.self, apiUrl: apiURL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let data):
                print("Status: \(data.status)")
                print("Message: \(data.message)")
                DispatchQueue.main.async { [self] in
                    if data.status == "success" {
                        showAlert(title: "Success", message: data.message, okActionHandler: {
                            self.pushToViewController(withIdentifier: "PatientDashboardVC")
                        })
                    } else {
                        showAlert(title: "Failure", message: data.message)
                    }
                    stopIndicator()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {  [self] in
                    stopIndicator()
                    showAlert(title: "Failure", message: error.localizedDescription)
                }
            }
        }
    }

}
extension PhysiotherephyVC{
 func playVideo(with url: String) {
        
    let base = ApiList.baseUrl + url
    print("base :\(base)")
        guard let videoURL = URL(string: "\(base)") else {
            print("Invalid video URL")
            
            return
        }
        print("videoURL : \(videoURL)")
        player = AVPlayer(url: videoURL)
        
        guard let player = player else {
            //  print("Failed to initialize AVPlayer")
            return
        }
        
        let playerViewController = AVPlayerViewController()
        playerViewController.player = player
        playerViewController.entersFullScreenWhenPlaybackBegins = false
        playerViewController.allowsPictureInPicturePlayback = false
        
        addChild(playerViewController)
        subView.addSubview(playerViewController.view)
        playerViewController.view.frame = subView.bounds
        playerViewController.didMove(toParent: self)
        
        // Add observer for player status
        player.addObserver(self, forKeyPath: #keyPath(AVPlayer.status), options: .new, context:nil)
    }

       // Implement key-value observation method
override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
    if keyPath == #keyPath(AVPlayer.status) {
        if let player = player {
            if player.status == .failed {
                if let error = player.error {
                    print("Failed to load video: \(error)")
                } else {
                    //print("Failed to load video with an unknown error.")
                }
            }else {
                player.play()
            }
        } else {
            // print("AVPlayer is nil.")
        }
           }
       }

}
