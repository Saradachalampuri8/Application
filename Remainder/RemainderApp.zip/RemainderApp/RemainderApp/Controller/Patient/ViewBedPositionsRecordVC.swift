//
//  ViewBedPositionsRecordVC.swift
//  RemainderApp
//
//  Created by SAIL on 08/03/24.
//

import UIKit

class ViewBedPositionsRecordVC: BasicViewController {
    
    var hospitalid: String = ""
    var day: String = ""
    var monthName: String = ""
    var year: String = ""
    
    var monitoringPositionsRecordData: [MonitoringPositionsRecordData] = []
    
    @IBOutlet weak var dayLabel: UILabel!
    @IBOutlet weak var monthLabel: UILabel!
    @IBOutlet weak var yearLabel: UILabel!
    
    @IBOutlet weak var cb1ImageView: UIImageView!
    @IBOutlet weak var cb2ImageView: UIImageView!
    @IBOutlet weak var cb3ImageView: UIImageView!
    @IBOutlet weak var cb4ImageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        dayLabel.text = day
        monthLabel.text = monthName
        yearLabel.text = year
        getApi()

    }
    @IBAction func backButton(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
}
extension ViewBedPositionsRecordVC {
    func getApi() {
        startIndicator()
        let apiURL = ApiList.MonitoringBedPositionsRecordURL
        let formData = ["hospital_id": hospitalid,"day": day,"month_name": monthName,"year": year]
    
        APIHandler().postAPIValues(type: MonitoringPositionsRecordModel.self, apiUrl: apiURL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async {
                    self.monitoringPositionsRecordData = data.data
                    self.updateCheckBoxImages() // Update checkbox images after receiving API response
                    self.stopIndicator()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    self.stopIndicator()
                    self.showAlert(title: "Failure", message: "Something Went Wrong", okActionHandler: {})
                }
            }
        }
    }
    
    func updateCheckBoxImages() {
        guard let firstRecord = monitoringPositionsRecordData.first else {
            cb1ImageView.image = UIImage(named: "unchecked")
            cb2ImageView.image = UIImage(named: "unchecked")
            cb3ImageView.image = UIImage(named: "unchecked")
            cb4ImageView.image = UIImage(named: "unchecked")
            return
        }
        
        if firstRecord.bedpositions1 > 0 {
            if let checkedImage = UIImage(named: "check-box") {
                cb1ImageView.image = checkedImage
            } else {
                print("Error: Unable to load 'checked' image.")
            }
        } else {
            if let uncheckedImage = UIImage(named: "unchecked") {
                cb1ImageView.image = uncheckedImage
            } else {
                print("Error: Unable to load 'unchecked' image.")
            }
        }
        
        if firstRecord.bedpositions2 > 0 {
            if let checkedImage = UIImage(named: "check-box") {
                cb2ImageView.image = checkedImage
            } else {
                print("Error: Unable to load 'checked' image.")
            }
        } else {
            if let uncheckedImage = UIImage(named: "unchecked") {
                cb2ImageView.image = uncheckedImage
            } else {
                print("Error: Unable to load 'unchecked' image.")
            }
        }
        
        if firstRecord.bedpositions3 > 0 {
            if let checkedImage = UIImage(named: "check-box") {
                cb3ImageView.image = checkedImage
            } else {
                print("Error: Unable to load 'checked' image.")
            }
        } else {
            if let uncheckedImage = UIImage(named: "unchecked") {
                cb3ImageView.image = uncheckedImage
            } else {
                print("Error: Unable to load 'unchecked' image.")
            }
        }
        
        if firstRecord.bedpositions4 > 0 {
            if let checkedImage = UIImage(named: "check-box") {
                cb4ImageView.image = checkedImage
            } else {
                print("Error: Unable to load 'checked' image.")
            }
        } else {
            if let uncheckedImage = UIImage(named: "unchecked") {
                cb4ImageView.image = uncheckedImage
            } else {
                print("Error: Unable to load 'unchecked' image.")
            }
        }
    }
}
