
//  FoleysPatientVC.swift
//  RemainderApp
//
//  Created by SAIL on 08/03/24.
//

import UIKit

class FoleysPatientVC: BasicViewController,UITextFieldDelegate {
    
    @IBOutlet weak var segmentControllerOutlet: UISegmentedControl!
    @IBOutlet weak var selectDate: UITextField!
    @IBOutlet weak var submitButton: UIButton!
    let datePicker : UIDatePicker = UIDatePicker()
    
    let hospitalId = UserDefaultsManager.shared.gethospitalId() ?? ""

    var selectedDate: Date? 
//    {
//            didSet {
//                updateSubmitButtonState()
//            }
//        }
    override func viewDidLoad() {
        super.viewDidLoad()
        selectDate.delegate = self
       // updateSubmitButtonState()
    }
    
    @IBAction func dateTextFieldBeginEditing(_ sender: UITextField) {
        print("Text field tapped")
        showDatePicker(tag: sender.tag)
    }

       func showDatePicker(tag: Int){
           datePicker.datePickerMode = .date
           if #available(iOS 13.4, *) { datePicker.preferredDatePickerStyle = .inline }
           else { datePicker.preferredDatePickerStyle = .wheels }
           datePicker.maximumDate = Calendar.current.date(byAdding: .year, value: 0, to: Date())
           let toolbar = UIToolbar()
           toolbar.sizeToFit()
           let doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItem.Style.done, target: self, action: #selector(self.donedatePicker(_ :)))
           doneButton.tag = tag
           let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)
           let cancelButton = UIBarButtonItem(title: "Cancel", style: UIBarButtonItem.Style.plain, target: self, action: #selector(self.cancelDatePicker(_ :)))
           cancelButton.tag = tag
           toolbar.setItems([cancelButton ,spaceButton,doneButton], animated: false)
           self.selectDate.inputAccessoryView = toolbar
           self.selectDate.inputView = datePicker
       }
       @objc func cancelDatePicker(_ sender: UIButton){
           self.selectDate.text? = ""
           self.selectDate.placeholder = "Select the Date"
           self.view.endEditing(true)
       }
    @objc func donedatePicker(_ sender: UIButton){
            let formatter = DateFormatter()
            formatter.dateFormat = "yyyy-MM-dd"
            datePicker.maximumDate = Calendar.current.date(byAdding: .year, value: 0, to: Date())
            selectedDate = datePicker.date // Update selectedDate
            self.selectDate.text = formatter.string(from: datePicker.date)
            self.view.endEditing(true)
        }
    @IBAction func backButton(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
//    func updateSubmitButtonState() {
//            if let selectedDate = selectedDate {
//                let currentDate = Date()
//                let calendar = Calendar.current
//                if let difference = calendar.dateComponents([.day], from: selectedDate, to: currentDate).day {
//                    if difference > 25 {
//                        submitButton.isEnabled = false
//                    } else {
//                        submitButton.isEnabled = true
//                    }
//                }
//            } else {
//                submitButton.isEnabled = false
//            }
//        }
    @IBAction func foleysHistoryButton(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ViewPatientFoleysVC") as! ViewPatientFoleysVC
                    self.navigationController?.pushViewController(vc, animated: true)
    }
//    @IBAction func foleysSegmentButtonAction(_ sender: Any) {
//           switch segmentControllerOutlet.selectedSegmentIndex {
//           case 0:
//               getAPI(Mode: ApiList.FoleysURL)
//           case 1:
//               getAPI(Mode: ApiList.RylesURL)
//           default:
//               break
//           }
//       }
    @objc func foleyButtonTapped(_ sender: UIButton) {
//        updateApi(HospitalId: rowData.hospitalid, Status: "Foley")
//        print("Foley button tapped for hospital ID: \(rowData.hospitalid)")
    }
    
    @IBAction func submitButton(_ sender: Any) {
        if selectDate.text?.isEmpty == true{
           showToast("Please select the date")
        }else{
            getAPI()

        }
    }
}
extension FoleysPatientVC {
    func getAPI() {
        startIndicator()
        
        var apiURL: String = ""
        var formData: [String: Any] = [:]

        switch segmentControllerOutlet.selectedSegmentIndex {
        case 0:
            apiURL = ApiList.FoleysURL
            formData = [
                "hospital_id": hospitalId,
                "foleys_date": selectDate.text ?? ""
            ]
        case 1:
            apiURL = ApiList.RylesURL
            // Adjust formData accordingly for Ryles segment
            formData = ["hospital_id": hospitalId,
                        "ryles_date": selectDate.text ?? ""]
        default:
            break
        }

        APIHandler().postAPIValues(type: FoleysModel.self, apiUrl: apiURL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let data):
                print("Status: \(data.status)")
                print("Message: \(data.message)")
                DispatchQueue.main.async { [self] in
                    if data.status == "success" {
                        showAlert(title: "Success", message: data.message, okActionHandler: {
                            self.pushToViewController(withIdentifier: "PatientDashboardVC")
                        })
                    } else {
                        showAlert(title: "Failure", message: data.message)
                    }
                    stopIndicator()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {  [self] in
                    stopIndicator()
                    showAlert(title: "Failure", message: error.localizedDescription)
                }
            }
        }
    }
}
