//
//  ViewPatientFoleysVC.swift
//  RemainderApp
//
//  Created by SAIL on 08/03/24.
//

import UIKit

class ViewPatientFoleysVC: BasicViewController {
    @IBOutlet weak var segmentControllerOutlet: UISegmentedControl!
    @IBOutlet weak var searchBarOutlet: UISearchBar! {
        didSet {
            searchBarOutlet.delegate = self
        }
    }
    @IBOutlet weak var FoleysTable: UITableView! {
        didSet {
            FoleysTable.delegate = self
            FoleysTable.dataSource = self
            FoleysTable.register(UINib(nibName: "PhysioTableViewCell", bundle: nil), forCellReuseIdentifier: "PhysioTableViewCell")
        }
    }
    let hospitalId = UserDefaultsManager.shared.gethospitalId() ?? ""
    var overallData = [FoleysRecordData]()
    var filteredOverallData: [FoleysRecordData] = []
    override func viewDidLoad() {
        super.viewDidLoad()

        getAPI(Mode: ApiList.FoleysRecordURL)
    }
    

    @IBAction func backButton(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func foleysSegmentButtonAction(_ sender: Any) {
        switch segmentControllerOutlet.selectedSegmentIndex {
        case 0:
            self.getAPI(Mode: ApiList.FoleysRecordURL)
        case 1:
            self.getAPI(Mode: ApiList.RylesRecordURL)
        default:
            break
        }
    }
    
    @objc func foleyButtonTapped(_ sender: UIButton) {
        let rowIndex = sender.tag
        let rowData = filteredOverallData[rowIndex]
//        updateApi(HospitalId: rowData.hospitalid, Status: "Foley")
//        print("Foley button tapped for hospital ID: \(rowData.hospitalid)")
    }
}

extension ViewPatientFoleysVC{

    func getAPI(Mode : String) {
        startIndicator()
        let apiUrl = Mode
        let formData: [String: String] = [
                    "hospital_id": hospitalId
                ]
        APIHandler().postAPIValues(type: FoleysRecordModel.self, apiUrl: apiUrl, method: "POST", formData: formData) { result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async {
                    self.searchBarOutlet.text = ""
                    self.showToast(data.message)
                    self.overallData = data.data
                    self.filteredOverallData = self.overallData
                    self.FoleysTable.reloadData()
                    self.stopIndicator()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    self.stopIndicator()
                    self.showAlert(title: "Failure", message: "Something Went Wrong", okActionHandler: {})
                }
            }
        }
    }
   
}
extension ViewPatientFoleysVC: UISearchBarDelegate {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText.isEmpty {
            filteredOverallData = overallData
        } else {
            filteredOverallData = overallData.filter {
                $0.day.lowercased().contains(searchText.lowercased()) ||
                $0.monthName.lowercased().contains(searchText.lowercased()) ||
                $0.year.lowercased().contains(searchText.lowercased())
            }
        }
        FoleysTable.reloadData()
    }
}

extension ViewPatientFoleysVC: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if segmentControllerOutlet.selectedSegmentIndex == 0 {
            return filteredOverallData.count
        }else if segmentControllerOutlet.selectedSegmentIndex == 1{
            return filteredOverallData.count
        }else{
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "PhysioTableViewCell", for: indexPath) as! PhysioTableViewCell
        
    
        cell.dayLabel.text = filteredOverallData[indexPath.row].day
        cell.monthNameLabel.text = filteredOverallData[indexPath.row].monthName
        cell.yearLabel.text = filteredOverallData[indexPath.row].year
        
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        80
    }
        
    
}


