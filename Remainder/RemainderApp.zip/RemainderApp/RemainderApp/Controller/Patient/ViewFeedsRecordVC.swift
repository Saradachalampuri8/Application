//
//  ViewFeedsRecordVC.swift
//  RemainderApp
//
//  Created by SAIL on 08/03/24.
//

import UIKit

class ViewFeedsRecordVC: BasicViewController {
    
    @IBOutlet weak var dayLabel: UILabel!
    @IBOutlet weak var monthNameLabel: UILabel!
    @IBOutlet weak var yearLabel: UILabel!
    @IBOutlet weak var cb1ImageView: UIImageView!
    @IBOutlet weak var cb2ImageView: UIImageView!
    @IBOutlet weak var cb3ImageView: UIImageView!
    @IBOutlet weak var cb4ImageView: UIImageView!
    @IBOutlet weak var cb5ImageView: UIImageView!
    @IBOutlet weak var cb6ImageView: UIImageView!
    
    
    var hospitalid: String = ""
    var day: String = ""
    var monthName: String = ""
    var year: String = ""
    
    var monitoringBSRecordData: [FeedsRecordData] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        dayLabel.text = day
        monthNameLabel.text = monthName
        yearLabel.text = year
        
        getApi()
    }
    @IBAction func backButton(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
}
extension ViewFeedsRecordVC {
    func getApi() {
        startIndicator()
        let apiURL = ApiList.FeedsRecordURL
        let formData = ["hospital_id": hospitalid,"day": day,"month_name": monthName,"year": year]
    
        APIHandler().postAPIValues(type: FeedsRecordModel.self, apiUrl: apiURL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async {
                    self.monitoringBSRecordData = data.data
                    self.updateCheckBoxImages() // Update checkbox images after receiving API response
                    self.stopIndicator()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    self.stopIndicator()
                    self.showAlert(title: "Failure", message: "Something Went Wrong", okActionHandler: {})
                }
            }
        }
    }
    
    func updateCheckBoxImages() {
        guard let firstRecord = monitoringBSRecordData.first else {
            // No data received, set default images
            cb1ImageView.image = UIImage(named: "unchecked") // Replace "unchecked" with the name of your unchecked image
            cb2ImageView.image = UIImage(named: "unchecked") // Replace "unchecked" with the name of your unchecked image
            cb3ImageView.image = UIImage(named: "unchecked")
            cb4ImageView.image = UIImage(named: "unchecked")
            cb5ImageView.image = UIImage(named: "unchecked")
            cb6ImageView.image = UIImage(named: "unchecked")
            return
        }
        
        // Update images based on the fetched data
        if firstRecord.feeds1 > 0 {
            if let checkedImage = UIImage(named: "check-box") {
                cb1ImageView.image = checkedImage
            } else {
                print("Error: Unable to load 'checked' image.")
            }
        } else {
            if let uncheckedImage = UIImage(named: "unchecked") {
                cb1ImageView.image = uncheckedImage
            } else {
                print("Error: Unable to load 'unchecked' image.")
            }
        }
        
        if firstRecord.feeds2 > 0 {
            if let checkedImage = UIImage(named: "check-box") {
                cb2ImageView.image = checkedImage
            } else {
                print("Error: Unable to load 'checked' image.")
            }
        } else {
            if let uncheckedImage = UIImage(named: "unchecked") {
                cb2ImageView.image = uncheckedImage
            } else {
                print("Error: Unable to load 'unchecked' image.")
            }
        }
        if firstRecord.feeds3 > 0 {
            if let checkedImage = UIImage(named: "check-box") {
                cb3ImageView.image = checkedImage
            } else {
                print("Error: Unable to load 'checked' image.")
            }
        } else {
            if let uncheckedImage = UIImage(named: "unchecked") {
                cb3ImageView.image = uncheckedImage
            } else {
                print("Error: Unable to load 'unchecked' image.")
            }
        }
        if firstRecord.feeds4 > 0 {
            if let checkedImage = UIImage(named: "check-box") {
                cb4ImageView.image = checkedImage
            } else {
                print("Error: Unable to load 'checked' image.")
            }
        } else {
            if let uncheckedImage = UIImage(named: "unchecked") {
                cb4ImageView.image = uncheckedImage
            } else {
                print("Error: Unable to load 'unchecked' image.")
            }
        }
        if firstRecord.feeds5 > 0 {
            if let checkedImage = UIImage(named: "check-box") {
                cb5ImageView.image = checkedImage
            } else {
                print("Error: Unable to load 'checked' image.")
            }
        } else {
            if let uncheckedImage = UIImage(named: "unchecked") {
                cb5ImageView.image = uncheckedImage
            } else {
                print("Error: Unable to load 'unchecked' image.")
            }
        }
        if firstRecord.feeds6 > 0 {
            if let checkedImage = UIImage(named: "check-box") {
                cb6ImageView.image = checkedImage
            } else {
                print("Error: Unable to load 'checked' image.")
            }
        } else {
            if let uncheckedImage = UIImage(named: "unchecked") {
                cb6ImageView.image = uncheckedImage
            } else {
                print("Error: Unable to load 'unchecked' image.")
            }
        }
    }

}
