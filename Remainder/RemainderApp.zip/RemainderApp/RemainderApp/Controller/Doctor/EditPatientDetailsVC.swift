//
//  EditPatientDetailsVC.swift
//  RemainderApp
//
//  Created by SAIL on 08/03/24.
//

import UIKit

class EditPatientDetailsVC: BasicViewController {
    
    @IBOutlet weak var nameTextField: UITextField!
    
    @IBOutlet weak var hospitalIdLabel: UILabel!
    
    @IBOutlet weak var ageTextField: UITextField!
    @IBOutlet weak var gendertextField: UITextField!
    @IBOutlet weak var mobileNoTextField: UITextField!
    @IBOutlet weak var diagnosisTextField: UITextField!
    
    var hospitalid: String = ""
    var patientDetailsData : [PatientDetailsData] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        nameTextField.text =  patientDetailsData.first?.name
        ageTextField.text = patientDetailsData.first?.age
        mobileNoTextField.text = patientDetailsData.first?.mobileNumber
        diagnosisTextField.text = patientDetailsData.first?.diagnosis
        gendertextField.text = patientDetailsData.first?.gender
        hospitalIdLabel.text = hospitalid
        
    }
    
    @IBAction func saveButton(_ sender: Any) {
        registerUseredit()
    }
    @IBAction func backButton(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
}
extension EditPatientDetailsVC {
    
    func registerUseredit(){
        startIndicator()
        let apiURL = ApiList.EditPatientDetailsURL
        print(apiURL)
        let formData: [String: String] = [
            "hospital_id": "\(hospitalIdLabel.text ?? "")",
            "name": nameTextField.text ?? "",
            "mobile_number": mobileNoTextField.text ?? "",
            "gender": gendertextField.text ?? "",
            "age": ageTextField.text ?? "",
            "diagnosis": diagnosisTextField.text ?? ""
            
        ]
        APIHandler().postAPIValues(type: EditPatientDetailsModel.self, apiUrl: apiURL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let Data):
                print("Status: \(Data.status)")
                print("Message: \(Data.message)")
                DispatchQueue.main.async { [self] in
                    if Data.status == "success" {
                        
                        showAlert(title: "Success", message: Data.message,okActionHandler: {
                            self.pushToViewController(withIdentifier: "DoctorDasboardVC")
                        })
                       
                    } else {
                        showAlert(title: "Failure", message: Data.message)

                    }
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {  [self] in
                    showAlert(title: "Failure", message: error.localizedDescription)

                }
            }
        }
    }
    
}
