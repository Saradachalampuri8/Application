//
//  MonitoringBedSoresVC.swift
//  RemainderApp
//
//  Created by SAIL on 08/03/24.
//

import UIKit

class MonitoringBedSoresVC: BasicViewController {
    
    var filteredPatientRecordData: [MonitoringBedSoresData] = []
    var isSearching = false
    var sendData: [MonitoringBedSoresData] = []
    var monitoringSoresData: [MonitoringBedSoresData] = []
    var monitoringSoresListData : [MonitoringBedSoresData] = []
    
    var hospitalid: String = ""
    
    @IBOutlet weak var searchBarOutlet: UISearchBar! {
           didSet {
               searchBarOutlet.delegate = self
           }
       }
       
    
    @IBOutlet weak var patientBSRecordTable: UITableView! {
        didSet {
            patientBSRecordTable.delegate = self
            patientBSRecordTable.dataSource = self
            patientBSRecordTable.register(UINib(nibName: "PhysioTableViewCell", bundle: nil), forCellReuseIdentifier: "PhysioTableViewCell")
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getApi()

        }
    
    @IBAction func backButton(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
}
extension MonitoringBedSoresVC {
    func getApi() {
        startIndicator()
        let apiURL = ApiList.MonitoringBedSoresURL
        let formData = ["hospital_id": hospitalid]
        
        APIHandler().postAPIValues(type: MonitoringBedSoresModel.self, apiUrl: apiURL, method: "POST", formData: formData) { [weak self] result in
            guard let self = self else { return }
            switch result {
            case .success(let data):
                DispatchQueue.main.async {
                    self.stopIndicator()

                    if data.success{
                        self.monitoringSoresData = data.data
                        self.monitoringSoresListData = data.data
                        self.showToast(data.message)
                        self.patientBSRecordTable.reloadData()
                    }else{
                        self.showAlert(title:"Alert", message: data.message)
                    }
                }
            case .failure(let error):
                print("API Error: \(error)")
                DispatchQueue.main.async {
                    self.stopIndicator()
                    self.showAlert(title: "Failure", message: "Failed to fetch data. Please try again later.", okActionHandler: {})
                }
            }
        }
    }
}
extension MonitoringBedSoresVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
           return isSearching ? filteredPatientRecordData.count : monitoringSoresListData.count
       }

    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = patientBSRecordTable.dequeueReusableCell(withIdentifier: "PhysioTableViewCell", for: indexPath) as! PhysioTableViewCell

        let data = isSearching ? filteredPatientRecordData[indexPath.row] : monitoringSoresListData[indexPath.row]
        
        cell.dayLabel.text = " \(data.day)"
        cell.monthNameLabel.text = " \(data.monthName)"
        cell.yearLabel.text = " \(data.year)"
        
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let viewControllerIdentifier = "MonitoringBedSoresRecordVC"
        
        guard let vc = storyBoard.instantiateViewController(withIdentifier: viewControllerIdentifier) as? MonitoringBedSoresRecordVC else {
            print("Failed to instantiate view controller with identifier: \(viewControllerIdentifier)")
            return
        }

        let data = isSearching ? monitoringSoresData[indexPath.row] : monitoringSoresData[indexPath.row]
        
        vc.hospitalid = hospitalid
        vc.day = data.day
        vc.monthName = data.monthName
        vc.year = data.year

        navigationController?.pushViewController(vc, animated: true)
    }


    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80.0
    }
}
extension MonitoringBedSoresVC: UISearchBarDelegate {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText.isEmpty {
            isSearching = false
            filteredPatientRecordData = monitoringSoresListData
        } else {
            isSearching = true
            filteredPatientRecordData = monitoringSoresListData.filter {
                $0.day.lowercased().contains(searchText.lowercased()) ||
                $0.monthName.lowercased().contains(searchText.lowercased()) ||
                $0.year.lowercased().contains(searchText.lowercased())
            }
        }
        patientBSRecordTable.reloadData()
    }
}
