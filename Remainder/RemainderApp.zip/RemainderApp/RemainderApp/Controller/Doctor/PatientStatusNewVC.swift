//
//  PatientStatusNewVC.swift
//  RemainderApp
//
//  Created by SAIL on 07/03/24.
//

import UIKit

class PatientStatusNewVC: BasicViewController {
    
    @IBOutlet weak var rulTextField: UITextField!
    @IBOutlet weak var lulTextField: UITextField!
    @IBOutlet weak var rllTextField: UITextField!
    @IBOutlet weak var lllTextField: UITextField!
   
    
    var hospitalid: String = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    @IBAction func backButton(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func patientStatusHistoryButton(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "PatientStatusHistoryVC") as! PatientStatusHistoryVC
        vc.hospitalid = hospitalid
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func saveButton(_ sender: Any) {
//        let vc = self.storyboard?.instantiateViewController(withIdentifier: "DoctorDasboardVC") as! DoctorDasboardVC
//                    self.navigationController?.pushViewController(vc, animated: true)
        registerUseredit()
    }
    
    
}
extension PatientStatusNewVC {
    
    func registerUseredit(){
        startIndicator()
        let apiURL = ApiList.PatientStatusNewURL
        print(apiURL)
        let formData: [String: Any] = [
            "rul": rulTextField.text ?? "",
            "lul": lulTextField.text ?? "",
            "rll": rllTextField.text ?? "",
            "lll": lllTextField.text ?? "",
            "hospital_id":hospitalid
            
        ]
        APIHandler().postAPIValues(type: PatientStatusNewModel.self, apiUrl: apiURL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let Data):
                print("Status: \(Data.status)")
                print("Message: \(Data.message)")
                DispatchQueue.main.async { [self] in
                    if Data.status == "success" {
                        showAlert(title: "Success", message: Data.message,okActionHandler: {
                            self.pushToViewController(withIdentifier: "DoctorDasboardVC")
                        })
                       
                    } else {
                        showAlert(title: "Failure", message: Data.message)

                    }
                    stopIndicator()

                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {  [self] in
                    stopIndicator()
                    showAlert(title: "Failure", message: error.localizedDescription)

                }
            }
        }
    }
    
}
