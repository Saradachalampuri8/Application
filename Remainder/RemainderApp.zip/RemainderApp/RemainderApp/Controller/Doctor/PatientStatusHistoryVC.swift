import UIKit

class PatientStatusHistoryVC: BasicViewController {
    
    var hospitalid: String = ""
    var patientStatusHistoryData: [PatientStatusHistoryData] = []
    
    @IBOutlet weak var patientStatusRecordTable: UITableView! {
        didSet {
            patientStatusRecordTable.delegate = self
            patientStatusRecordTable.dataSource = self
            patientStatusRecordTable.register(UINib(nibName: "StatusHistoryTableViewCell", bundle: nil), forCellReuseIdentifier: "StatusHistoryTableViewCell")
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getApi()
    }
    
    @IBAction func backButton(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }

}
extension PatientStatusHistoryVC {
    func getApi() {
        startIndicator()
        let apiURL = ApiList.PatientStatusHistoryURL
        let formData = ["hospital_id": hospitalid]
        
        APIHandler().postAPIValues(type: PatientStatusHistoryModel.self, apiUrl: apiURL, method: "POST", formData: formData) { [weak self] result in
            guard let self = self else { return }
            switch result {
            case .success(let data):
                DispatchQueue.main.async {
                    self.stopIndicator()
                    if data.status == "success" {
                        self.patientStatusHistoryData = data.data
                        self.showToast(data.message)
                        self.patientStatusRecordTable.reloadData()
                    } else {
                        self.showAlert(title: "Alert", message: data.message)
                    }
                }
            case .failure(let error):
                print("API Error: \(error)")
                DispatchQueue.main.async {
                    self.stopIndicator()
                    self.showAlert(title: "Failure", message: "Failed to fetch data. Please try again later.", okActionHandler: {})
                }
            }
        }
    }
}

extension PatientStatusHistoryVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return patientStatusHistoryData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = patientStatusRecordTable.dequeueReusableCell(withIdentifier: "StatusHistoryTableViewCell", for: indexPath) as! StatusHistoryTableViewCell
        
        let data = patientStatusHistoryData[indexPath.row]
        cell.rulLabel.text = data.rul
        cell.lulLabel.text = data.lul
        cell.rllLabel.text = data.rll
        cell.lllLabel.text = data.lll
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}
