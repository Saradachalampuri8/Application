//
//  ViewMriReport.swift
//  RemainderApp
//
//  Created by SAIL on 07/03/24.
//

import UIKit

class ViewMriReport: BasicViewController {
    
    @IBOutlet weak var mriImage: UIImageView!
    
    var dischargeFormModel: MriModel?
    var hospitalid: String = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        postApi()
    }
    
    @IBAction func backButton(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }

}
extension ViewMriReport {
    func postApi() {
        self.startIndicator()
        let formData: [String: Any] = ["hospital_id": hospitalid]
        APIHandler().postAPIValues(type: MriModel.self, apiUrl: ApiList.MriFetchingURL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async { [self] in
                    if data.mri_images.isEmpty {
                        self.showAlert(title: "Alert", message: "No MRI images found")
                    } else {
                        for path in data.mri_images {
                            if let imageURL = URL(string: ApiList.baseUrl + path) {
                                self.loadImage(from: imageURL) { image in
                                    DispatchQueue.main.async {
                                        if let image = image {
                                            self.mriImage.image = image
                                        } else {
                                            self.showAlert(title: "Alert", message: "Failed to load image")
                                        }
                                    }
                                }
                            }
                        }
                    }
                    self.stopIndicator()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    self.stopIndicator()
                    self.showAlert(title: "Failure", message: "Something Went Wrong", okActionHandler: {})
                }
            }
        }
    }

    func loadImage(from url: URL, completion: @escaping (UIImage?) -> Void) {
        URLSession.shared.dataTask(with: url) { (data, response, error) in
            guard let data = data else {
                completion(nil)
                return
            }
            let image = UIImage(data: data)
            completion(image)
        }.resume()
    }
}
