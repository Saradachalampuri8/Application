//
//  TrackPatientVC.swift
//  RemainderApp
//
//  Created by SAIL on 07/03/24.
//
import UIKit

class TrackPatientVC: BasicViewController {
    
    var sendData: [MissingDay] = []
    var monitoringTrackPatientData: [MissingDay] = []
    
    var hospitalid: String = ""
    
    @IBOutlet weak var patientRecordTable: UITableView! {
        didSet {
            patientRecordTable.delegate = self
            patientRecordTable.dataSource = self
            patientRecordTable.register(UINib(nibName: "TrackPatientTableViewCell", bundle: nil), forCellReuseIdentifier: "TrackPatientTableViewCell")
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getApi()
    }

    @IBAction func backButton(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
}

extension TrackPatientVC {
    func getApi() {
        startIndicator()
        let apiURL = ApiList.TrackPatientURL
        let formData = ["hospital_id": hospitalid]
        
        APIHandler().postAPIValues(type: TrackPatientModel.self, apiUrl: apiURL, method: "POST", formData: formData) { [weak self] result in
            guard let self = self else { return }
            switch result {
            case .success(let data):
                DispatchQueue.main.async {
                    self.stopIndicator()

                    if data.status == "success" {
                        self.monitoringTrackPatientData = data.data.missingDays
                        if self.monitoringTrackPatientData.isEmpty {
                            self.showAlert(title: "Alert", message: "No missing days found")
                        } else {
                            self.showToast(data.message)
                        }
                        self.patientRecordTable.reloadData()
                    } else {
                        self.showAlert(title: "Alert", message: data.message)
                    }
                }
            case .failure(let error):
                print("API Error: \(error)")
                DispatchQueue.main.async {
                    self.stopIndicator()
                    self.showAlert(title: "Failure", message: "Failed to fetch data. Please try again later.", okActionHandler: {})
                }
            }
        }
    }
}

extension TrackPatientVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return monitoringTrackPatientData.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = patientRecordTable.dequeueReusableCell(withIdentifier: "TrackPatientTableViewCell", for: indexPath) as! TrackPatientTableViewCell

        let data = monitoringTrackPatientData[indexPath.row]
        cell.dayLabel.text = " \(data.day)"
        cell.monthLabel.text = " \(data.monthName)"
        cell.yearLabel.text = " \(data.year)"
        
        return cell
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100.0
    }
}
