//
//  MonitoringPositionsVC.swift
//  RemainderApp
//
//  Created by SAIL on 08/03/24.
//

import UIKit

class MonitoringPositionsVC: BasicViewController {
    
    var filteredPatientRecordData: [MonitoringBedPositionsData] = []
    var isSearching = false
    var sendData: [MonitoringBedPositionsData] = []
    var monitoringPositionsData: [MonitoringBedPositionsData] = []
    var monitoringPositionsListData : [MonitoringBedPositionsData] = []
    
    var hospitalid: String = ""
    
    @IBOutlet weak var searchBarOutlet: UISearchBar! {
           didSet {
               searchBarOutlet.delegate = self
           }
       }
    @IBOutlet weak var patientPositionsRecordTable: UITableView! {
        didSet {
            patientPositionsRecordTable.delegate = self
            patientPositionsRecordTable.dataSource = self
            patientPositionsRecordTable.register(UINib(nibName: "PhysioTableViewCell", bundle: nil), forCellReuseIdentifier: "PhysioTableViewCell")
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        getApi()   
    }
    
    @IBAction func backButton(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
}
extension MonitoringPositionsVC {
    func getApi() {
        startIndicator()
        let apiURL = ApiList.MonitoringBedPositionsURL
        let formData = ["hospital_id": hospitalid]
        
        APIHandler().postAPIValues(type: MonitoringBedPositionsModel.self, apiUrl: apiURL, method: "POST", formData: formData) { [weak self] result in
            guard let self = self else { return }
            switch result {
            case .success(let data):
                DispatchQueue.main.async {
                    self.stopIndicator()
                   

                    if data.success{
                        self.showToast(data.message)
                        self.monitoringPositionsData = data.data
                        self.monitoringPositionsListData = data.data
                        self.patientPositionsRecordTable.reloadData()
                    }else{
                        self.showAlert(title:"Alert", message: data.message)
                    }
                }
            case .failure(let error):
                print("API Error: \(error)")
                DispatchQueue.main.async {
                    self.stopIndicator()
                    self.showAlert(title: "Failure", message: "Failed to fetch data. Please try again later.", okActionHandler: {})
                }
            }
        }
    }
}
extension MonitoringPositionsVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
           return isSearching ? filteredPatientRecordData.count : monitoringPositionsListData.count
       }

    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = patientPositionsRecordTable.dequeueReusableCell(withIdentifier: "PhysioTableViewCell", for: indexPath) as! PhysioTableViewCell

        let data = isSearching ? filteredPatientRecordData[indexPath.row] : monitoringPositionsListData[indexPath.row]
        
        cell.dayLabel.text = " \(data.day)"
        cell.monthNameLabel.text = " \(data.monthName)"
        cell.yearLabel.text = " \(data.year)"
        
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let viewControllerIdentifier = "MonitoringPositionsRecordVC"
        
        guard let vc = storyBoard.instantiateViewController(withIdentifier: viewControllerIdentifier) as? MonitoringPositionsRecordVC else {
            print("Failed to instantiate view controller with identifier: \(viewControllerIdentifier)")
            return
        }

        let data = isSearching ? monitoringPositionsData[indexPath.row] : monitoringPositionsData[indexPath.row]
        
        vc.hospitalid = hospitalid
        vc.day = data.day
        vc.monthName = data.monthName
        vc.year = data.year

        navigationController?.pushViewController(vc, animated: true)
    }


    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80.0
    }
}
extension MonitoringPositionsVC: UISearchBarDelegate {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText.isEmpty {
            isSearching = false
            filteredPatientRecordData = monitoringPositionsListData
        } else {
            isSearching = true
            filteredPatientRecordData = monitoringPositionsListData.filter {
                $0.day.lowercased().contains(searchText.lowercased()) ||
                $0.monthName.lowercased().contains(searchText.lowercased()) ||
                $0.year.lowercased().contains(searchText.lowercased())
            }
        }
        patientPositionsRecordTable.reloadData()
    }
}
