//
//  DoctorProfileVC.swift
//  RemainderApp
//
//  Created by SAIL on 08/03/24.
//

import UIKit

class DoctorProfileVC: BasicViewController {

    @IBOutlet weak var profileImage: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var hospitalIdLabel: UILabel!
    @IBOutlet weak var genderLabel: UILabel!
    @IBOutlet weak var ageLabel: UILabel!
    @IBOutlet weak var mobileNoLabel: UILabel!

    
    var hospitalId = ""
    var doctorDetailsData: [DoctorProfileData] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        postApi()
    }
    
    @IBAction func backButton(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
}
extension DoctorProfileVC {
    func postApi() {
        self.startIndicator()
        let formData = ["doc_id": hospitalId]
        APIHandler().postAPIValues(type: DoctorProfileModel.self, apiUrl: ApiList.DoctorProfileURL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async { [self] in
                    self.doctorDetailsData = data.data
                    nameLabel.text = doctorDetailsData.first?.name
                    hospitalIdLabel.text = doctorDetailsData.first?.docID
                    genderLabel.text = doctorDetailsData.first?.gender
                    ageLabel.text = doctorDetailsData.first?.age
                    mobileNoLabel.text = doctorDetailsData.first?.contactNo
                                       
//                    if let profileImageURL = URL(string: ApiList.baseUrl + (patientDetailsData.first?.profileImage ?? "")) {
//                        loadImage(from: profileImageURL, into: profileImage)
//                    }
                    
                    self.stopIndicator()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    self.stopIndicator()
                    self.showAlert(title: "Failure", message: "Something Went Wrong", okActionHandler: {})
                }
            }
        }
    }
}
