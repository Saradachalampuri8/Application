//
//  PatientPerformanceVC.swift
//  RemainderApp
//
//  Created by SAIL on 02/04/24.
//

import UIKit
import Charts

class PatientPerformanceVC: BasicViewController {
    
    @IBOutlet weak var barChartView: BarChartView!
    
    var graphData = [GraphData]() // Assuming GraphData is a struct or class representing your API response data
    
    override func viewDidLoad() {
        super.viewDidLoad()
        graphApi()
    }
    
    func graphApi() {
        startIndicator()
        guard let hospitalId = UserDefaultsManager.shared.gethospitalId() else {
            stopIndicator()
            showAlert(title: "Error", message: "Hospital ID not found")
            return
        }
        
        let apiURL = ApiList.GraphURL
        let formData: [String: String] = ["hospital_id": hospitalId]
        
        APIHandler().postAPIValues(type: GraphModel.self, apiUrl: apiURL, method: "POST", formData: formData) { [weak self] result in
            guard let self = self else { return }
            
            switch result {
            case .success(let data):
                DispatchQueue.main.async {
                    if data.status == "success" {
                        self.graphData = data.data
                        self.updateChartData() // Call a method to update chart data
                    } else {
                        self.showAlert(title: "Failure", message: data.message)
                    }
                    self.stopIndicator()
                }
            case .failure(let error):
                DispatchQueue.main.async {
                    self.showAlert(title: "Failure", message: error.localizedDescription)
                    self.stopIndicator()
                }
            }
        }
    }
    
    func updateChartData() {
        var entries: [BarChartDataEntry] = []
        var labels: [String] = []
        
        for (index, data) in graphData.enumerated() {
            guard let totalCount = Double(data.totalCount) else {
                continue // Skip if total_count cannot be converted to Double
            }
            let entry = BarChartDataEntry(x: Double(index), y: totalCount)
            entries.append(entry)
            labels.append(data.date)
        }
        
        let dataSet = BarChartDataSet(entries: entries, label: "Total Count")
        let customColor = UIColor(named: "lightPink") ?? UIColor.blue // Use "AppColor" from asset catalog, fallback to blue if not found
        dataSet.colors = [customColor] // Set custom color for the bar chart
        
        let data = BarChartData(dataSet: dataSet)
        
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            
            self.barChartView.data = data
            self.barChartView.xAxis.valueFormatter = IndexAxisValueFormatter(values: labels)
            self.barChartView.xAxis.labelRotationAngle = -45
            self.barChartView.xAxis.granularity = 1
            self.barChartView.xAxis.labelCount = labels.count
            let barWidth = 1.2
            self.barChartView.barData?.barWidth = barWidth
            
            self.barChartView.notifyDataSetChanged()
        }
    }


    
    @IBAction func backButton(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
}


