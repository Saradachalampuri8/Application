//
//  AddPatientStatusVC.swift
//  RemainderApp
//
//  Created by SAIL on 08/03/24.
//

import UIKit

class AddPatientStatusVC: BasicViewController,UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    @IBOutlet weak var rulTextfield: UITextField!
    @IBOutlet weak var lulTextField: UITextField!
    @IBOutlet weak var rlltextfield: UITextField!
    @IBOutlet weak var lllTextField: UITextField!
    @IBOutlet weak var profileImage: UIImageView!
    @IBOutlet weak var profileButton: UIButton!
var hospitalId = ""
    var selectedImage = [UIImage]()
        
    var imagePicker = UIImagePickerController()
    
    //    var hospitalId = ""
    var patientDetailsData : [PatientDetailsData] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        imagePicker.delegate = self
        imagePicker.allowsEditing = true
        profileButton.addTarget(self, action: #selector(profileAction), for: .touchUpInside)
    }
    @objc func profileAction() {
        presentImagePicker()
    }
    @IBAction func backButton(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func saveButton(_ sender: Any) {
//        let vc = self.storyboard?.instantiateViewController(withIdentifier: "DoctorDasboardVC") as! DoctorDasboardVC
//                    self.navigationController?.pushViewController(vc, animated: true)
//        registerUseredit()
        uploadMriApi()
    }
    func presentImagePicker() {
           let alert = UIAlertController(title: "Choose Image", message: nil, preferredStyle: .actionSheet)
           alert.addAction(UIAlertAction(title: "Camera", style: .default, handler: { _ in
               self.openCamera()
           }))
           alert.addAction(UIAlertAction(title: "Gallery", style: .default, handler: { _ in
               self.openGallery()
           }))
           alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
           present(alert, animated: true, completion: nil)
    }
    
    func openCamera() {
          if UIImagePickerController.isSourceTypeAvailable(.camera) {
              imagePicker.sourceType = .camera
              present(imagePicker, animated: true, completion: nil)
          } else {
              showToast("There is no Camera")
          }
        }
            
    func openGallery() {
                imagePicker.sourceType = .photoLibrary
                present(imagePicker, animated: true, completion: nil)
        }

    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
                  if let pickedImage = info[UIImagePickerController.InfoKey.editedImage] as? UIImage {
                          profileImage.image = pickedImage
                      selectedImage.append(pickedImage)
                      print("selectedImage ----->",selectedImage )
                         
                      }
                  picker.dismiss(animated: true, completion: nil)
              }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
                picker.dismiss(animated: true, completion: nil)
            }
    
}
extension AddPatientStatusVC {
    func uploadMriApi() {
        let apiURL = ApiList.AddPatientStatusURL
        print("API URL:", apiURL)

        guard let url = URL(string: apiURL) else {
            print("Invalid API URL")
            return
        }

        let boundary = UUID().uuidString
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        var body = Data()

        let formData: [String: Any] = [
            "rul": rulTextfield.text ?? "",
            "lul": lulTextField.text ?? "",
            "rll": rlltextfield.text ?? "",
            "lll": lllTextField.text ?? "",
            "hospital_id": hospitalId
            
        ]

        for (key, value) in formData {
            body.append("--\(boundary)\r\n".data(using: .utf8)!)
            body.append("Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n".data(using: .utf8)!)
            body.append("\(value)\r\n".data(using: .utf8)!)
        }

        let fieldNames = ["mri"]

        for (index, image) in selectedImage.enumerated() {
            let fieldName = fieldNames[index]
            let imageData = image.jpegData(compressionQuality: 0.8)!

            body.append("--\(boundary)\r\n".data(using: .utf8)!)
            body.append("Content-Disposition: form-data; name=\"\(fieldName)\"; filename=\"\(UUID().uuidString).jpg\"\r\n".data(using: .utf8)!)
            body.append("Content-Type: image/jpeg\r\n\r\n".data(using: .utf8)!)
            body.append(imageData)
            body.append("\r\n".data(using: .utf8)!)
        }

        body.append("--\(boundary)--\r\n".data(using: .utf8)!) // Close the request body

        request.httpBody = body

        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
            if let error = error {
                print("Error: \(error)")
                // Handle or report the error to the user
                return
            }

            if let httpResponse = response as? HTTPURLResponse {
                print("Status code: \(httpResponse.statusCode)")

                if let data = data {
                    print("Response Data:", String(data: data, encoding: .utf8) ?? "")

                    do {
                        if let json = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any] {
                            if let status = json["status"] as? String, let message = json["message"] as? String {
                                DispatchQueue.main.async {
                                    if self.navigationController != nil {
                                        self.showAlert(title: "Success", message: message,okActionHandler: {
                                        self.pushToViewController(withIdentifier: "DoctorDasboardVC")})
//                                        self.showToast(message)
                                    }
                                }
                            }
                        }
                    } catch {
                        print("Error parsing JSON: \(error)")
                    }
                }
            } else {
                print("Invalid HTTP response")
            }
        }

        task.resume()
    }

    
//    func registerUseredit(){
//        startIndicator()
//        let apiURL = ApiList.AddPatientStatusURL
//        print(apiURL)
//        let formData: [String: Any] = [
//            "rul": rulTextfield.text ?? "",
//            "lul": lulTextField.text ?? "",
//            "rll": rlltextfield.text ?? "",
//            "lll": lllTextField.text ?? "",
//            "mri":  ""
//            
//        ]
//        APIHandler().postAPIValues(type: AddPatientStatusModel.self, apiUrl: apiURL, method: "POST", formData: formData) { result in
//            switch result {
//            case .success(let Data):
//                print("Status: \(Data.status)")
//                print("Message: \(Data.message)")
//                DispatchQueue.main.async { [self] in
//                    if Data.status == "success" {
//                        showAlert(title: "Success", message: Data.message,okActionHandler: {
//                            self.pushToViewController(withIdentifier: "DoctorDasboardVC")
//                        })
//                       
//                    } else {
//                        showAlert(title: "Failure", message: Data.message)
//
//                    }
//                    stopIndicator()
//
//                }
//            case .failure(let error):
//                print(error)
//                DispatchQueue.main.async {  [self] in
//                    stopIndicator()
//                    showAlert(title: "Failure", message: error.localizedDescription)
//
//                }
//            }
//        }
//    }
    
}
