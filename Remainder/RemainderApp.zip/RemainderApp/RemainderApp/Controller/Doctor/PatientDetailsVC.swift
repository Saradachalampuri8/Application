import UIKit

class PatientDetailsVC: BasicViewController {

    @IBOutlet weak var profileImage: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var hospitalIdLabel: UILabel!
    @IBOutlet weak var genderLabel: UILabel!
    @IBOutlet weak var ageLabel: UILabel!
    @IBOutlet weak var mobileNoLabel: UILabel!
    @IBOutlet weak var diagnosisLabel: UILabel!
    @IBOutlet weak var sideView: UIView!
    @IBOutlet weak var headlineView: UIView!
    @IBOutlet weak var sideViewStackView: UIStackView!
    @IBOutlet weak var sideViewHeightNSLayout: NSLayoutConstraint!
    
    var sideviewBool = true
    var hospitalId = ""
    var patientDetailsData: [PatientDetailsData] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        postApi()
//        sideView.isHidden = true
        sideViewHeightNSLayout.constant = 0

        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(handleTap(_:)))
              self.view.addGestureRecognizer(tapGestureRecognizer)
              tapGestureRecognizer.delegate = self
    }
    @objc func handleTap(_ sender: UITapGestureRecognizer) {
           if !sideView.isHidden {
               hideSideView()
           }
       }
    func showSideView() {
        sideView.isHidden = false
        sideViewHeightNSLayout.isActive = false
        sideViewHeightNSLayout = sideView.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.45)
        sideViewHeightNSLayout.isActive = true
        UIView.animate(withDuration: 0.3) {
                self.view.layoutIfNeeded()
            self.sideViewStackView.isHidden = false
            }
        sideviewBool = false
    }

    func hideSideView() {
        sideViewHeightNSLayout.isActive = false
        sideViewHeightNSLayout = sideView.heightAnchor.constraint(equalToConstant: 0)
        sideViewHeightNSLayout.isActive = true
        UIView.animate(withDuration: 0.3) {
            self.view.layoutIfNeeded()
            self.sideViewStackView.isHidden = true
        }
        sideviewBool = true
    }

    
    @IBAction func backButton(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func sideButton(_ sender: Any) {
        if sideviewBool{
            showSideView()
        }else{
            hideSideView()

        }
    }
    
    @IBAction func editPatientButton(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "EditPatientDetailsVC") as! EditPatientDetailsVC
        vc.hospitalid = hospitalId
        vc.patientDetailsData = patientDetailsData
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func patientPerformanceButton(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "PatientPerformanceVC") as! PatientPerformanceVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func physioButton(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "MonitoringPhysioVC") as! MonitoringPhysioVC
        vc.hospitalId = hospitalId
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func positionsButton(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "MonitoringPositionsVC") as! MonitoringPositionsVC
        vc.hospitalid = hospitalId
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func soresButton(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "MonitoringBedSoresVC") as! MonitoringBedSoresVC
        vc.hospitalid = hospitalId
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func foleysButton(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "MonitoringFoleysVC") as! MonitoringFoleysVC
        vc.hospitalid = hospitalId
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func patientStatusButton(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "PatientStatusNewVC") as! PatientStatusNewVC
        vc.hospitalid = hospitalId
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func trackPatientButton(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "TrackPatientVC") as! TrackPatientVC
        vc.hospitalid = hospitalId
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func mriButton(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ViewMriReport") as! ViewMriReport
        vc.hospitalid = hospitalId
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
extension PatientDetailsVC: UIGestureRecognizerDelegate {
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
        return touch.view != sideView
    }
}
extension PatientDetailsVC {
    func postApi() {
        self.startIndicator()
        let formData = ["hospital_id": hospitalId]
        APIHandler().postAPIValues(type: PatientDetailsModel.self, apiUrl: ApiList.PatientDetailsURL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async { [self] in
                    self.patientDetailsData = data.patients
                    nameLabel.text = patientDetailsData.first?.name
                    hospitalIdLabel.text = patientDetailsData.first?.hospitalID
                    genderLabel.text = patientDetailsData.first?.gender
                    ageLabel.text = patientDetailsData.first?.age
                    mobileNoLabel.text = patientDetailsData.first?.mobileNumber
                    diagnosisLabel.text = patientDetailsData.first?.diagnosis
                    
                    if let profileImageURL = URL(string: ApiList.baseUrl + (patientDetailsData.first?.profileImage ?? "")) {
                        loadImage(from: profileImageURL, into: profileImage)
                    }
                    
                    self.stopIndicator()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    self.stopIndicator()
                    self.showAlert(title: "Failure", message: "Something Went Wrong", okActionHandler: {})
                }
            }
        }
    }
}
