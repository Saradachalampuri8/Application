//
//  DoctorProfileModel.swift
//  RemainderApp
//
//  Created by SAIL on 13/04/24.
//

import Foundation

// MARK: - Loginmodel
struct DoctorProfileModel: Codable {
    let status, message: String
    let data: [DoctorProfileData]
}

// MARK: - Datum
struct DoctorProfileData: Codable {
    let name, docID, age, gender: String
    let contactNo: String

    enum CodingKeys: String, CodingKey {
        case name
        case docID = "doc_id"
        case age, gender
        case contactNo = "contact_no"
    }
}

