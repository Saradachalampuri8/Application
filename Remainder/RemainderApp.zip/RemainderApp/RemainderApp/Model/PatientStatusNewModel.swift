//
//  PatientStatusNewModel.swift
//  RemainderApp
//
//  Created by SAIL on 02/04/24.
//

import Foundation
// MARK: - Loginmodel
struct PatientStatusNewModel: Codable {
    let status, message: String
}
