//
//  TrackPatientModel.swift
//  RemainderApp
//
//  Created by SAIL on 01/04/24.
//

import Foundation
//
//// MARK: - Loginmodel
//struct TrackPatientModel: Codable {
//    let status, message: String
//    let data: TrackPatientData
//}
//
//// MARK: - DataClass
//struct TrackPatientData: Codable {
//    let missingDays: [MissingDay]
//
//    enum CodingKeys: String, CodingKey {
//        case missingDays = "missing_days"
//    }
//}
//
//// MARK: - MissingDay
//struct MissingDay: Codable {
//    let day, monthName, year: String
//
//    enum CodingKeys: String, CodingKey {
//        case day
//        case monthName = "month_name"
//        case year
//    }
//}
// MARK: - Loginmodel
struct TrackPatientModel: Codable {
    let status, message: String
    let data: TrackPatientData
}

// MARK: - DataClass
struct TrackPatientData: Codable {
    let missingDays: [MissingDay]

    enum CodingKeys: String, CodingKey {
        case missingDays = "missing_days"
    }
}

// MARK: - MissingDay
struct MissingDay: Codable {
    let day, monthName, year: String

    enum CodingKeys: String, CodingKey {
        case day
        case monthName = "month_name"
        case year
    }
}

