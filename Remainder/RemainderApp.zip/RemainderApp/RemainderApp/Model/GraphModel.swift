//
//  GraphModel.swift
//  RemainderApp
//
//  Created by SAIL on 06/05/24.
//

import Foundation

// MARK: - Loginmodel
struct GraphModel: Codable {
    let status, message: String
    let data: [GraphData]
}

// MARK: - Datum
struct GraphData: Codable {
    let date, totalCount: String

    enum CodingKeys: String, CodingKey {
        case date
        case totalCount = "total_count"
    }
}


