//
//  MonitoringBedPositionsModel.swift
//  RemainderApp
//
//  Created by SAIL on 27/03/24.
//

import Foundation
// MARK: - Loginmodel
struct MonitoringBedPositionsModel: Codable {
    let success: Bool
    let message: String
    let data: [MonitoringBedPositionsData]
}

// MARK: - Datum
struct MonitoringBedPositionsData: Codable {
    let day, monthName, year: String

    enum CodingKeys: String, CodingKey {
        case day
        case monthName = "month_name"
        case year
    }
}
