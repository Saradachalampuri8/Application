//
//  NotificationModel.swift
//  RemainderApp
//
//  Created by SAIL on 07/05/24.
//

import Foundation

struct NotificationModel: Codable {
    let status, message: String
    let data: [NotificationData]
}

// MARK: - Datum
struct NotificationData: Codable {
    let id, message, timing: String
}
