//
//  FeedsRecordModel.swift
//  RemainderApp
//
//  Created by SAIL on 01/04/24.
//

import Foundation

// MARK: - Loginmodel
struct FeedsRecordModel: Codable {
    let status, message: String
    let data: [FeedsRecordData]
}

// MARK: - Datum
struct FeedsRecordData: Codable {
    let feeds1, feeds2, feeds3, feeds4: Int
    let feeds5, feeds6: Int

    enum CodingKeys: String, CodingKey {
        case feeds1 = "feeds_1"
        case feeds2 = "feeds_2"
        case feeds3 = "feeds_3"
        case feeds4 = "feeds_4"
        case feeds5 = "feeds_5"
        case feeds6 = "feeds_6"
    }
}
