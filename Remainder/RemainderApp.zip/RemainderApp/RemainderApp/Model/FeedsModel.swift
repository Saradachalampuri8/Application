//
//  FeedsModel.swift
//  RemainderApp
//
//  Created by SAIL on 01/04/24.
//

import Foundation

// MARK: - Loginmodel
struct FeedsModel: Codable {
    let success: Bool
    let message: String
    let data: [FeedsData]
}

// MARK: - Datum
struct FeedsData: Codable {
    let day, monthName, year: String

    enum CodingKeys: String, CodingKey {
        case day
        case monthName = "month_name"
        case year
    }
}

