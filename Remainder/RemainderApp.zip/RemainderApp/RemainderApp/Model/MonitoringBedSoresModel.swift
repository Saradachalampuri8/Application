//
//  MonitoringBedSoresModel.swift
//  RemainderApp
//
//  Created by SAIL on 28/03/24.
//

import Foundation
// MARK: - Loginmodel
//struct MonitoringBedSoresModel: Codable {
//    let success: Bool
//    let message: String
//    let data: [MonitoringBedSoresData]
//}
//
//// MARK: - Datum
//struct MonitoringBedSoresData: Codable {
//    let day, monthName, year: String
//
//    enum CodingKeys: String, CodingKey {
//        case day
//        case monthName = "month_name"
//        case year
//    }
//}
// MARK: - Loginmodel
struct MonitoringBedSoresModel: Codable {
    let success: Bool
    let message: String
    let data: [MonitoringBedSoresData]
}

// MARK: - Datum
struct MonitoringBedSoresData: Codable {
    let day, monthName, year: String

    enum CodingKeys: String, CodingKey {
        case day
        case monthName = "month_name"
        case year
    }
}
