//
//  AddPatientStatusModel.swift
//  RemainderApp
//
//  Created by SAIL on 18/03/24.
//

import Foundation

struct AddPatientStatusModel: Codable {
    let status, message: String
}
