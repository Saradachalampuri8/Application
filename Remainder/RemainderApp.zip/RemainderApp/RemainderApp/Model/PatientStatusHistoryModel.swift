//
//  PatientStatusHistoryModel.swift
//  RemainderApp
//
//  Created by SAIL on 02/04/24.
//

import Foundation

//// MARK: - Loginmodel
//struct PatientStatusHistoryModel: Codable {
//    let status, message: String
//    let data: [PatientStatusHistoryData]
//}
//
//// MARK: - Datum
//struct PatientStatusHistoryData: Codable {
//    let patientStatusRul, patientStatusLul, patientStatusRLL, patientStatusLll: String
//
//    enum CodingKeys: String, CodingKey {
//        case patientStatusRul = "patient_status_rul"
//        case patientStatusLul = "patient_status_lul"
//        case patientStatusRLL = "patient_status_rll"
//        case patientStatusLll = "patient_status_lll"
//    }
//}
// MARK: - Loginmodel
struct PatientStatusHistoryModel: Codable {
    let status, message: String
    let data: [PatientStatusHistoryData]
}

// MARK: - Datum
struct PatientStatusHistoryData: Codable {
    let rul, lul, rll, lll: String
}
