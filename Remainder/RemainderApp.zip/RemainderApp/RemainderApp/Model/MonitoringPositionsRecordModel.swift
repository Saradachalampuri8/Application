//
//  MonitoringPositionsRecordModel.swift
//  RemainderApp
//
//  Created by SAIL on 28/03/24.
//

import Foundation

struct MonitoringPositionsRecordModel: Codable {
    let status, message: String
    let data: [MonitoringPositionsRecordData]
}

struct MonitoringPositionsRecordData: Codable {
    let bedpositions1, bedpositions2, bedpositions3, bedpositions4: Int

    enum CodingKeys: String, CodingKey {
        case bedpositions1 = "bedpositions_1"
        case bedpositions2 = "bedpositions_2"
        case bedpositions3 = "bedpositions_3"
        case bedpositions4 = "bedpositions_4"
    }
}
