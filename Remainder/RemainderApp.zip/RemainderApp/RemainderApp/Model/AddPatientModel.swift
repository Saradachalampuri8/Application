//
//  AddPatientModel.swift
//  RemainderApp
//
//  Created by SAIL on 14/03/24.
//

import Foundation
struct AddPatientModel: Codable {
    let status, message: String
}

