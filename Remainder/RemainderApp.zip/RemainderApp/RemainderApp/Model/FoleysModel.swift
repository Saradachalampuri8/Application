//
//  FoleysModel.swift
//  RemainderApp
//
//  Created by SAIL on 23/04/24.
//

import Foundation
// MARK: - Loginmodel
struct FoleysModel: Codable {
    let status, message: String
}

