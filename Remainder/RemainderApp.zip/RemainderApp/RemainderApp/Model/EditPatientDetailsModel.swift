//
//  EditPatientDetailsModel.swift
//  RemainderApp
//
//  Created by SAIL on 14/03/24.
//

import Foundation

// MARK: - Loginmodel
struct EditPatientDetailsModel: Codable {
    let status, message: String
}
