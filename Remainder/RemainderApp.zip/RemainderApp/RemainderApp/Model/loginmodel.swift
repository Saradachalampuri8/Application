//
//  loginmodel.swift
//  RemainderApp
//
//  Created by SAIL on 11/03/24.
//

import Foundation

struct Loginmodel: Codable {
    let status, message: String
}
