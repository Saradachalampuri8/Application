//
//  PatientPhysioModel.swift
//  RemainderApp
//
//  Created by SAIL on 15/04/24.
//

import Foundation
// MARK: - Loginmodel
struct PatientPhysioModel: Codable {
    let status, message: String
}

struct GetExerciseModel: Codable {
    let status: Bool
    let videos: [String]
}
