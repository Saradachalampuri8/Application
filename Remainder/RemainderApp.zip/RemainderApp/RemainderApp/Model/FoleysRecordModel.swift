//
//  FoleysRecordModel.swift
//  RemainderApp
//
//  Created by SAIL on 04/04/24.
//

import Foundation
// MARK: - Loginmodel
struct FoleysRecordModel: Codable {
    let success: Bool
    let message: String
    let data: [FoleysRecordData]
}

// MARK: - Datum
struct FoleysRecordData: Codable {
    let day, monthName, year: String

    enum CodingKeys: String, CodingKey {
        case day
        case monthName = "month_name"
        case year
    }
}
