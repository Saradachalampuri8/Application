//
//  MonitoringPhysioRecordModel.swift
//  RemainderApp
//
//  Created by SAIL on 22/03/24.
//

import Foundation

struct MonitoringPhysioRecordModel: Codable {
    let status, message: String
    let data: [MonitoringPhysioRecordData]
}

struct MonitoringPhysioRecordData: Codable {
    let physioMorning, physioEvening: Int

    enum CodingKeys: String, CodingKey {
        case physioMorning = "physio_morning"
        case physioEvening = "physio_evening"
    }
}

