//
//  MonitoringPhysioModel.swift
//  RemainderApp
//
//  Created by SAIL on 20/03/24.
//

import Foundation

struct MonitoringPhysioModel: Codable {
    let success: Bool
    let message: String
    let data: [MonitoringPhysioData]
}

struct MonitoringPhysioData: Codable {
    let day, monthName, year: String

    enum CodingKeys: String, CodingKey {
        case day
        case monthName = "month_name"
        case year
    }
}
