//
//  MonitoringBSRecordModel.swift
//  RemainderApp
//
//  Created by SAIL on 29/03/24.
//

import Foundation

struct MonitoringBSRecordModel: Codable {
    let status, message: String
    let data: [MonitoringBSRecordData]
}
struct MonitoringBSRecordData: Codable {
    let bedsores1, bedsores2: Int

    enum CodingKeys: String, CodingKey {
        case bedsores1 = "bedsores_1"
        case bedsores2 = "bedsores_2"
    }
}

