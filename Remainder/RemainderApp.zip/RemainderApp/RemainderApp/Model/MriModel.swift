//
//  MriModel.swift
//  RemainderApp
//
//  Created by SAIL on 06/04/24.
//

import Foundation

// MARK: - Loginmodel
struct MriModel: Codable {
    let status, message: String
    let mri_images: [String]
}


