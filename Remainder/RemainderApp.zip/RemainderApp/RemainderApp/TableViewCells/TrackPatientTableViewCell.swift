//
//  TrackPatientTableViewCell.swift
//  RemainderApp
//
//  Created by SAIL on 01/04/24.
//

import UIKit

class TrackPatientTableViewCell: UITableViewCell {

    @IBOutlet weak var messageLabel: UILabel!
    
  
    @IBOutlet weak var dayLabel: UILabel!
  
    @IBOutlet weak var monthLabel: UILabel!
    @IBOutlet weak var yearLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
    
}
