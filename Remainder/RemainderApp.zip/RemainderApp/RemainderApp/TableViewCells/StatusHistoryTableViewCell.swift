//
//  StatusHistoryTableViewCell.swift
//  RemainderApp
//
//  Created by SAIL on 05/04/24.
//

import UIKit

class StatusHistoryTableViewCell: UITableViewCell {

    @IBOutlet weak var rulLabel: UILabel!
    @IBOutlet weak var lulLabel: UILabel!
    @IBOutlet weak var rllLabel: UILabel!
    @IBOutlet weak var lllLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
