//
//  PhysioTableViewCell.swift
//  RemainderApp
//
//  Created by SAIL on 29/02/24.
//

import UIKit

class PhysioTableViewCell: UITableViewCell {

    @IBOutlet weak var calenderImage: UIImageView!
    @IBOutlet weak var dayLabel: UILabel!
    @IBOutlet weak var monthNameLabel: UILabel!
    @IBOutlet weak var yearLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
