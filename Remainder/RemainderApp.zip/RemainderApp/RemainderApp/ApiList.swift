
import Foundation
import UIKit


struct ApiList {
    static let baseUrl = "http://192.168.152.24/php/"
//    static let baseUrl = "http://172.23.18.233/php/"
    static let dloginURL = baseUrl+"dlogin.php"
    static let ploginURL = baseUrl+"plogin.php"
    static let PatientListURL = baseUrl+"plist.php"
    static let PatientDetailsURL = baseUrl+"patient_details_doctor.php"
    static let EditPatientDetailsURL = baseUrl+"edit_patient_details_doc.php"
    static let AddPatientURL = baseUrl+"add_patient_ios.php"
    static let AddPatientStatusURL = baseUrl+"add_patient_status_ios.php"
    static let MonitoringPhysioTBURL = baseUrl+"physio_patient_rec.php"
    static let MonitoringPhysioRecordURL = baseUrl+"physio_record.php"
    static let MonitoringBedPositionsURL = baseUrl+"bed_positions_patient_rec.php"
    static let MonitoringBedPositionsRecordURL = baseUrl+"bed_positions_record.php"
    static let MonitoringBedSoresURL = baseUrl+"bed_sores_patient_rec.php"
    static let MonitoringBedSoresRecordURL = baseUrl+"bed_sores_record.php"
    static let FeedsURL = baseUrl+"feeds_patient_rec.php"
    static let FeedsRecordURL = baseUrl+"feeds_record.php"
    static let TrackPatientURL = baseUrl+"track_patient.php"
    static let PatientStatusHistoryURL = baseUrl+"status.php"
    static let PatientStatusNewURL = baseUrl+"Patient_status_new_rec.php"
    static let FoleysRecordURL = baseUrl+"foleys_patient_rec.php"
    static let RylesRecordURL = baseUrl+"ryles_patient_rec.php"
    static let MriFetchingURL = baseUrl+"mri_fetch.php"
    static let DoctorProfileURL = baseUrl+"doc_profile.php"
    static let PatientProfileURL = baseUrl+"doc_profile.php"
    static let PatientPhysioURL = baseUrl+"patient_insert_ios.php"
    static let GetExerciseURL = baseUrl+"get_exercise.php"
    static let FoleysURL = baseUrl+"foleysios.php"
    static let RylesURL = baseUrl+"rylesios.php"
    static let GraphURL = baseUrl+"graph_doc.php"
    static let NotificationURL = baseUrl+"notify.php"
}
