
<?php
// Initialize response array
$response = array();

// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Check if hospital_id is provided in the request
    if(isset($_POST['hospital_id'])) {
        // Get the provided hospital_id
        $hospital_id = $_POST['hospital_id'];
        
        require_once('conn.php');

        // Check if the provided hospital_id exists in the database
        $check_sql = "SELECT COUNT(*) AS count FROM patient_records WHERE hospital_id = ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("s", $hospital_id);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();
        $row = $check_result->fetch_assoc();

        // If the hospital_id does not exist, set response with empty data
        if ($row['count'] == 0) {
            $response['status'] = 'success';
            $response['message'] = 'Hospital not found';
            $response['data'] = array("missing_days" => array()); // Ensure 'data' is always an associative array
        } else {
            // Initialize an array to store the missing days
            $missing_days = array();

            // Loop through the past five days
            for ($i = 0; $i < 5; $i++) {
                // Get the date for the current day
                $current_date = date('Y-m-d', strtotime("-$i days"));
                
                // Extract day, month, and year from the current date
                $day = date('d', strtotime($current_date));
                $monthName = date('F', strtotime($current_date));
                $year = date('Y', strtotime($current_date));

                // Prepare the SQL statement to check if there's a record for the current day
                $check_sql = "SELECT COUNT(*) AS count FROM patient_records WHERE hospital_id = ? AND day = ? AND month_name = ? AND year = ?";
                $check_stmt = $conn->prepare($check_sql);
                $check_stmt->bind_param("ssss", $hospital_id, $day, $monthName, $year);
                $check_stmt->execute();
                $check_result = $check_stmt->get_result();
                $check_row = $check_result->fetch_assoc();

                // If no record found for the current day, add it to the missing days array
                if ($check_row['count'] == 0) {
                    $missing_days[] = array(
                        'day' => $day,
                        'month_name' => $monthName,
                        'year' => $year
                    );
                }
            }

            // Check if all days are completed
            if (empty($missing_days)) {
                // All days are completed
                $status_message = "All days completed";
            } else {
                // Some days are missing
                $status_message = "Patient has not completed all days";
            }

            // Set response data
            $response['status'] = 'success';
            $response['message'] = $status_message;
            $response['data'] = array("missing_days" => $missing_days);
        }

        // Closing the connection
        $conn->close();
    } else {
        // If hospital_id is not provided
        $response['status'] = 'error';
        $response['message'] = 'hospital_id not provided';
    }
} else {
    // Handle the case where the request method is not POST
    $response['status'] = 'error';
    $response['message'] = 'Invalid request method';
}

// Set the content type header to JSON
header('Content-Type: application/json');

// Encoding the response array as JSON
echo json_encode($response);
?>



