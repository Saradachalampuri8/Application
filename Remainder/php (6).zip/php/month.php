<?php

// Include the connection file
require "conn.php";

// Initialize the response array
$response = array();

// Check connection
if ($conn->connect_error) {
    $response['status'] = 'error';
    $response['message'] = 'Connection failed: ' . $conn->connect_error;
} else {
    // Check if the request method is POST
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Get the raw JSON data from the request
        $json_data = file_get_contents("php://input");

        // Log received JSON data for debugging
        file_put_contents("debug.log", "Received JSON data: " . $json_data);

        // Decode the JSON data into an associative array
        $data = json_decode($json_data, true);

        // Check for JSON decoding errors
        if ($data === null && json_last_error() !== JSON_ERROR_NONE) {
            // JSON decoding error
            $response['status'] = 'error';
            $response['message'] = 'Error decoding JSON: ' . json_last_error_msg();
        } else {
            // Check if the required keys exist in the $data array
            if (isset($data['hospital_id'], $data['foleys'], $data['ryles'])) {
                // Collect data from the decoded JSON array
                $hospital_id = $data['hospital_id'];
                $foleys_date = $data['foleys'];
                $ryles_date = $data['ryles'];

                // Prepare and bind the SQL statement without specifying sno (auto-incremented)
                $sql = $conn->prepare("INSERT INTO month (hospital_id, foleys, ryles)
                                       VALUES (?, ?, ?)");
                $sql->bind_param("sss", $hospital_id, $foleys_date, $ryles_date);

                // Execute the SQL query
                if ($sql->execute()) {
                    $response['status'] = 'success';
                    $response['message'] = 'Data inserted successfully';
                } else {
                    $response['status'] = 'error';
                    $response['message'] = 'Error inserting data: ' . $sql->error;
                }

                // Close the statement
                $sql->close();
            } else {
                // If the required keys are not present in the $data array
                $response['status'] = 'error';
                $response['message'] = 'Incomplete data received';
                $response['received_data'] = $data;
            }
        }
    } else {
        // If the request method is not POST
        $response['status'] = 'error';
        $response['message'] = 'Invalid request method';
    }

    // Close connection
    $conn->close();
}

// Output JSON response
header('Content-Type: application/json');
echo json_encode($response);

?>
