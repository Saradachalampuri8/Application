<?php
require_once('conn.php');

// Check if doc_id is provided and not empty
if(isset($_POST['doc_id']) && !empty($_POST['doc_id'])) {
    $doc_id = $_POST['doc_id'];

    // Check if doc_id exists in the database
    $check_sql = "SELECT COUNT(*) as count FROM doc_profile WHERE doc_id = '$doc_id'";
    $check_result = $conn->query($check_sql);
    $check_row = $check_result->fetch_assoc();
    $doc_count = $check_row['count'];

    if ($doc_count > 0) {
        // Doc ID exists, proceed to fetch data
        $sql = "SELECT name, doc_id, age, gender, contact_no FROM doc_profile WHERE doc_id = '$doc_id'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // Output data of each row
            $data = array();
            while($row = $result->fetch_assoc()) {
                $data[] = $row;
            }
            
            // Close connection
            $conn->close(); 

            // Return JSON response with data
            header('Content-Type: application/json');
            echo json_encode(array('status' => 'success', 'message' => 'Data fetched successfully', 'data' => $data));
        } else {
            // Close connection
            $conn->close();

            // No data found message with empty data
            header('Content-Type: application/json');
            echo json_encode(array('status' => 'error', 'message' => 'No data found for the provided doc ID', 'data' => []));
        }
    } else {
        // Doc ID does not exist message with empty data
        header('Content-Type: application/json');
        echo json_encode(array('status' => 'error', 'message' => 'Doc ID does not exist', 'data' => []));
    }
} else {
    // No doc_id provided or empty message with empty data
    header('Content-Type: application/json');
    echo json_encode(array('status' => 'error', 'message' => 'Doc ID is not provided or empty', 'data' => []));
}
?>
