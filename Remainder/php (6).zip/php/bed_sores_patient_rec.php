


<?php

// Include the database connection file (conn.php)
require_once('conn.php');

// Check if the hospital_id is set in the POST data
$hospital_id = isset($_POST["hospital_id"]) ? $_POST["hospital_id"] : null;

// Check if the hospital_id is not null
if ($hospital_id !== null) {
    // Prepare the SQL query to retrieve patient records
    $sql = "SELECT day, month_name, year 
            FROM patient_records 
            WHERE hospital_id = ? 
            AND (bedsores_1 = 1 OR bedsores_2 = 1)";
    $stmt = $conn->prepare($sql);

    // Check if the statement is prepared successfully
    if ($stmt) {
        // Bind the parameters and execute the query
        $stmt->bind_param("s", $hospital_id); // assuming hospital_id is a string
        $stmt->execute();

        // Get the result set
        $result = $stmt->get_result();

        // Check if there are rows in the result set
        if ($result->num_rows > 0) {
            // Initialize an array to store patient data
            $patientData = array();

            // Fetch data from each row and store it in the array
            while ($row = $result->fetch_assoc()) {
                // Strip HTML tags if present in the response
                $row = array_map('strip_tags', $row);
                $patientData[] = array(
                    'day' => $row['day'],
                    'month_name' => $row['month_name'],
                    'year' => $row['year']
                );
            }

            // Convert the data to JSON
            $jsonResponse = json_encode(array('success' => true,'message' => 'Data has been fetched successfully', 'data' => $patientData));
            echo $jsonResponse;
        } else {
            // If no results are found
            $jsonResponse = json_encode(array('success' => false, 'message' => 'No results found for the given hospital_id.', 'data' => array()));
            echo $jsonResponse;
        }

        // Close the statement
        $stmt->close();
    } else {
        // If there is an error in preparing the SQL statement
        $jsonResponse = json_encode(array('success' => false, 'message' => 'Error in preparing SQL statement.', 'data' => array()));
        echo $jsonResponse;
    }
} else {
    // If hospital_id is not set in POST data
    $jsonResponse = json_encode(array('success' => false, 'message' => 'Hospital ID not provided in POST data.', 'data' => array()));
    echo $jsonResponse;
}

// Close the database connection
$conn->close();

?>
