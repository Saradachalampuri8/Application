<?php

require("conn.php"); // Include your database connection code

// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Read JSON data from the request body
    $inputJSON = file_get_contents('php://input');
    $_POST = json_decode($inputJSON, true);

    // Extracting values from JSON with isset checks
    $hospital_id = isset($_POST['hospital_id']) ? $_POST['hospital_id'] : null;

    // Check if hospital_id is null or empty
    if (empty($hospital_id)) {
        // Return error response if hospital_id is null or empty
        header('Content-Type: application/json');
        echo json_encode(array("status" => "error", "message" => "hospital_id cannot be null or empty"));
        exit; // Terminate script execution
    }

    // Get the current date
    $day = date('d');
    $month_name = date('F');
    $year = date('Y');

    // Check if a record with the given hospital_id, day, month_name, and year already exists
    $stmt_check_existing = $conn->prepare("SELECT * FROM patient_records WHERE hospital_id = ? AND day = ? AND month_name = ? AND year = ?");
    $stmt_check_existing->bind_param("siss", $hospital_id, $day, $month_name, $year);
    $stmt_check_existing->execute();
    $result = $stmt_check_existing->get_result();

    if ($result->num_rows > 0) {
        // Record already exists, fetch the existing values
        $row = $result->fetch_assoc();
        $existing_physio_morning = $row['physio_morning'];
        $existing_physio_evening = $row['physio_evening'];
        $existing_bedpositions_1 = $row['bedpositions_1'];
        $existing_bedpositions_2 = $row['bedpositions_2'];
        $existing_bedpositions_3 = $row['bedpositions_3'];
        $existing_bedpositions_4 = $row['bedpositions_4'];
        $existing_bedsores_1 = $row['bedsores_1'];
        $existing_bedsores_2 = $row['bedsores_2'];
        $existing_feeds_1 = $row['feeds_1'];
        $existing_feeds_2 = $row['feeds_2'];
        $existing_feeds_3 = $row['feeds_3'];
        $existing_feeds_4 = $row['feeds_4'];
        $existing_feeds_5 = $row['feeds_5'];
        $existing_feeds_6 = $row['feeds_6'];
        
        // Update specific columns and keep other values intact
        $physio_morning = isset($_POST['physio_morning']) ? ($_POST['physio_morning'] ? 1 : $existing_physio_morning) : $existing_physio_morning;
        $physio_evening = isset($_POST['physio_evening']) ? ($_POST['physio_evening'] ? 1 : $existing_physio_evening) : $existing_physio_evening;
        $bedpositions_1 = isset($_POST['bedpositions_1']) ? ($_POST['bedpositions_1'] ? 1 : $existing_bedpositions_1) : $existing_bedpositions_1;
        $bedpositions_2 = isset($_POST['bedpositions_2']) ? ($_POST['bedpositions_2'] ? 1 : $existing_bedpositions_2) : $existing_bedpositions_2;
        $bedpositions_3 = isset($_POST['bedpositions_3']) ? ($_POST['bedpositions_3'] ? 1 : $existing_bedpositions_3) : $existing_bedpositions_3;
        $bedpositions_4 = isset($_POST['bedpositions_4']) ? ($_POST['bedpositions_4'] ? 1 : $existing_bedpositions_4) : $existing_bedpositions_4;
        $bedsores_1 = isset($_POST['bedsores_1']) ? ($_POST['bedsores_1'] ? 1 : $existing_bedsores_1) : $existing_bedsores_1;
        $bedsores_2 = isset($_POST['bedsores_2']) ? ($_POST['bedsores_2'] ? 1 : $existing_bedsores_2) : $existing_bedsores_2;
        $feeds_1 = isset($_POST['feeds_1']) ? ($_POST['feeds_1'] ? 1 : $existing_feeds_1) : $existing_feeds_1;
        $feeds_2 = isset($_POST['feeds_2']) ? ($_POST['feeds_2'] ? 1 : $existing_feeds_2) : $existing_feeds_2;
        $feeds_3 = isset($_POST['feeds_3']) ? ($_POST['feeds_3'] ? 1 : $existing_feeds_3) : $existing_feeds_3;

        // Adding feeds_4, feeds_5, and feeds_6 columns
        $feeds_4 = isset($_POST['feeds_4']) ? ($_POST['feeds_4'] ? 1 : $existing_feeds_4) : $existing_feeds_4;
        $feeds_5 = isset($_POST['feeds_5']) ? ($_POST['feeds_5'] ? 1 : $existing_feeds_5) : $existing_feeds_5; // Change here to save false as 0
        $feeds_6 = isset($_POST['feeds_6']) ? ($_POST['feeds_6'] ? 1 : $existing_feeds_6) : $existing_feeds_6;

        // Calculate total count
        $total_count = $physio_morning + $physio_evening + $bedpositions_1 + $bedpositions_2 + $bedpositions_3 + $bedpositions_4 + $bedsores_1 + $bedsores_2 + $feeds_1 + $feeds_2 + $feeds_3+ $feeds_4 + $feeds_5 + $feeds_6;

         // Set status for new record
         $status = $total_count > 0 ? 'completed' : 'not_completed';

        // Update the record with the new values
        $stmt_update = $conn->prepare("UPDATE patient_records SET physio_morning = ?, physio_evening = ?, bedpositions_1 = ?, bedpositions_2 = ?, bedpositions_3 = ?, bedpositions_4 = ?, bedsores_1 = ?, bedsores_2 = ?, feeds_1 = ?, feeds_2 = ?, feeds_3 = ?, feeds_4 = ?, feeds_5 = ?, feeds_6 = ?, total_count = ?, status = ? WHERE hospital_id = ? AND day = ? AND month_name = ? AND year = ?");

        $stmt_update->bind_param("iiiiiiiiiiiiiiissisi", $physio_morning, $physio_evening, $bedpositions_1, $bedpositions_2, $bedpositions_3, $bedpositions_4, $bedsores_1, $bedsores_2, $feeds_1, $feeds_2, $feeds_3, $feeds_4, $feeds_5, $feeds_6, $total_count, $status, $hospital_id, $day, $month_name, $year);

        if ($stmt_update->execute()) {
            $response = array("status" => "success", "message" => "Data updated successfully");
        } else {
            $response = array("status" => "error", "message" => "Error updating data: " . $stmt_update->error);
        }

        $stmt_update->close();
    } else {
        // If the record doesn't exist, insert a new one
        // Extract other values from JSON with isset checks, initializing to 0 if not provided
        $physio_morning = isset($_POST['physio_morning']) ? ($_POST['physio_morning'] ? 1 : 0) : 0;
        $physio_evening = isset($_POST['physio_evening']) ? ($_POST['physio_evening'] ? 1 : 0) : 0;
        $bedpositions_1 = isset($_POST['bedpositions_1']) ? ($_POST['bedpositions_1'] ? 1 : 0) : 0;
        $bedpositions_2 = isset($_POST['bedpositions_2']) ? ($_POST['bedpositions_2'] ? 1 : 0) : 0;
        $bedpositions_3 = isset($_POST['bedpositions_3']) ? ($_POST['bedpositions_3'] ? 1 : 0) : 0;
        $bedpositions_4 = isset($_POST['bedpositions_4']) ? ($_POST['bedpositions_4'] ? 1 : 0) : 0;
        $bedsores_1 = isset($_POST['bedsores_1']) ? ($_POST['bedsores_1'] ? 1 : 0) : 0;
        $bedsores_2 = isset($_POST['bedsores_2']) ? ($_POST['bedsores_2'] ? 1 : 0) : 0;
        $feeds_1 = isset($_POST['feeds_1']) ? ($_POST['feeds_1'] ? 1 : 0) : 0;
        $feeds_2 = isset($_POST['feeds_2']) ? ($_POST['feeds_2'] ? 1 : 0) : 0;
        $feeds_3 = isset($_POST['feeds_3']) ? ($_POST['feeds_3'] ? 1 : 0) : 0;

        // Adding feeds_4, feeds_5, and feeds_6 columns for new record
        $feeds_4 = isset($_POST['feeds_4']) ? ($_POST['feeds_4'] ? 1 : 0) : 0;
        $feeds_5 = isset($_POST['feeds_5']) ? ($_POST['feeds_5'] ? 1 : 0) : 0; // Change here to save false as 0
        $feeds_6 = isset($_POST['feeds_6']) ? ($_POST['feeds_6'] ? 1 : 0) : 0;

        // Calculate total count for new record
        $total_count = $physio_morning + $physio_evening + $bedpositions_1 + $bedpositions_2 + $bedpositions_3 + $bedpositions_4 + $bedsores_1 + $bedsores_2 + $feeds_1 + $feeds_2 + $feeds_3+ $feeds_4 + $feeds_5 + $feeds_6;
        
        $status = $total_count > 0 ? 'completed' : 'not_completed';
        // Insert new record
        $stmt_insert = $conn->prepare("INSERT INTO patient_records (hospital_id, physio_morning, physio_evening, bedpositions_1, bedpositions_2, bedpositions_3, bedpositions_4, bedsores_1, bedsores_2, feeds_1, feeds_2, feeds_3, feeds_4, feeds_5, feeds_6, total_count, status, day, month_name, year) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        
        $stmt_insert->bind_param("siiiiiiiiiiiiiiisisi", $hospital_id, $physio_morning, $physio_evening, $bedpositions_1, $bedpositions_2, $bedpositions_3, $bedpositions_4, $bedsores_1, $bedsores_2, $feeds_1, $feeds_2, $feeds_3, $feeds_4, $feeds_5, $feeds_6, $total_count, $status, $day, $month_name, $year);

        if ($stmt_insert->execute()) {
            $response = array("status" => "success", "message" => "Data inserted successfully", "status" => $status); // Include status in the response
        } else {
            $response = array("status" => "error", "message" => "Error inserting  " . $stmt_insert->error);
        }

        $stmt_insert->close();
    }

    // Close statement for checking existing record
    $stmt_check_existing->close();

    // Send JSON response back to the client
    header('Content-Type: application/json');
    echo json_encode($response);

} else {
    // If the request method is not POST, return an error response
    header('Content-Type: application/json');
    echo json_encode(array("status" => "error", "message" => "Invalid request method"));
}

$conn->close(); // Close the MySQL connection

?>
