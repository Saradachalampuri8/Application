<?php

header("Content-Type: application/json");

require 'conn.php';

// Check if 'id' is provided in the request
if(isset($_GET['id'])) {
    $id = $_GET['id'];
    
    // Prepare the SQL query with a WHERE clause to filter by 'id'
    $sql = "SELECT `id`, `name`, `hospital_id`, `age`, `gender`, `mobile_number`, `diagnosis`, 
            `patient_status_rul`, `patient_status_lul`, `patient_status_rll`, `patient_status_lll`, 
            `mri` FROM `patients` WHERE `id` = $id";
    
    $result = $conn->query($sql);

    if ($result) {
        $data = array();
        while ($row = $result->fetch_assoc()) {
            // Replace encoded link with the actual file path
            $row['mri'] = $row['mri'] ? 'http://localhost/php/' . $row['mri'] : '';

            $data[] = $row;
        }

        $response = array('status' => 'success', 'message' => 'Data retrieved successfully', 'data' => $data);
        echo json_encode($response);
    } else {
        $response = array('status' => 'failure', 'message' => 'Error retrieving data: ' . $conn->error);
        echo json_encode($response);
    }
} else {
    $response = array('status' => 'failure', 'message' => 'No ID provided');
    echo json_encode($response);
}

$conn->close();

?>
