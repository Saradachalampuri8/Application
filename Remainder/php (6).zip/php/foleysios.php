<?php

include 'conn.php'; // Include the database connection file

// Initialize response array
$response = array();

// Check if the required keys exist in the $_POST array
if(isset($_POST['hospital_id']) && isset($_POST['foleys_date'])) {
    // Extract hospital_id and ryles_date from the form data
    $hospital_id = $_POST['hospital_id'];
    $foleys_date = $_POST['foleys_date']; // Assuming 'ryles_date' is in Y-m-d format
    
    // Get the current date
    $current_date = date('Y-m-d');

    // Extract month and year from the current date
    $current_month_year = date('Y-m', strtotime($current_date));

    // Check if there's already a record for the given hospital_id and current month and year
    $query_check_existing = "SELECT * FROM foleys_ryles WHERE hospital_id = '$hospital_id' AND DATE_FORMAT(date, '%Y-%m') = '$current_month_year'";
    $result_check_existing = $conn->query($query_check_existing);

    if ($result_check_existing) {
        if ($result_check_existing->num_rows > 0) {
            // Records exist for the given hospital_id and current month and year
            // Check if the provided ryles_date matches any existing data for the same month and year
            $foleys_date_exists = false;
            while ($row = $result_check_existing->fetch_assoc()) {
                // Check if the provided ryles_date matches any existing data for this month and year
                if ($row['foleys'] == $foleys_date || substr($row['foleys'], 0, 7) == $current_month_year) {
                    // Provided Foleys date matches an existing record for this month and year
                    $foleys_date_exists = true;
                    break; // No need to check further, exit the loop
                }
            }
            
            if ($foleys_date_exists) {
                $response['status'] = 'error';
                $response['message'] = "Provided Foleys date matches an existing record for this month and year";
            } else {
                // Update the 'foleys' column with the provided date
                $update_sql = "UPDATE foleys_ryles SET foleys = '$foleys_date' WHERE hospital_id = '$hospital_id' AND DATE_FORMAT(date, '%Y-%m') = '$current_month_year'";
                if ($conn->query($update_sql) === TRUE) {
                    $response['status'] = 'success';
                    $response['message'] = "Record updated successfully";
                } else {
                    $response['status'] = 'error';
                    $response['message'] = "Error updating record: " . $conn->error;
                }
            }
        } else {
            // No record found for the given hospital_id and current month and year, insert new record with current date
            $insert_sql = "INSERT INTO foleys_ryles (hospital_id, foleys, date) VALUES ('$hospital_id', '$foleys_date', '$current_date')";
            if ($conn->query($insert_sql) === TRUE) {
                $response['status'] = 'success';
                $response['message'] = "New record inserted successfully";
            } else {
                $response['status'] = 'error';
                $response['message'] = "Error inserting new record: " . $conn->error;
            }
        }
    } else {
        $response['status'] = 'error';
        $response['message'] = "Error checking existing records: " . $conn->error;
    }

} else {
    $response['status'] = 'error';
    $response['message'] = "Incomplete or invalid data received for Foleys update";
}

// Convert the response array to JSON format
echo json_encode($response);

// Close the connection
$conn->close();

?>
