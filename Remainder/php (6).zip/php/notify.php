<?php
// Connect to MySQL database
require "conn.php";

// Initialize response array
$response = array();

// Check connection
if ($conn->connect_error) {
    $response['status'] = "error";
    $response['message'] = "Connection failed: " . $conn->connect_error;
} else {
    // Assuming hospital_id is provided via POST method, you can retrieve it like this
    if(isset($_POST['hospital_id']) && !empty($_POST['hospital_id'])){
        $hospital_id = $_POST['hospital_id'];

        // Prepare and execute SQL statement to check if hospital_id exists in plogin table
        $stmt = $conn->prepare("SELECT * FROM plogin WHERE hospital_id = ?");
        $stmt->bind_param("s", $hospital_id);
        $stmt->execute();
        $result = $stmt->get_result();

        // If hospital_id exists in plogin table
        if ($result->num_rows > 0) {
            // Fetch notifications for the given hospital_id
            $sql = "SELECT * FROM notify";
            $result_notify = $conn->query($sql);

            if ($result_notify->num_rows > 0) {
                $notify = array();
                while ($row = $result_notify->fetch_assoc()) {
                    $notify[] = $row;
                }
                // Set response fields
                $response['status'] = "success";
                $response['message'] = "Notifications fetched successfully";
                $response['data'] = $notify;
            } else {
                // If no notifications found
                $response['status'] = "error";
                $response['message'] = "No notifications found";
                $response['data'] = array();
            }
        } else {
            // If hospital_id does not exist in plogin table
            $response['status'] = "error";
            $response['message'] = "Hospital ID not found ";
            $response['data'] = array();
        }
        // Close statement
        $stmt->close();
    } else {
        // If hospital_id is not provided or empty
        $response['status'] = "error";
        $response['message'] = "Hospital ID is missing or empty";
        $response['data'] = array();
    }
    // Close connection
    $conn->close();
}

// Return response as JSON
echo json_encode($response);
?>
