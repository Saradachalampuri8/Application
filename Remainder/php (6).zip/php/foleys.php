<?php

include 'conn.php'; // Include the database connection file

// Get the data from the POST request
$_POST = json_decode(file_get_contents("php://input"), true);

// Check if the required keys exist in the $_POST array
if(isset($_POST['hospital_id'], $_POST['foleys'])) {
    // Extract hospital_id and foleys from the data
    $hospital_id = $_POST['hospital_id'];
    $foleys = $_POST['foleys'];

    // Query to fetch the current value of the foleys column for the given hospital_id
    $query = "SELECT foleys FROM foleys_ryles WHERE hospital_id = '$hospital_id'";
    $result = $conn->query($query);

    if ($result) {
        // Fetch the result row
        $row = $result->fetch_assoc();
        if ($row) {
            // Extract the month part from the current foleys
            $prev_month = date('m', strtotime($row['foleys']));
            // Extract the month part from the new foleys
            $new_month = date('m', strtotime($foleys));
            // Check if the months are different
            if ($prev_month != $new_month) {
                // Update the ryles column
                $update_sql = "UPDATE foleys_ryles SET foleys = '$foleys' WHERE hospital_id = '$hospital_id'";
                if ($conn->query($update_sql) === TRUE) {
                    echo "Rylev column updated successfully for hospital with ID: $hospital_id";
                } else {
                    echo "Error updating foleys column: " . $conn->error;
                }
            } else {
                echo "foleys column for hospital with ID: $hospital_id already contains the same month";
            }
        } else {
            // If no row found, insert a new row
            $insert_sql = "INSERT INTO foleys_ryles (hospital_id, foleys) VALUES ('$hospital_id', '$foleys')";
            if ($conn->query($insert_sql) === TRUE) {
                echo "New record inserted successfully for hospital with ID: $hospital_id";
            } else {
                echo "Error inserting new record: " . $conn->error;
            }
        }
    } else {
        echo "Error fetching current value of foleys column: " . $conn->error;
    }

} else {
    echo "Incomplete or invalid data received for foleys update";
}

// Close the connection
$conn->close();

?>
