<?php

require_once('conn.php');

if ($conn->connect_error) {
    $response = [
        'status' => false,
        'message' => 'Database connection error'
    ];
    echo json_encode($response);
    exit();
}

// Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if the file is uploaded
    if (isset($_FILES['video_file'])) {
        // Use the original filename for the video in the uploads folder
        $upload_folder = 'uploads/videos/';
        $video_filename = $_FILES['video_file']['name'];
        $upload_path = $upload_folder . $video_filename;

        // Check if the video already exists in the database
        $check_sql = "SELECT * FROM videos WHERE video_url = ?";
        $check_stmt = $conn->prepare($check_sql);

        if ($check_stmt) {
            $check_stmt->bind_param("s", $upload_path);
            $check_stmt->execute();
            $check_result = $check_stmt->get_result();

            if ($check_result->num_rows > 0) {
                // Video already exists
                $response = [
                    'status' => false,
                    'message' => 'Video already exists in the database'
                    
                ];
            } else {
                // Move the uploaded video to the uploads folder
                if (move_uploaded_file($_FILES['video_file']['tmp_name'], $upload_path)) {
                    // Insert the video information into the database
                    $insert_sql = "INSERT INTO videos (video_url) VALUES (?)";
                    $insert_stmt = $conn->prepare($insert_sql);

                    if ($insert_stmt) {
                        $insert_stmt->bind_param("s", $upload_path);
                        $insert_result = $insert_stmt->execute();

                        if ($insert_result) {
                            $response = [
                                'status' => true,
                                'message' => 'Video uploaded successfully'
                            ];
                        } else {
                            $response = [
                                'status' => false,
                                'message' => 'Error uploading video to database'
                            ];
                        }

                        $insert_stmt->close();
                    } else {
                        // Log the error for development purposes
                        error_log("Error preparing SQL statement: " . $conn->error);

                        $response = [
                            'status' => false,
                            'message' => 'Internal server error'
                        ];
                    }
                } else {
                    $response = [
                        'status' => false,
                        'message' => 'Error uploading video to server'
                    ];
                }
            }

            $check_stmt->close();
        } else {
            // Log the error for development purposes
            error_log("Error preparing SQL statement: " . $conn->error);

            $response = [
                'status' => false,
                'message' => 'Internal server error'
            ];
        }
    } else {
        $response = [
            'status' => false,
            'message' => 'No file uploaded'
        ];
    }
} else {
    $response = [
        'status' => false,
        'message' => 'Invalid request method'
    ];
}

$conn->close();

// Return JSON response
header('Content-Type: application/json');
echo json_encode($response);

?>
