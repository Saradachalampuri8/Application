<?php

require("conn.php"); // Include your database connection code

// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // Read JSON data from the request body
    $inputJSON = file_get_contents('php://input');
    $_POST = json_decode($inputJSON, true);

    // Extracting values from JSON with isset checks
    $hospital_id = isset($_POST['hospital_id']) ? $_POST['hospital_id'] : null;

    // Check if hospital_id is null or empty
    if (empty($hospital_id)) {
        // Return error response if hospital_id is null or empty
        header('Content-Type: application/json');
        echo json_encode(array("status" => "error", "message" => "hospital_id cannot be null or empty"));
        exit; // Terminate script execution
    }

    $physio_morning = isset($_POST['physio_morning']) ? (intval($_POST['physio_morning']) ? 1 : 0) : null;
    $physio_evening = isset($_POST['physio_evening']) ? (intval($_POST['physio_evening']) ? 1 : 0) : null;

  // Calculate total_count based on the sum of boolean values
 $total_count = $physio_morning + $physio_evening + $bedpositions_1 + $bedpositions_2 + $bedpositions_3 + $bedpositions_4 + $bedsores_1 + $bedsores_2 + $feeds_1 + $feeds_2 + $feeds_3;

    // Get the current date
    $day = date('d');
    $month_name = date('F');
    $year = date('Y');

    // Check if a record with the given hospital_id, day, month_name, and year already exists
    $stmt_check_existing = $conn->prepare("SELECT * FROM patient_records WHERE hospital_id = ? AND day = ? AND month_name = ? AND year = ?");
    $stmt_check_existing->bind_param("siss", $hospital_id, $day, $month_name, $year);
    $stmt_check_existing->execute();
    $result = $stmt_check_existing->get_result();

    if ($result->num_rows > 0) {
        // Update existing record
        $stmt_update = $conn->prepare("UPDATE patient_records SET physio_morning = COALESCE(?, physio_morning), physio_evening = COALESCE(?, physio_evening), total_count = physio_morning + physio_evening, status = CASE WHEN ? OR ? THEN 'completed' ELSE 'pending' END WHERE hospital_id = ? AND day = ? AND month_name = ? AND year = ?");
        $stmt_update->bind_param("iiiiissi", $physio_morning, $physio_evening, $physio_morning, $physio_evening, $hospital_id, $day, $month_name, $year);

        if ($stmt_update->execute()) {
            $response = array("status" => "success", "message" => "Data updated successfully");
        } else {
            $response = array("status" => "error", "message" => "Error updating data: " . $stmt_update->error);
        }

        $stmt_update->close();
    } else {
        // Insert new record
        $status = ($physio_morning == 1 || $physio_evening == 1  || $bedpositions_1 == 1|| $bedpositions_2 == 1|| $bedpositions_3 == 1|| $bedpositions_4== 1 || $bedsores_1 == 1|| $bedsores_2 == 1|| $feeds_1== 1 || $feeds_2== 1 || $feeds_3 == 1) ? 'completed' : 'pending';

        $stmt_insert = $conn->prepare("INSERT INTO patient_records (hospital_id, physio_morning, physio_evening, total_count, status, day, month_name, year) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt_insert->bind_param("siiisiss", $hospital_id, $physio_morning, $physio_evening, $total_count, $status, $day, $month_name, $year);

        if ($stmt_insert->execute()) {
            $response = array("status" => "success", "message" => "Data inserted successfully");
        } else {
            $response = array("status" => "error", "message" => "Error inserting data: " . $stmt_insert->error);
        }

        $stmt_insert->close();
    }

    // Close statement for checking existing record
    $stmt_check_existing->close();

    // Send JSON response back to the client
    header('Content-Type: application/json');
    echo json_encode($response);

} else {
    // If the request method is not POST, return an error response
    header('Content-Type: application/json');
    echo json_encode(array("status" => "error", "message" => "Invalid request method"));
}

?>
