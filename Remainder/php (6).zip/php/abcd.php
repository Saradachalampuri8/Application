<?php
require_once('conn.php');

// Set the desired time zone to Indian Standard Time (IST)
date_default_timezone_set('Asia/Kolkata');


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the data from the POST body
    // $postData = json_decode(file_get_contents('php://input'), true);


// Get current date and time
$currentDate = date("d");
$currentMonth = date("F");
$currentYear = date("Y");
$currentHour = date("H"); // Hour in 24-hour format
$currentMinute = date("i"); // Minutes

// Initialize an empty array to hold the results
$output = array();

// Debug information
$output[] = array("current_date" => $currentDate, "current_month" => $currentMonth, "current_year" => $currentYear, "current_hour" => $currentHour, "current_minute" => $currentMinute);

// Check if the current time is 1:05 AM and physio_morning is not completed
if ($currentHour == 1 && $currentMinute == 5) {
    // Fetch data from patient_records table
    $sql = "SELECT hospital_id, physio_morning FROM patient_records WHERE day = '$currentDate' AND month_name = '$currentMonth' AND year = '$currentYear'";
    $result = $conn->query($sql);

    // Check for errors
    if (!$result) {
        die("Error: " . $conn->error);
    }

    // Check if there are any records for the current date
    if ($result->num_rows > 0) {
        // Fetch each row
        while($row = $result->fetch_assoc()) {
            $hospitalId = $row["hospital_id"];
            $physioMorning = $row["physio_morning"];

            // Check if physio_morning is not completed
            if ($physioMorning != 1) {
                $notification = "It's time for morning physiotherapy task.";

                // Insert notification into the database
                $insert_sql = "INSERT INTO notification (hospital_id, notification) VALUES ('$hospitalId', '$notification')";
                if ($conn->query($insert_sql) === TRUE) {
                    // Record inserted successfully
                    $output[] = array("hospital_id" => $hospitalId, "notification" => $notification);
                } else {
                    // Error inserting record
                    die("Error: " . $conn->error);
                }
            }
        }
    } else {
        // If no records found for the current date, insert a notification for each hospital ID
        $no_record_notification = "It's time for morning physiotherapy task.";
        $no_record_insert_sql = "INSERT INTO notification (hospital_id, notification) SELECT DISTINCT hospital_id, '" . $conn->real_escape_string($no_record_notification) . "' FROM patient_records";
        if ($conn->query($no_record_insert_sql) === TRUE) {
            // Records inserted successfully
            $output[] = array("notification" => "No records found for the current date. Notifications inserted for all hospital IDs.");
        } else {
            // Error inserting records
            die("Error: " . $conn->error);
        }
    }
}
// Check if the current time is 4:05 AM and physio_evening is not completed
if ($currentHour == 12 && $currentMinute == 23 ) {
    // Fetch data from patient_records table
    $sql = "SELECT hospital_id, physio_evening FROM patient_records WHERE day = '$currentDate' AND month_name = '$currentMonth' AND year = '$currentYear'";
    $result = $conn->query($sql);

    // Check for errors
    if (!$result) {
        die("Error: " . $conn->error);
    }

    // Check if there are any records for the current date
    if ($result->num_rows > 0) {
        // Fetch each row
        while($row = $result->fetch_assoc()) {
            $hospitalId = $row["hospital_id"];
            $physioEvening = $row["physio_evening"];

            // Check if physio_evening is not completed
            if ($physioEvening != 1) {
                $notification = "It's time for evening physiotherapy task.";

                // Insert notification into the database
                $insert_sql = "INSERT INTO notification (hospital_id, notification) VALUES ('$hospitalId', '$notification')";
                if ($conn->query($insert_sql) === TRUE) {
                    // Record inserted successfully
                    $output[] = array("hospital_id" => $hospitalId, "notification" => $notification);
                } else {
                    // Error inserting record
                    die("Error: " . $conn->error);
                }
            }
        }
    } else {
        // If no records found for the current date, insert a notification for each hospital ID
        $no_record_notification = "It's time for evening physiotherapy task.";
        $no_record_insert_sql = "INSERT INTO notification (hospital_id, notification) SELECT DISTINCT hospital_id, '" . $conn->real_escape_string($no_record_notification) . "' FROM patient_records";
        if ($conn->query($no_record_insert_sql) === TRUE) {
            // Records inserted successfully
            $output[] = array("notification" => "No records found for the current date. Notifications inserted for all hospital IDs.");
        } else {
            // Error inserting records
            die("Error: " . $conn->error);
        }
    }
}

// Check if the current time is 4:05 AM and bedpositions_1 is not completed
if ($currentHour == 13 && $currentMinute == 35 ) {
    // Fetch data from patient_records table
    $sql = "SELECT hospital_id, bedpositions_1 FROM patient_records WHERE day = '$currentDate' AND month_name = '$currentMonth' AND year = '$currentYear'";
    $result = $conn->query($sql);

    // Check for errors
    if (!$result) {
        die("Error: " . $conn->error);
    }

    // Check if there are any records for the current date
    if ($result->num_rows > 0) {
        // Fetch each row
        while($row = $result->fetch_assoc()) {
            $hospitalId = $row["hospital_id"];
            $bedpositions_1 = $row["bedpositions_1"];

            // Check if physio_evening is not completed
            if ($bedpositions_1 != 1) {
                $notification = "It's time for change bed positions1 task.";

                // Insert notification into the database
                $insert_sql = "INSERT INTO notification (hospital_id, notification) VALUES ('$hospitalId', '$notification')";
                if ($conn->query($insert_sql) === TRUE) {
                    // Record inserted successfully
                    $output[] = array("hospital_id" => $hospitalId, "notification" => $notification);
                } else {
                    // Error inserting record
                    die("Error: " . $conn->error);
                }
            }
        }
    } else {
        // If no records found for the current date, insert a notification for each hospital ID
        $no_record_notification = "It's time for change bed positions1 task.";
        $no_record_insert_sql = "INSERT INTO notification (hospital_id, notification) SELECT DISTINCT hospital_id, '" . $conn->real_escape_string($no_record_notification) . "' FROM patient_records";
        if ($conn->query($no_record_insert_sql) === TRUE) {
            // Records inserted successfully
            $output[] = array("notification" => "No records found for the current date. Notifications inserted for all hospital IDs.");
        } else {
            // Error inserting records
            die("Error: " . $conn->error);
        }
    }
}

// Check if the current time is 4:05 AM and bedpositions_2 is not completed
if ($currentHour == 13 && $currentMinute == 40 ) {
    // Fetch data from patient_records table
    $sql = "SELECT hospital_id, bedpositions_2 FROM patient_records WHERE day = '$currentDate' AND month_name = '$currentMonth' AND year = '$currentYear'";
    $result = $conn->query($sql);

    // Check for errors
    if (!$result) {
        die("Error: " . $conn->error);
    }

    // Check if there are any records for the current date
    if ($result->num_rows > 0) {
        // Fetch each row
        while($row = $result->fetch_assoc()) {
            $hospitalId = $row["hospital_id"];
            $bedpositions_2 = $row["bedpositions_2"];

            // Check if physio_evening is not completed
            if ($bedpositions_2 != 1) {
                $notification = "It's time for change bed positions2 task.";

                // Insert notification into the database
                $insert_sql = "INSERT INTO notification (hospital_id, notification) VALUES ('$hospitalId', '$notification')";
                if ($conn->query($insert_sql) === TRUE) {
                    // Record inserted successfully
                    $output[] = array("hospital_id" => $hospitalId, "notification" => $notification);
                } else {
                    // Error inserting record
                    die("Error: " . $conn->error);
                }
            }
        }
    } else {
        // If no records found for the current date, insert a notification for each hospital ID
        $no_record_notification = "It's time for change bed positions 2 task.";
        $no_record_insert_sql = "INSERT INTO notification (hospital_id, notification) SELECT DISTINCT hospital_id, '" . $conn->real_escape_string($no_record_notification) . "' FROM patient_records";
        if ($conn->query($no_record_insert_sql) === TRUE) {
            // Records inserted successfully
            $output[] = array("notification" => "No records found for the current date. Notifications inserted for all hospital IDs.");
        } else {
            // Error inserting records
            die("Error: " . $conn->error);
        }
    }
}

// Check if the current time is 4:05 AM and bedpositions_1 is not completed
if ($currentHour == 13 && $currentMinute == 42 ) {
    // Fetch data from patient_records table
    $sql = "SELECT hospital_id, bedpositions_3 FROM patient_records WHERE day = '$currentDate' AND month_name = '$currentMonth' AND year = '$currentYear'";
    $result = $conn->query($sql);

    // Check for errors
    if (!$result) {
        die("Error: " . $conn->error);
    }

    // Check if there are any records for the current date
    if ($result->num_rows > 0) {
        // Fetch each row
        while($row = $result->fetch_assoc()) {
            $hospitalId = $row["hospital_id"];
            $bedpositions_3 = $row["bedpositions_3"];

            // Check if physio_evening is not completed
            if ($bedpositions_1 != 1) {
                $notification = "It's time for change bed positions3 task.";

                // Insert notification into the database
                $insert_sql = "INSERT INTO notification (hospital_id, notification) VALUES ('$hospitalId', '$notification')";
                if ($conn->query($insert_sql) === TRUE) {
                    // Record inserted successfully
                    $output[] = array("hospital_id" => $hospitalId, "notification" => $notification);
                } else {
                    // Error inserting record
                    die("Error: " . $conn->error);
                }
            }
        }
    } else {
        // If no records found for the current date, insert a notification for each hospital ID
        $no_record_notification = "It's time for change bed positions3 task.";
        $no_record_insert_sql = "INSERT INTO notification (hospital_id, notification) SELECT DISTINCT hospital_id, '" . $conn->real_escape_string($no_record_notification) . "' FROM patient_records";
        if ($conn->query($no_record_insert_sql) === TRUE) {
            // Records inserted successfully
            $output[] = array("notification" => "No records found for the current date. Notifications inserted for all hospital IDs.");
        } else {
            // Error inserting records
            die("Error: " . $conn->error);
        }
    }
}
// Check if the current time is 4:05 AM and bedpositions_4 is not completed
if ($currentHour == 13 && $currentMinute == 43 ) {
    // Fetch data from patient_records table
    $sql = "SELECT hospital_id, bedpositions_4 FROM patient_records WHERE day = '$currentDate' AND month_name = '$currentMonth' AND year = '$currentYear'";
    $result = $conn->query($sql);

    // Check for errors
    if (!$result) {
        die("Error: " . $conn->error);
    }

    // Check if there are any records for the current date
    if ($result->num_rows > 0) {
        // Fetch each row
        while($row = $result->fetch_assoc()) {
            $hospitalId = $row["hospital_id"];
            $bedpositions_1 = $row["bedpositions_4"];

            // Check if physio_evening is not completed
            if ($bedpositions_1 != 1) {
                $notification = "It's time for change bed positions task.";

                // Insert notification into the database
                $insert_sql = "INSERT INTO notification (hospital_id, notification) VALUES ('$hospitalId', '$notification')";
                if ($conn->query($insert_sql) === TRUE) {
                    // Record inserted successfully
                    $output[] = array("hospital_id" => $hospitalId, "notification" => $notification);
                } else {
                    // Error inserting record
                    die("Error: " . $conn->error);
                }
            }
        }
    } else {
        // If no records found for the current date, insert a notification for each hospital ID
        $no_record_notification = "It's time for change bed positions4 task.";
        $no_record_insert_sql = "INSERT INTO notification (hospital_id, notification) SELECT DISTINCT hospital_id, '" . $conn->real_escape_string($no_record_notification) . "' FROM patient_records";
        if ($conn->query($no_record_insert_sql) === TRUE) {
            // Records inserted successfully
            $output[] = array("notification" => "No records found for the current date. Notifications inserted for all hospital IDs.");
        } else {
            // Error inserting records
            die("Error: " . $conn->error);
        }
    }
}

// Check if the current time is 4:05 AM and bedsores_1 is not completed
if ($currentHour == 15 && $currentMinute == 33 ) {
    // Fetch data from patient_records table
    $sql = "SELECT hospital_id, bedsores_1 FROM patient_records WHERE day = '$currentDate' AND month_name = '$currentMonth' AND year = '$currentYear'";
    $result = $conn->query($sql);

    // Check for errors
    if (!$result) {
        die("Error: " . $conn->error);
    }

    // Check if there are any records for the current date
    if ($result->num_rows > 0) {
        // Fetch each row
        while($row = $result->fetch_assoc()) {
            $hospitalId = $row["hospital_id"];
            $bedsores_1 = $row["bedsores_1"];

            // Check if physio_evening is not completed
            if ($bedsores_1 != 1) {
                $notification = "It's time for bedsores_1 task.";

                // Insert notification into the database
                $insert_sql = "INSERT INTO notification (hospital_id, notification) VALUES ('$hospitalId', '$notification')";
                if ($conn->query($insert_sql) === TRUE) {
                    // Record inserted successfully
                    $output[] = array("hospital_id" => $hospitalId, "notification" => $notification);
                } else {
                    // Error inserting record
                    die("Error: " . $conn->error);
                }
            }
        }
    } else {
        // If no records found for the current date, insert a notification for each hospital ID
        $no_record_notification = "It's time for bedsores_1 task.";
        $no_record_insert_sql = "INSERT INTO notification (hospital_id, notification) SELECT DISTINCT hospital_id, '" . $conn->real_escape_string($no_record_notification) . "' FROM patient_records";
        if ($conn->query($no_record_insert_sql) === TRUE) {
            // Records inserted successfully
            $output[] = array("notification" => "No records found for the current date. Notifications inserted for all hospital IDs.");
        } else {
            // Error inserting records
            die("Error: " . $conn->error);
        }
    }
}

// Check if the current time is 4:05 AM and bedsores_1 is not completed
if ($currentHour == 15 && $currentMinute == 36 ) {
    // Fetch data from patient_records table
    $sql = "SELECT hospital_id, bedsores_2 FROM patient_records WHERE day = '$currentDate' AND month_name = '$currentMonth' AND year = '$currentYear'";
    $result = $conn->query($sql);

    // Check for errors
    if (!$result) {
        die("Error: " . $conn->error);
    }

    // Check if there are any records for the current date
    if ($result->num_rows > 0) {
        // Fetch each row
        while($row = $result->fetch_assoc()) {
            $hospitalId = $row["hospital_id"];
            $bedsores_2 = $row["bedsores_2"];

            // Check if physio_evening is not completed
            if ($bedsores_2 != 1) {
                $notification = "It's time for bedsores_2 task.";

                // Insert notification into the database
                $insert_sql = "INSERT INTO notification (hospital_id, notification) VALUES ('$hospitalId', '$notification')";
                if ($conn->query($insert_sql) === TRUE) {
                    // Record inserted successfully
                    $output[] = array("hospital_id" => $hospitalId, "notification" => $notification);
                } else {
                    // Error inserting record
                    die("Error: " . $conn->error);
                }
            }
        }
    } else {
        // If no records found for the current date, insert a notification for each hospital ID
        $no_record_notification = "It's time for bedsores 2 task.";
        $no_record_insert_sql = "INSERT INTO notification (hospital_id, notification) SELECT DISTINCT hospital_id, '" . $conn->real_escape_string($no_record_notification) . "' FROM patient_records";
        if ($conn->query($no_record_insert_sql) === TRUE) {
            // Records inserted successfully
            $output[] = array("notification" => "No records found for the current date. Notifications inserted for all hospital IDs.");
        } else {
            // Error inserting records
            die("Error: " . $conn->error);
        }
    }
}

// Check if the current time is 4:05 AM and feeds_1 is not completed
if ($currentHour == 15 && $currentMinute == 37 ) {
    // Fetch data from patient_records table
    $sql = "SELECT hospital_id, feeds_1 FROM patient_records WHERE day = '$currentDate' AND month_name = '$currentMonth' AND year = '$currentYear'";
    $result = $conn->query($sql);

    // Check for errors
    if (!$result) {
        die("Error: " . $conn->error);
    }

    // Check if there are any records for the current date
    if ($result->num_rows > 0) {
        // Fetch each row
        while($row = $result->fetch_assoc()) {
            $hospitalId = $row["hospital_id"];
            $feeds_1 = $row["feeds_1"];

            // Check if physio_evening is not completed
            if ($feeds_1 != 1) {
                $notification = "It's time for feeds_1 task.";

                // Insert notification into the database
                $insert_sql = "INSERT INTO notification (hospital_id, notification) VALUES ('$hospitalId', '$notification')";
                if ($conn->query($insert_sql) === TRUE) {
                    // Record inserted successfully
                    $output[] = array("hospital_id" => $hospitalId, "notification" => $notification);
                } else {
                    // Error inserting record
                    die("Error: " . $conn->error);
                }
            }
        }
    } else {
        // If no records found for the current date, insert a notification for each hospital ID
        $no_record_notification = "It's time for feeds_1 task.";
        $no_record_insert_sql = "INSERT INTO notification (hospital_id, notification) SELECT DISTINCT hospital_id, '" . $conn->real_escape_string($no_record_notification) . "' FROM patient_records";
        if ($conn->query($no_record_insert_sql) === TRUE) {
            // Records inserted successfully
            $output[] = array("notification" => "No records found for the current date. Notifications inserted for all hospital IDs.");
        } else {
            // Error inserting records
            die("Error: " . $conn->error);
        }
    }
}


// Check if the current time is 4:05 AM and feeds_2 is not completed
if ($currentHour == 15 && $currentMinute == 47 ) {
    // Fetch data from patient_records table
    $sql = "SELECT hospital_id, feeds_2 FROM patient_records WHERE day = '$currentDate' AND month_name = '$currentMonth' AND year = '$currentYear'";
    $result = $conn->query($sql);

    // Check for errors
    if (!$result) {
        die("Error: " . $conn->error);
    }

    // Check if there are any records for the current date
    if ($result->num_rows > 0) {
        // Fetch each row
        while($row = $result->fetch_assoc()) {
            $hospitalId = $row["hospital_id"];
            $feeds_2 = $row["feeds_2"];

            // Check if physio_evening is not completed
            if ($feeds_2 != 1) {
                $notification = "It's time for feeds_2 task.";

                // Insert notification into the database
                $insert_sql = "INSERT INTO notification (hospital_id, notification) VALUES ('$hospitalId', '$notification')";
                if ($conn->query($insert_sql) === TRUE) {
                    // Record inserted successfully
                    $output[] = array("hospital_id" => $hospitalId, "notification" => $notification);
                } else {
                    // Error inserting record
                    die("Error: " . $conn->error);
                }
            }
        }
    } else {
        // If no records found for the current date, insert a notification for each hospital ID
        $no_record_notification = "It's time for feeds_2 task.";
        $no_record_insert_sql = "INSERT INTO notification (hospital_id, notification) SELECT DISTINCT hospital_id, '" . $conn->real_escape_string($no_record_notification) . "' FROM patient_records";
        if ($conn->query($no_record_insert_sql) === TRUE) {
            // Records inserted successfully
            $output[] = array("notification" => "No records found for the current date. Notifications inserted for all hospital IDs.");
        } else {
            // Error inserting records
            die("Error: " . $conn->error);
        }
    }
}


// Check if the current time is 4:05 AM and feeds_3 is not completed
if ($currentHour == 11 && $currentMinute == 32 ) {
    // Fetch data from patient_records table
    $sql = "SELECT hospital_id, feeds_3 FROM patient_records WHERE day = '$currentDate' AND month_name = '$currentMonth' AND year = '$currentYear'";
    $result = $conn->query($sql);

    // Check for errors
    if (!$result) {
        die("Error: " . $conn->error);
    }

    // Check if there are any records for the current date
    if ($result->num_rows > 0) {
        // Fetch each row
        while($row = $result->fetch_assoc()) {
            $hospitalId = $row["hospital_id"];
            $feeds_3 = $row["feeds_3"];

            // Check if physio_evening is not completed
            if ($feeds_2 != 1) {
                $notification = "It's time for feeds_3 task.";

                // Insert notification into the database
                $insert_sql = "INSERT INTO notification (hospital_id, notification) VALUES ('$hospitalId', '$notification')";
                if ($conn->query($insert_sql) === TRUE) {
                    // Record inserted successfully
                    $output[] = array("hospital_id" => $hospitalId, "notification" => $notification);
                } else {
                    // Error inserting record
                    die("Error: " . $conn->error);
                }
            }
        }
    } else {
        // If no records found for the current date, insert a notification for each hospital ID
        $no_record_notification = "It's time for feeds_3 task.";
        $no_record_insert_sql = "INSERT INTO notification (hospital_id, notification) SELECT DISTINCT hospital_id, '" . $conn->real_escape_string($no_record_notification) . "' FROM patient_records";
        if ($conn->query($no_record_insert_sql) === TRUE) {
            // Records inserted successfully
            $output[] = array("notification" => "No records found for the current date. Notifications inserted for all hospital IDs.");
        } else {
            // Error inserting records
            die("Error: " . $conn->error);
        }
    }
}

    // Fetch data from foleys_ryles table
    $foleysRylesSql = "SELECT hospital_id, MAX(GREATEST(foleys, ryles)) AS recent_date FROM foleys_ryles GROUP BY hospital_id";
    $foleysRylesResult = $conn->query($foleysRylesSql);
    if ($foleysRylesResult) {
        while ($foleysRylesRow = $foleysRylesResult->fetch_assoc()) {
            $hospitalId = $foleysRylesRow['hospital_id'];
            $recentDate = $foleysRylesRow['recent_date'];

            // Calculate the difference in days
            $currentDateTime = new DateTime();
            $recentDateTime = new DateTime($recentDate);
            $interval = $currentDateTime->diff($recentDateTime);
            $daysDifference = $interval->days;

            // If the recent date is more than 30 days ago, add notification
            if ($daysDifference > 30) {
                $notification = "It's time to do foleys and ryles.";

                // Insert notification into the database
                $insert_sql = "INSERT INTO notification (hospital_id, notification) VALUES ('$hospitalId', '" . $conn->real_escape_string($notification) . "')";
                if ($conn->query($insert_sql) === TRUE) {
                    // Record inserted successfully
                    $output[] = array("hospital_id" => $hospitalId, "notification" => $notification);
                } else {
                    // Error inserting record
                    die("Error: " . $conn->error);
                }
            }
        }
    } else {
        // Error fetching data from foleys_ryles table
        die("Error: " . $conn->error);
    }


// // Check if the current time is midnight (00:00) and delete all data from the notification table
if ($currentHour == 0 && $currentMinute == 4) {
    $delete_sql = "TRUNCATE TABLE notification";
    if ($conn->query($delete_sql) === TRUE) {
        // Data deleted successfully
        $output[] = array("notification" => "All data from the notification table deleted.");
    } else {
        // Error deleting data
        die("Error: " . $conn->error);
    }
}


// Close MySQL connection
$conn->close();
// Return the output array as JSON
header('Content-Type: application/json');
// Return the output array as JSON
echo json_encode($output);
} else {
    // If the request method is not POST, return an error message
    echo json_encode(array("error" => "Invalid request method. Only POST requests are allowed."));
}

?>
