<?php
// Include your database connection file
require "conn.php";

// Check if the necessary parameters are provided
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize input data to prevent SQL injection
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $gender = mysqli_real_escape_string($conn, $_POST['gender']);
    $age = intval($_POST['age']);
    $hospital_id = mysqli_real_escape_string($conn, $_POST['hospital_id']);
    $diagnosis = mysqli_real_escape_string($conn, $_POST['diagnosis']);
    $mobile_number = mysqli_real_escape_string($conn, $_POST['mobile_number']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    // Directory to save uploaded profile pictures
    $uploadDirectory = "profile_images/" . $hospital_id . '.jpg';

    // Check if the file was uploaded without errors
    if ($_FILES['profile_image']['error'] === UPLOAD_ERR_OK) {
        // Get the temporary file path
        $profilePicTmpName = $_FILES['profile_image']['tmp_name'];

        // Move the uploaded file to the destination directory
        if (move_uploaded_file($profilePicTmpName, $uploadDirectory)) {
            // Update the database with the new information including the profile picture path
            $profilePicPath = $uploadDirectory;
            $query = "INSERT INTO patients (hospital_id, name, mobile_number, age, gender, password, diagnosis, profile_image)
                      VALUES ('$hospital_id', '$name', '$mobile_number', '$age', '$gender', '$password', '$diagnosis', '$profilePicPath')";

            if (mysqli_query($conn, $query)) {
                // Insert hospital_id and password into plogin table
                $ploginQuery = "INSERT INTO plogin (hospital_id, password) VALUES ('$hospital_id', '$password')";
                if (mysqli_query($conn, $ploginQuery)) {
                    echo json_encode(['status' => 'success', 'message' => 'Patient added successfully']);
                } else {
                    echo json_encode(['status' => 'error', 'message' => mysqli_error($conn)]);
                }
            } else {
                echo json_encode(['status' => 'error', 'message' => mysqli_error($conn)]);
            }
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to save the image']);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Image upload error']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method']);
}

// Close the database connection
mysqli_close($conn);
?>
