<?php
// Include your database connection file
require "conn.php";

// Fetch data from the database
$sql = "SELECT hospital_id, name, profile_image FROM patients";
$result = $conn->query($sql);

// Check if there are results
if ($result) {
    $data = array();

    // Fetch associative array
    while ($row = $result->fetch_assoc()) {
        $data[] = array(
            'hospital_id' => $row['hospital_id'],
            'name' => $row['name'],
            'profile_image' => $row['profile_image'],
        ); 
    }

    // Return the data as JSON
    echo json_encode(['status' => 'success', 'data' => $data]);
} else {
    // Handle query error
    echo json_encode(['status' => 'error', 'message' => 'Error fetching data from the database: ' . $conn->error]);
}

// Close the database connection
mysqli_close($conn);
?>
