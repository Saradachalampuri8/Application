<?php
// Include your database connection file
require "conn.php";

// Check if the necessary parameters are provided
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize input data to prevent SQL injection
    $patient_status_rul = mysqli_real_escape_string($conn, $_POST['rul']);
    $patient_status_lul = mysqli_real_escape_string($conn, $_POST['lul']);
    $hospital_id = mysqli_real_escape_string($conn, $_POST['hospital_id']);
    $patient_status_rll = mysqli_real_escape_string($conn, $_POST['rll']);
    $patient_status_lll = mysqli_real_escape_string($conn, $_POST['lll']);

    // Directory to save uploaded MRI images
    $uploadDirectory = "mri_images/" . $hospital_id . '.jpg';

    // Check if a record with the given hospital ID already exists
    $checkQuery = "SELECT * FROM patients WHERE hospital_id = '$hospital_id'";
    $checkResult = mysqli_query($conn, $checkQuery);

    if (mysqli_num_rows($checkResult) > 0) {
        // If a record exists, perform an UPDATE operation
        $query = "UPDATE patients 
                  SET patient_status_rul = '$patient_status_rul', 
                      patient_status_lul = '$patient_status_lul', 
                      patient_status_rll = '$patient_status_rll', 
                      patient_status_lll = '$patient_status_lll', 
                      mri = '$uploadDirectory' 
                  WHERE hospital_id = '$hospital_id'";
    } else {
        // If no record exists, perform an INSERT operation
        $query = "INSERT INTO patients (hospital_id, patient_status_rul, patient_status_lul, patient_status_rll, patient_status_lll, mri) 
                  VALUES ('$hospital_id', '$patient_status_rul', '$patient_status_lul', '$patient_status_rll', '$patient_status_lll', '$uploadDirectory')";
    }

    // Move the uploaded file to the destination directory and execute the query
    if (move_uploaded_file($_FILES['mri']['tmp_name'], $uploadDirectory) && mysqli_query($conn, $query)) {
        echo json_encode(['status' => 'success', 'message' => 'Patient status added successfully']);
    } else {
        echo json_encode(['status' => 'error', 'message' => mysqli_error($conn)]);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method']);
}

// Close the database connection
mysqli_close($conn);
?>
