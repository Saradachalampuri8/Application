<?php

require "conn.php";

// Check if hospital_id parameter is provided via POST
if(isset($_POST['hospital_id'])) {
    // Sanitize input to prevent SQL injection
    $hospital_id = $conn->real_escape_string($_POST['hospital_id']);

    // Prepare SQL query to fetch data with matching hospital_id from patients table
    $sqlPatients = "SELECT patient_status_rul AS rul, patient_status_lul AS lul, patient_status_rll AS rll, patient_status_lll AS lll
                    FROM patients
                    WHERE hospital_id = '$hospital_id'";

    // Prepare SQL query to fetch data with matching hospital_id from new_patient_status table
    $sqlNewStatus = "SELECT rul, lul, rll, lll
                     FROM new_patient_status
                     WHERE hospital_id = '$hospital_id'";

    // Execute both queries
    $resultPatients = $conn->query($sqlPatients);
    $resultNewStatus = $conn->query($sqlNewStatus);

    // Initialize array to store results
    $data = array();

    // Fetch data from patients table if available
    if ($resultPatients && $resultPatients->num_rows > 0) {
        while ($row = $resultPatients->fetch_assoc()) {
            // Store patient data in the data array
            $data[] = $row;
        }
    }

    // Fetch data from new_patient_status table if available
    if ($resultNewStatus && $resultNewStatus->num_rows > 0) {
        while ($row = $resultNewStatus->fetch_assoc()) {
            // Store new_status in the data array
            $data[] = $row;
        }
    }

    // Output data as JSON
    echo json_encode(["status" => "success", "message" => "Data fetched successfully", "data" => $data]);
} else {
    // hospital_id parameter is missing
    echo json_encode(["status" => "error", "message" => "hospital_id parameter is missing", "data" => []]);
}

// Close connection
$conn->close();

?>
