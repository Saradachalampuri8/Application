<?php

include 'conn.php'; // Include the database connection file

// Get the data from the POST request
$_POST = json_decode(file_get_contents("php://input"), true);

// Check if the required keys exist in the $_POST array
if(isset($_POST['hospital_id'], $_POST['ryles_date'])) {
    // Extract hospital_id and ryles_date from the data
    $hospital_id = $_POST['hospital_id'];
    $ryles_date = $_POST['ryles_date'];

    // Query to fetch the current value of the ryles column for the given hospital_id
    $query = "SELECT ryles FROM foleys_ryles WHERE hospital_id = '$hospital_id'";
    $result = $conn->query($query);

    if ($result) {
        // Fetch the result row
        $row = $result->fetch_assoc();
        if ($row) {
            // Extract the month part from the current ryles_date
            $prev_month = date('m', strtotime($row['ryles']));
            // Extract the month part from the new ryles_date
            $new_month = date('m', strtotime($ryles_date));
            // Check if the months are different
            if ($prev_month != $new_month) {
                // Update the ryles column
                $update_sql = "UPDATE foleys_ryles SET ryles = '$ryles_date' WHERE hospital_id = '$hospital_id'";
                if ($conn->query($update_sql) === TRUE) {
                    echo "Ryles column updated successfully for hospital with ID: $hospital_id";
                } else {
                    echo "Error updating Ryles column: " . $conn->error;
                }
            } else {
                echo "Ryles column for hospital with ID: $hospital_id already contains the same month";
            }
        } else {
            // If no row found, insert a new row
            $insert_sql = "INSERT INTO foleys_ryles (hospital_id, ryles) VALUES ('$hospital_id', '$ryles_date')";
            if ($conn->query($insert_sql) === TRUE) {
                echo "New record inserted successfully for hospital with ID: $hospital_id";
            } else {
                echo "Error inserting new record: " . $conn->error;
            }
        }
    } else {
        echo "Error fetching current value of Ryles column: " . $conn->error;
    }

} else {
    echo "Incomplete or invalid data received for Ryles update";
}

// Close the connection
$conn->close();

?>
