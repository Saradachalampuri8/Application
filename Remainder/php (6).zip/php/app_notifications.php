<?php

// Set header to ensure JSON response
header('Content-Type: application/json');

// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Database connection parameters
    require_once('conn.php');

    // Check connection
    if ($conn->connect_error) {
        $response = array(
            "status" => "error",
            "message" => "Connection failed: " . $conn->connect_error
        );
        echo json_encode($response);
        exit();
    }

    // Get time parameter from the request body
    $current_time = isset($_POST['time']) ? $_POST['time'] : date("H:i");

    // SQL query to fetch data with notification timings matching the current time
    $sql = "SELECT * FROM app_notifications WHERE DATE_FORMAT(timings, '%H:%i') = '$current_time'";
    $result = $conn->query($sql);

    // Check if there are any results
    if ($result->num_rows > 0) {
        // Fetching data and converting it to associative array
        $data = array();
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
        // Sending response as JSON
        $response = array(
            "status" => "success",
            "message" => "Notification time matched",
            "data" => $data
        );
        echo json_encode($response);
    } else {
        // No results found
        $response = array(
            "status" => "error",
            "message" => "No notification time matched with the current time"
        );
        echo json_encode($response);
    }

    // Close connection
    $conn->close();
} else {
    // Invalid request method
    $response = array(
        "status" => "error",
        "message" => "Invalid request method"
    );
    echo json_encode($response);
}

?>
