<?php
// Include your database connection file
require "conn.php";

// Function to generate JSON response
function jsonResponse($status, $message) {
    header('Content-Type: application/json');
    echo json_encode(['status' => $status, 'message' => $message]);
    exit;
}

// Check if the hospital_id parameter is provided via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['hospital_id'])) {
    // Sanitize input data to prevent SQL injection
    $hospital_id = mysqli_real_escape_string($conn, $_POST['hospital_id']);

    // Check if the patient exists in the database
    $check_query = "SELECT * FROM patients WHERE hospital_id = '$hospital_id'";
    $check_result = mysqli_query($conn, $check_query);
    
    if (mysqli_num_rows($check_result) > 0) {
        // Prepare the update query
        $update_query = "UPDATE patients SET ";
        $updated_fields = array();
        
        // Check and append provided fields to the update query
        if (isset($_POST['name'])) {
            $name = mysqli_real_escape_string($conn, $_POST['name']);
            $update_query .= "name = '$name', ";
            $updated_fields[] = 'name';
        }
        if (isset($_POST['gender'])) {
            $gender = mysqli_real_escape_string($conn, $_POST['gender']);
            $update_query .= "gender = '$gender', ";
            $updated_fields[] = 'gender';
        }
        if (isset($_POST['age'])) {
            $age = mysqli_real_escape_string($conn, $_POST['age']);
            $update_query .= "age = '$age', ";
            $updated_fields[] = 'age';
        }
        if (isset($_POST['diagnosis'])) {
            $diagnosis = mysqli_real_escape_string($conn, $_POST['diagnosis']);
            $update_query .= "diagnosis = '$diagnosis', ";
            $updated_fields[] = 'diagnosis';
        }
        if (isset($_POST['mobile_number'])) {
            $mobile_number = mysqli_real_escape_string($conn, $_POST['mobile_number']);
            $update_query .= "mobile_number = '$mobile_number', ";
            $updated_fields[] = 'mobile_number';
        }

        // Remove trailing comma and space
        $update_query = rtrim($update_query, ", ");
        
        // Append the condition for hospital_id
        $update_query .= " WHERE hospital_id = '$hospital_id'";
        
        // Execute the update query
        if (mysqli_query($conn, $update_query)) {
            jsonResponse('success', 'Patient details updated successfully');
        } else {
            jsonResponse('error', mysqli_error($conn));
        }
    } else {
        jsonResponse('error', 'Patient not found');
    }
} else {
    jsonResponse('error', 'Invalid or missing parameters');
}

// Close the database connection
mysqli_close($conn);
?>
