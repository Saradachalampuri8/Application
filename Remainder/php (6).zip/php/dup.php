<?php

require_once('conn.php'); // Include the connection file

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form data is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if hospital_id and ryles_date exist in the data
    if (isset($_POST['hospital_id']) && isset($_POST['ryles_date'])) {
        // Extract data from the POST array
        $hospital_id = $_POST['hospital_id'];
        $ryles_date = $_POST['ryles_date'];
        
        // Check if the combination of hospital_id and ryles_date exists in the table
        $check_query = "SELECT ryles FROM foleys_ryles WHERE hospital_id = ? AND foleys = ?";
        $check_stmt = $conn->prepare($check_query);
        $check_stmt->bind_param("ss", $hospital_id, $ryles_date);
        $check_stmt->execute();
        $check_stmt->store_result();
        
        if ($check_stmt->num_rows > 0) {
            // Combination exists in the table
            $check_stmt->bind_result($existing_ryles);
            $check_stmt->fetch();
            
            // Check if existing ryles value is '0000-00-00' and incoming ryles is not '0000-00-00'
            if ($existing_ryles == '0000-00-00' && $ryles_date != '0000-00-00') {
                // Update ryles column
                $update_query = "UPDATE foleys_ryles SET ryles = ? WHERE hospital_id = ? AND foleys = ?";
                $update_stmt = $conn->prepare($update_query);
                $update_stmt->bind_param("sss", $ryles_date, $hospital_id, $ryles_date);
                
                if ($update_stmt->execute()) {
                    echo "Data updated successfully!";
                } else {
                    echo "Error updating data: " . $update_stmt->error;
                }
                
                // Close update statement
                $update_stmt->close();
            } else {
                echo "Hospital ID and ryles combination exists in the table. Data not updated.";
            }
        } else {
            // Combination does not exist in the table, insert data
            $insert_query = "INSERT INTO foleys_ryles (hospital_id, foleys, ryles) VALUES (?, ?, ?)";
            $insert_stmt = $conn->prepare($insert_query);
            $insert_stmt->bind_param("sss", $hospital_id, $ryles_date, $ryles_date);
            
            if ($insert_stmt->execute()) {
                echo "Data inserted successfully!";
            } else {
                echo "Error inserting data: " . $insert_stmt->error;
            }
            
            // Close insert statement
            $insert_stmt->close();
        }
        
        // Close check statement
        $check_stmt->close();
    } else {
        echo "Hospital ID and/or ryles_date are not present!";
    }
}

// Close connection
$conn->close();

?>
