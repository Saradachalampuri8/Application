<?php
require_once "conn.php";
header("Content-Type: application/json");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    // Check if 'hospital_id' is set in the JSON data
    if (isset($data["hospital_id"])) {
        $hospital_id = $data["hospital_id"];
        
        // Extract boolean values from checkboxes
        $physio_morning = isset($data["physio_morning"]) ? 1 : 0;
        $physio_evening = isset($data["physio_evening"]) ? 1 : 0;
        $bedpositions_1 = isset($data["bedpositions_1"]) ? 1 : 0;
        $bedpositions_2 = isset($data["bedpositions_2"]) ? 1 : 0;
        $bedpositions_3 = isset($data["bedpositions_3"]) ? 1 : 0;
        $bedpositions_4 = isset($data["bedpositions_4"]) ? 1 : 0;
        $bedsores_1 = isset($data["bedsores_1"]) ? 1 : 0;
        $bedsores_2 = isset($data["bedsores_2"]) ? 1 : 0;
        $feeds_1 = isset($data["feeds_1"]) ? 1 : 0;
        $feeds_2 = isset($data["feeds_2"]) ? 1 : 0;
        $feeds_3 = isset($data["feeds_3"]) ? 1 : 0;

        // Automatically get the present date
        $day = date('d');
        $month_name = date('F');
        $year = date('Y');

        // Calculate status based on boolean values using OR gate
        $status = ($physio_morning || $physio_evening || $bedpositions_1 || $bedpositions_2 || $bedpositions_3 || $bedpositions_4 || $bedsores_1 || $bedsores_2 || $feeds_1 || $feeds_2 || $feeds_3) ? 'completed' : 'pending';

        // Calculate total_count based on the sum of boolean values
        $total_count = $physio_morning + $physio_evening + $bedpositions_1 + $bedpositions_2 + $bedpositions_3 + $bedpositions_4 + $bedsores_1 + $bedsores_2 + $feeds_1 + $feeds_2 + $feeds_3;

        // Check if the record with the same hospital ID, day, month, and year already exists
        $checkDuplicateSql = "SELECT * FROM patient_records WHERE hospital_id = '$hospital_id' AND day = '$day' AND month_name = '$month_name' AND year = '$year'";
        $result = $conn->query($checkDuplicateSql);

        if ($result && $result->num_rows > 0) {
            // Update the existing record
            $updateSql = "UPDATE patient_records SET physio_morning = '$physio_morning', physio_evening = '$physio_evening', bedpositions_1 = '$bedpositions_1', bedpositions_2 = '$bedpositions_2', bedpositions_3 = '$bedpositions_3', bedpositions_4 = '$bedpositions_4', bedsores_1 = '$bedsores_1', bedsores_2 = '$bedsores_2', feeds_1 = '$feeds_1', feeds_2 = '$feeds_2', feeds_3 = '$feeds_3', status = '$status', total_count = '$total_count' WHERE hospital_id = '$hospital_id' AND day = '$day' AND month_name = '$month_name' AND year = '$year'";

            if ($conn->query($updateSql) === TRUE) {
                $response = array('status' => 'success', 'message' => 'Data updated successfully');
            } else {
                $response = array('status' => 'failure', 'message' => 'Error updating data: ' . $conn->error);
            }
        } else {
            // Insert the new record
            $insertSql = "INSERT INTO patient_records (hospital_id, day, month_name, year, physio_morning, physio_evening, bedpositions_1, bedpositions_2, bedpositions_3, bedpositions_4, bedsores_1, bedsores_2, feeds_1, feeds_2, feeds_3, status, total_count) 
                          VALUES ('$hospital_id', '$day', '$month_name', '$year', '$physio_morning', '$physio_evening', '$bedpositions_1', '$bedpositions_2', '$bedpositions_3', '$bedpositions_4', '$bedsores_1', '$bedsores_2', '$feeds_1', '$feeds_2', '$feeds_3', '$status', '$total_count')";

            if ($conn->query($insertSql) === TRUE) {
                $response = array('status' => 'success', 'message' => 'Data inserted successfully with calculated status');
            } else {
                $response = array('status' => 'failure', 'message' => 'Error inserting data: ' . $conn->error);
            }
        }

        echo json_encode($response);
    } else {
        $response = array('status' => 'failure', 'message' => 'Missing hospital_id in the request');
        echo json_encode($response);
    }
} else {
    $response = array('status' => 'failure', 'message' => 'Invalid request method');
    echo json_encode($response);
}
?>
