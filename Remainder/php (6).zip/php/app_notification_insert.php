<?php

require_once('conn.php'); // Assuming you have already established a database connection

// Ensure the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve data from the request body (FormData)
    $timings = $_POST['timings'] ?? null;
    $message = $_POST['message'] ?? null;

    // Check if both timings and message are provided
    if ($timings !== null && $message !== null) {
        // Insert data into the table
        $sql = "INSERT INTO app_notifications (timings, message) VALUES (?, ?)";
        $stmt = $conn->prepare($sql);
        if ($stmt->execute([$timings, $message])) {
            // Data inserted successfully
            $response = array(
                "status" => "success",
                "message" => "Data inserted successfully"
            );
        } else {
            // Failed to insert data
            $response = array(
                "status" => "error",
                "message" => "Failed to insert data"
            );
        }
    } else {
        // Invalid request format
        $response = array(
            "status" => "error",
            "message" => "Invalid request format"
        );
    }
} else {
    // Invalid request method
    $response = array(
        "status" => "error",
        "message" => "Invalid request method"
    );
}

// Encode the response to JSON format
echo json_encode($response);
?>
