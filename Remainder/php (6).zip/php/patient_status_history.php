<?php
require_once('conn.php');

// Check if hospital_id is set in the POST request
if(isset($_POST['hospital_id'])){
    $hospital_id = $_POST['hospital_id'];

    // SQL query to fetch data from the patients table for a specific hospital_id
    $sql = "SELECT patient_status_rul, patient_status_lul, patient_status_rll, patient_status_lll FROM patients WHERE hospital_id = ?";

    // Prepare the SQL statement
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        // If statement preparation fails, return an error
        echo json_encode(array("status" => "error", "message" => "Failed to prepare statement"));
        exit;
    }

    // Bind the hospital_id parameter
    $stmt->bind_param("s", $hospital_id);

    // Execute the statement
    $stmt->execute();

    // Get the result
    $result = $stmt->get_result();

    if ($result) {
        if ($result->num_rows > 0) {
            // Initialize an array to store the data
            $data = array();
            
            // Fetch data from each row and add it to the array
            while ($row = $result->fetch_assoc()) {
                $data[] = $row;
            }
            
            // Return the data as JSON
            echo json_encode(array("status" => "success",'message' => 'patient status has been fetched successfully', "data" => $data));
        } else {
            // If no rows are returned, return an empty array
            echo json_encode(array("status" => "success","message" => "No result Found For the Provided hospital_id", "data" => array()));
        }
    } else {
        // If query execution fails, return an error
        echo json_encode(array("status" => "error", "message" => "Failed to execute query"));
    }

    // Close the statement
    $stmt->close();
} else {
    // If hospital_id is not set in the request, return an error
    echo json_encode(array("status" => "error", "message" => "hospital_id is required"));
}

// Close the connection
$conn->close();
?>