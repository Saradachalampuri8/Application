<?php

require_once('conn.php');

// Base URL for the videos
$base_url = 'http://localhost/php/uploads/videos/';

// Fetch video URLs from the database
$select_sql = "SELECT video_url FROM videos";
$select_stmt = $conn->prepare($select_sql);

if ($select_stmt) {
    $select_stmt->execute();
    $result = $select_stmt->get_result();

    $videos = [];

    while ($row = $result->fetch_assoc()) {
        // Ensure correct concatenation
        $videos[] = $base_url . basename($row['video_url']);
    }

    $select_stmt->close();

    // Return JSON response
    header('Content-Type: application/json');
    echo json_encode(['status' => true, 'videos' => $videos]);
} else {
    // Log the error for development purposes
    error_log("Error preparing SQL statement: " . $conn->error);

    // Return JSON response for error
    header('Content-Type: application/json');
    echo json_encode(['status' => false, 'message' => 'Internal server error']);
}

$conn->close();
?>
