<?php
// Initialize response array
$response = array();

// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Check if hospital_id, day, month_name, and year are provided in the request
    if(isset($_POST['hospital_id']) && isset($_POST['day']) && isset($_POST['month_name']) && isset($_POST['year'])) {
        // Get the provided values
        $hospital_id = $_POST['hospital_id'];
        $day = $_POST['day'];
        $month_name = $_POST['month_name'];
        $year = $_POST['year'];
        
        require_once('conn.php');

        // Prepare the SQL statement to fetch data from patient_records table based on hospital_id, day, month_name, and year
        $sql = "SELECT IFNULL(physio_morning, 0) AS physio_morning, IFNULL(physio_evening, 0) AS physio_evening FROM patient_records WHERE hospital_id = ? AND day = ? AND month_name = ? AND year = ?";
        
        // Prepare the statement
        $stmt = $conn->prepare($sql);
        
        // Bind parameters
        $stmt->bind_param("ssss", $hospital_id, $day, $month_name, $year);
        
        // Execute the statement
        $stmt->execute();
        
        // Get the result
        $result = $stmt->get_result();
        
        // Initialize an array to store the patient records
        $patient_records = array();

        // Checking if there are any results
        if ($result->num_rows > 0) {
            // Fetching data row by row
            while($row = $result->fetch_assoc()) {
                // Adding each row to the patient_records array
                $patient_records[] = $row;
            }
            $response['status'] = 'success';
            $response['message'] = 'Patient records found';
            $response['data'] = $patient_records;
        } else {
            // If no results found
            $response['status'] = 'error';
            $response['message'] = 'No patient records found for the provided hospital_id, day, month_name, and year';
        }

        // Closing the connection
        $conn->close();
    } else {
        // If hospital_id, day, month_name, or year is not provided
        $response['status'] = 'error';
        $response['message'] = 'hospital_id, day, month_name, and year not provided';
    }
} else {
    // Handle the case where the request method is not POST
    $response['status'] = 'error';
    $response['message'] = 'Invalid request method';
}

// Set the content type header to JSON
header('Content-Type: application/json');

// Output the JSON response
echo json_encode($response);
?>
