<?php

// Include the database connection file (conn.php)
require_once('conn.php');

// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Check if the hospital_id is set in the POST data
    if(isset($_POST['hospital_id'])) {
        // Get the provided hospital_id
        $hospital_id = $_POST['hospital_id'];

        // Prepare the SQL query to fetch data from foleys_ryles table
        $sql = "SELECT ryles FROM foleys_ryles WHERE hospital_id = ? AND ryles != '0'";
        $stmt = $conn->prepare($sql);

        // Check if the statement is prepared successfully
        if ($stmt) {
            // Bind the parameters and execute the query
            $stmt->bind_param("s", $hospital_id); // assuming hospital_id is a string
            $stmt->execute();

            // Get the result set
            $result = $stmt->get_result();

            // Check if there are rows in the result set
            if ($result->num_rows > 0) {
                // Initialize an array to store data
                $rylesData = array();

                // Fetch data from each row and store it in the array
                while ($row = $result->fetch_assoc()) {
                    // Separate date into day, month name, and year
                    $rylesParts = explode('-', $row['ryles']);
                    $day = date('d', strtotime($row['ryles']));
                    $monthName = date('F', strtotime($row['ryles']));
                    $year = date('Y', strtotime($row['ryles']));

                    // Add the separated data to the array
                    $rylesData[] = array(
                        'day' => $day,
                        'month_name' => $monthName,
                        'year' => $year
                    );
                }

                // Convert the data to JSON
                $jsonResponse = json_encode(array('success' => true, 'message' => 'Data has been fetched successfully.','data' => $rylesData));
                echo $jsonResponse;
            } else {
                // If no results are found
                echo json_encode(array('success' => false, 'message' => 'No results found for the given hospital_id.', 'data' => array()));
            }

            // Close the statement
            $stmt->close();
        } else {
            // If there is an error in preparing the SQL statement
            echo json_encode(array('success' => false, 'message' => 'Error in preparing SQL statement.', 'data' => array()));
        }
    } else {
        // If hospital_id is not provided
        echo json_encode(array('success' => false, 'message' => 'hospital_id not provided', 'data' => array()));
    }
} else {
    // Handle the case where the request method is not POST
    echo json_encode(array('success' => false, 'message' => 'Invalid request method'));
}

// Close the database connection
$conn->close();

?>
