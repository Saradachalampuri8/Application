<?php
require_once "conn.php"; // Include your database connection file
header("Content-Type: application/json");

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Check if required parameters are set in the URL
    if (isset($_GET["hospital_id"], $_GET["day"], $_GET["month_name"], $_GET["year"])) {
        $hospital_id = $_GET["hospital_id"];
        $day = $_GET["day"];
        $month_name = $_GET["month_name"];
        $year = $_GET["year"];

        // Select bedsores_1 and bedsores_2 from patient_records based on the provided parameters
        $selectSql = "SELECT bedsores_1, bedsores_2 FROM patient_records 
                      WHERE hospital_id = ? AND day = ? AND month_name = ? AND year = ?";

        $stmt = $conn->prepare($selectSql);
        $stmt->bind_param("ssss", $hospital_id, $day, $month_name, $year);

        if ($stmt->execute()) {
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $response = array('status' => 'success', 'message' => 'Data retrieved successfully', 'data' => $row);
            } else {
                $response = array('status' => 'failure', 'message' => 'No matching record found');
            }
        } else {
            $response = array('status' => 'failure', 'message' => 'Error executing query: ' . $conn->error);
        }

        echo json_encode($response);
    } else {
        $response = array('status' => 'failure', 'message' => 'Missing required parameters in the request');
        echo json_encode($response);
    }
} else {
    $response = array('status' => 'failure', 'message' => 'Invalid request method');
    echo json_encode($response);
}
?>
