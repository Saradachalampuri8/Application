<?php
// Include your database connection file
require "conn.php";

// Set headers to ensure response is treated as JSON
header("Content-Type: application/json");

// Check if the necessary parameters are provided
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the hospital_id from POST data
    $hospital_id = $_POST['hospital_id'];

    // Check if hospital_id is provided
    if (!empty($hospital_id)) {
        // Query to check if the hospital_id exists in the database
        $check_query = "SELECT * FROM patients WHERE hospital_id = '$hospital_id'";
        $check_result = mysqli_query($conn, $check_query);

        // Check if the hospital_id exists
        if (mysqli_num_rows($check_result) > 0) {
            // Query to fetch data from the patients table
            $query = "SELECT hospital_id, name, age, gender, mobile_number, diagnosis, profile_image FROM patients WHERE hospital_id = '$hospital_id'";

            // Execute the query
            $result = mysqli_query($conn, $query);

            // Check if the query was successful
            if ($result) {
                // Initialize an array to store the fetched data
                $patients = array();

                // Fetch associative array
                while ($row = mysqli_fetch_assoc($result)) {
                    // Add each row to the patients array
                    $patients[] = $row;
                }

                // Free result set
                mysqli_free_result($result);

                // Close the connection
                mysqli_close($conn);

                // Encode the patients array to JSON format
                $json_response = json_encode(['status' => 'success', 'patients' => $patients]);

                // Output the JSON response
                echo $json_response;
            } else {
                // If the query fails, return an error message
                echo json_encode(['status' => 'error', 'message' => 'Failed to fetch data from the database']);
            }
        } else {
            // If hospital_id does not exist, return an error message
            echo json_encode(['status' => 'error', 'message' => 'Hospital ID not found']);
        }
    } else {
        // If hospital_id is not provided, return an error message
        echo json_encode(['status' => 'error', 'message' => 'Hospital ID is required']);
    }
} else {
    // If the request method is not POST, return an error message
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method']);
}
?>
