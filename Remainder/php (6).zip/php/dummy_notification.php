<?php
require_once('conn.php');

// Set the desired time zone to Indian Standard Time (IST)
date_default_timezone_set('Asia/Kolkata');

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the data from the POST body
    $postData = json_decode(file_get_contents('php://input'), true);

    // Get current date and time
    $currentDate = date("d");
    $currentMonth = date("F");
    $currentYear = date("Y");
    $currentHour = date("H"); // Hour in 24-hour format
    $currentMinute = date("i"); // Minutes

    // Initialize an empty array to hold the results
    $output = array();

    // Debug information
    $output[] = array("current_date" => $currentDate, "current_month" => $currentMonth, "current_year" => $currentYear, "current_hour" => $currentHour, "current_minute" => $currentMinute);

    // Check if the current time is 1:05 AM and physio_morning is not completed
    if ($currentHour == 1 && $currentMinute == 5) {
        // Fetch data from patient_records table
        $sql = "SELECT hospital_id, physio_morning FROM patient_records WHERE day = '$currentDate' AND month_name = '$currentMonth' AND year = '$currentYear'";
        $result = $conn->query($sql);

        // Check for errors
        if (!$result) {
            die("Error: " . $conn->error);
        }

        // Check if there are any records for the current date
        if ($result->num_rows > 0) {
            // Fetch each row
            while($row = $result->fetch_assoc()) {
                $hospitalId = $row["hospital_id"];
                $physioMorning = $row["physio_morning"];

                // Check if physio_morning is not completed
                if ($physioMorning != 1) {
                    $notification = "It's time for morning physiotherapy task.";
                    // Add the notification to the output array
                    $output[] = array("hospital_id" => $hospitalId, "notification" => $notification);
                }
            }
        } else {
            // If no records found for the current date, add a notification for each hospital ID
            $output[] = array("notification" => "No records found for the current date. Notifications inserted for all hospital IDs.");
        }
    }

    // Check if the current time is 12:30 PM and bedpositions_1 is not completed
    if ($currentHour == 23 && $currentMinute == 42) {
        // Fetch data from patient_records table
        $sql = "SELECT hospital_id, bedpositions_1 FROM patient_records WHERE day = '$currentDate' AND month_name = '$currentMonth' AND year = '$currentYear'";
        $result = $conn->query($sql);

        // Check for errors
        if (!$result) {
            die("Error: " . $conn->error);
        }

        // Check if there are any records for the current date
        if ($result->num_rows > 0) {
            // Fetch each row
            while($row = $result->fetch_assoc()) {
                $hospitalId = $row["hospital_id"];
                $bedpositions_1 = $row["bedpositions_1"];

                // Check if bedpositions_1 is not completed
                if ($bedpositions_1 != 1) {
                    $notification = "It's time to change bed positions.";
                    // Add the notification to the output array
                    $output[] = array("hospital_id" => $hospitalId, "notification" => $notification);
                }
            }
        } else {
            // If no records found for the current date, add a notification for each hospital ID
            $output[] = array("notification" => "No records found for the current date. Notifications inserted for all hospital IDs.");
        }
    }

    // Check if the current time is midnight (00:00) and delete all data from the notification table
    if ($currentHour == 0 && $currentMinute == 0) {
        // Add a notification for data deletion
        $output[] = array("notification" => "All data from the notification table deleted.");
    }

    // Return the output array as JSON
    echo json_encode($output);
} else {
    // If the request method is not POST, return an error message
    echo json_encode(array("error" => "Invalid request method. Only POST requests are allowed."));
}
?>
