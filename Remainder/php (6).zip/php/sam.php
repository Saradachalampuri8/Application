<?php
// Check if the required parameters are set
if (isset($_GET['score']) && isset($_GET['userID']) && isset($_GET['currentDate'])) {
    // Get the values from the GET parameters
    $score = $_GET['score'];
    $userID = $_GET['userID'];
    $currentDate = $_GET['currentDate'];

    // Perform any additional validation or processing as needed

    // Example: Insert the data into a database
    // Replace "your_database_host", "your_database_username", "your_database_password", and "your_database_name" with your actual database credentials
   

    // Replace "your_table_name" with your actual table name
    $sql = "INSERT INTO info VALUES ( '$userID','$score', '$currentDate')";

    if ($conn->query($sql) === TRUE) {
        echo "Data inserted successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
} else {
    // Handle the case when the required parameters are not set
    echo "Missing parameters";
}
?>
