<?php
$hostname = "localhost";
$user = "root";
$pass = "";
$db = "sample";

$conn = new mysqli($hostname, $user, $pass, $db);

if ($conn->connect_error) {
    $response = array('status' => 'failure', 'message' => 'Database connection error');
    echo json_encode($response);
    exit();
}
?>
