<?php

require("conn.php"); // Include your database connection code

// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // Read JSON data from the request body
    $inputJSON = file_get_contents('php://input');
    $_POST = json_decode($inputJSON, true);

    // Extracting values from JSON with isset checks
    $hospital_id = isset($_POST['hospital_id']) ? $_POST['hospital_id'] : null;

    // Check if hospital_id is null or empty
    if (empty($hospital_id)) {
        // Return error response if hospital_id is null or empty
        header('Content-Type: application/json');
        echo json_encode(array("status" => "error", "message" => "hospital_id cannot be null or empty"));
        exit; // Terminate script execution
    }

    $feeds_1 = isset($_POST['feeds_1']) ? (intval($_POST['feeds_1']) ? 1 : 0) : null;
    $feeds_2 = isset($_POST['feeds_2']) ? (intval($_POST['feeds_2']) ? 1 : 0) : null;
    $feeds_3 = isset($_POST['feeds_3']) ? (intval($_POST['feeds_3']) ? 1 : 0) : null;

    // Calculate total_count based on the sum of boolean values
    $total_count = $feeds_1 + $feeds_2 + $feeds_3;

    // Get the current date
    $day = date('d');
    $month_name = date('F');
    $year = date('Y');

    // Check if a record with the given hospital_id, day, month_name, and year already exists
    $stmt_check_existing = $conn->prepare("SELECT total_count FROM patient_records WHERE hospital_id = ? AND day = ? AND month_name = ? AND year = ?");
    $stmt_check_existing->bind_param("siss", $hospital_id, $day, $month_name, $year);
    $stmt_check_existing->execute();
    $result = $stmt_check_existing->get_result();

    if ($result->num_rows > 0) {
        // Previous record exists, retrieve the previous total_count
        $row = $result->fetch_assoc();
        $previous_total_count = $row['total_count'];
        $total_count += $previous_total_count;
        
        // Update existing record with the new total_count and relevant feeds
        $stmt_update = $conn->prepare("UPDATE patient_records SET feeds_1 = ?, feeds_2 = ?, feeds_3 = ?, total_count = ? WHERE hospital_id = ? AND day = ? AND month_name = ? AND year = ?");
        $stmt_update->bind_param("iiiiissi", $feeds_1, $feeds_2, $feeds_3, $total_count, $hospital_id, $day, $month_name, $year);

        if ($stmt_update->execute()) {
            $response = array("status" => "success", "message" => "Data updated successfully");
        } else {
            $response = array("status" => "error", "message" => "Error updating data: " . $stmt_update->error);
        }

        $stmt_update->close();
    } else {
        // No previous record found, insert new record with the calculated total_count
        $stmt_insert = $conn->prepare("INSERT INTO patient_records (hospital_id, feeds_1, feeds_2, feeds_3, total_count, status, day, month_name, year) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $status = ($total_count > 0) ? 'completed' : 'pending';
        $stmt_insert->bind_param("siiiiisssi", $hospital_id, $feeds_1, $feeds_2, $feeds_3, $total_count, $status, $day, $month_name, $year);

        if ($stmt_insert->execute()) {
            $response = array("status" => "success", "message" => "Data inserted successfully");
        } else {
            $response = array("status" => "error", "message" => "Error inserting data: " . $stmt_insert->error);
        }

        $stmt_insert->close();
    }

    // Close statement for checking existing record
    $stmt_check_existing->close();

    // Send JSON response back to the client
    header('Content-Type: application/json');
    echo json_encode($response);

} else {<?php

    require("conn.php"); // Include your database connection code
    
    // Check if the request method is POST
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        
        // Read JSON data from the request body
        $inputJSON = file_get_contents('php://input');
        $_POST = json_decode($inputJSON, true);
    
        // Extracting values from JSON with isset checks
        $hospital_id = isset($_POST['hospital_id']) ? $_POST['hospital_id'] : null;
    
        // Check if hospital_id is null or empty
        if (empty($hospital_id)) {
            // Return error response if hospital_id is null or empty
            header('Content-Type: application/json');
            echo json_encode(array("status" => "error", "message" => "hospital_id cannot be null or empty"));
            exit; // Terminate script execution
        }
    
        // Get the current date
        $day = date('d');
        $month_name = date('F');
        $year = date('Y');
    
        // Check if a record with the given hospital_id, day, month_name, and year already exists
        $stmt_check_existing = $conn->prepare("SELECT total_count, feeds_1, feeds_2, feeds_3 FROM patient_records WHERE hospital_id = ? AND day = ? AND month_name = ? AND year = ?");
        $stmt_check_existing->bind_param("siss", $hospital_id, $day, $month_name, $year);
        $stmt_check_existing->execute();
        $result = $stmt_check_existing->get_result();
    
        if ($result->num_rows > 0) {
            // Previous record exists
            $row = $result->fetch_assoc();
            $previous_total_count = $row['total_count'];
            $previous_feeds_1 = $row['feeds_1'];
            $previous_feeds_2 = $row['feeds_2'];
            $previous_feeds_3 = $row['feeds_3'];
            
            // Calculate total_count based on the sum of boolean values
            $new_feeds_1 = isset($_POST['feeds_1']) ? (intval($_POST['feeds_1']) ? 1 : 0) : $previous_feeds_1;
            $new_feeds_2 = isset($_POST['feeds_2']) ? (intval($_POST['feeds_2']) ? 1 : 0) : $previous_feeds_2;
            $new_feeds_3 = isset($_POST['feeds_3']) ? (intval($_POST['feeds_3']) ? 1 : 0) : $previous_feeds_3;
            
            $total_count = $new_feeds_1 + $new_feeds_2 + $new_feeds_3;
            
            // Update existing record with the new values only if they are different from previous values
            if ($new_feeds_1 != $previous_feeds_1 || $new_feeds_2 != $previous_feeds_2 || $new_feeds_3 != $previous_feeds_3 || $total_count != $previous_total_count) {
                $stmt_update = $conn->prepare("UPDATE patient_records SET feeds_1 = ?, feeds_2 = ?, feeds_3 = ?, total_count = ? WHERE hospital_id = ? AND day = ? AND month_name = ? AND year = ?");
                $stmt_update->bind_param("iiiiissi", $new_feeds_1, $new_feeds_2, $new_feeds_3, $total_count, $hospital_id, $day, $month_name, $year);
    
                if ($stmt_update->execute()) {
                    $response = array("status" => "success", "message" => "Data updated successfully");
                } else {
                    $response = array("status" => "error", "message" => "Error updating data: " . $stmt_update->error);
                }
    
                $stmt_update->close();
            } else {
                // No change in values, send response accordingly
                $response = array("status" => "success", "message" => "No changes in data");
            }
        } else {
            // No previous record found, insert new record with the calculated total_count
            $stmt_insert = $conn->prepare("INSERT INTO patient_records (hospital_id, feeds_1, feeds_2, feeds_3, total_count, status, day, month_name, year) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
            // Calculate total count based on new values
            $new_feeds_1 = isset($_POST['feeds_1']) ? (intval($_POST['feeds_1']) ? 1 : 0) : 0;
            $new_feeds_2 = isset($_POST['feeds_2']) ? (intval($_POST['feeds_2']) ? 1 : 0) : 0;
            $new_feeds_3 = isset($_POST['feeds_3']) ? (intval($_POST['feeds_3']) ? 1 : 0) : 0;
            $total_count = $new_feeds_1 + $new_feeds_2 + $new_feeds_3;
            // Determine status based on total_count
            $status = ($total_count > 0) ? 'completed' : 'pending';
            $stmt_insert->bind_param("siiiiisss", $hospital_id, $new_feeds_1, $new_feeds_2, $new_feeds_3, $total_count, $status, $day, $month_name, $year);
    
            if ($stmt_insert->execute()) {
                $response = array("status" => "success", "message" => "Data inserted successfully");
            } else {
                $response = array("status" => "error", "message" => "Error inserting data: " . $stmt_insert->error);
            }
    
            $stmt_insert->close();
        }
    
        // Close statement for checking existing record
        $stmt_check_existing->close();
    
        // Send JSON response back to the client
        header('Content-Type: application/json');
        echo json_encode($response);
    
    } else {
        // If the request method is not POST, return an error response
        header('Content-Type: application/json');
        echo json_encode(array("status" => "error", "message" => "Invalid request method"));
    }
    
    ?>
    
    // If the request method is not POST, return an error response
    header('Content-Type: application/json');
    echo json_encode(array("status" => "error", "message" => "Invalid request method"));
}

?>
