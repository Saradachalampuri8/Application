<?php
require "conn.php";

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if the content type is JSON
    if (strpos($_SERVER["CONTENT_TYPE"], "application/json") !== false) {
        // Get raw JSON data from the request body
        $json_data = file_get_contents("php://input");

        // Decode JSON data into an associative array
        $_POST = json_decode($json_data, true);
    }

    // Check if all required fields are present
    $required_fields = ['hospital_id', 'rul', 'lul', 'rll', 'lll'];
    foreach ($required_fields as $field) {
        if (empty($_POST[$field])) {
            echo json_encode(['status' => 'error', 'message' => $field . ' is required']);
            exit;
        }
    }
    
    // Extract data from the decoded JSON array or form data
    $hospital_id = $_POST['hospital_id'];
    $rul = $_POST['rul'];
    $lul = $_POST['lul'];
    $rll = $_POST['rll'];
    $lll = $_POST['lll'];

    // Insert or update based on whether a record with the given hospital_id exists
    $checkSql = "SELECT * FROM new_patient_status WHERE hospital_id = ?";
    $checkStmt = $conn->prepare($checkSql);
    $checkStmt->bind_param('s', $hospital_id);
    $checkStmt->execute();
    $result = $checkStmt->get_result();

    if ($result->num_rows > 0) {
        // Record with hospital_id already exists, update the record
        $updateSql = "UPDATE new_patient_status SET rul=?, lul=?, rll=?, lll=? WHERE hospital_id=?";
        $updateStmt = $conn->prepare($updateSql);
        $updateStmt->bind_param('sssss', $rul, $lul, $rll, $lll, $hospital_id);

        if ($updateStmt->execute()) {
            echo json_encode(['status' => 'success', 'message' => 'Record updated successfully']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Error updating record']);
        }

        // Close the update statement
        $updateStmt->close();
    } else {
        // Insert new record
        $insertSql = "INSERT INTO new_patient_status (hospital_id, rul, lul, rll, lll) VALUES (?, ?, ?, ?, ?)";
        $insertStmt = $conn->prepare($insertSql);
        $insertStmt->bind_param('sssss', $hospital_id, $rul, $lul, $rll, $lll);

        if ($insertStmt->execute()) {
            echo json_encode(['status' => 'success', 'message' => 'Data inserted successfully']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Error inserting data into the database']);
        }

        // Close the insert statement
        $insertStmt->close();
    }

    // Close the check statement
    $checkStmt->close();
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method']);
}

// Close the database connection
mysqli_close($conn);
?>
