<?php
require "conn.php"; // Include database connection file

// Initializing response array
$response = array();

// Retrieving hospital_id from POST request
$hospital_id = isset($_POST['hospital_id']) ? $_POST['hospital_id'] : '';

// Check if hospital_id is provided
if(empty($hospital_id)) {
    $response['status'] = 'failure';
    $response['message'] = 'Hospital ID is required';
} else {
    // Query to check if the hospital_id exists in the table
    $query = "SELECT notification FROM notification WHERE hospital_id = ?";
    
    // Prepare and execute the query
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $hospital_id); // assuming hospital_id is a string
    $stmt->execute();
    
    // Fetching result
    $result = $stmt->get_result();
    
    // Initializing an array to hold the notifications
    $notifications = array();
    
    // If hospital_id exists, fetch notification data
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $notifications[] = $row['notification'];
        }
        $response['status'] = 'success';
        $response['notifications'] = $notifications;
    } else {
        $response['status'] = 'failure';
        $response['message'] = 'No notifications found for the provided hospital ID';
    }
    
    // Closing statement
    $stmt->close();
}

// Output JSON
header('Content-Type: application/json');
echo json_encode($response);

// Close database connection
$conn->close();
?>
