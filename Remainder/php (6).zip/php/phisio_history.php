<?php

require_once('conn.php');

// Check if the request is a GET request
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Check if search parameters are provided
    if (isset($_GET['exercise_name']) || isset($_GET['hospital_id']) || isset($_GET['month_name'])) {
        // Construct the SELECT query with search conditions
        $select_sql = "SELECT * FROM exercise_records WHERE 1";

        $conditions = [];
        $params = [];
        
        if (isset($_GET['exercise_name'])) {
            $conditions[] = "exercise_name LIKE ?";
            $params[] = '%' . $_GET['exercise_name'] . '%';
        }

        if (isset($_GET['hospital_id'])) {
            $conditions[] = "hospital_id = ?";
            $params[] = $_GET['hospital_id'];
        }

        if (isset($_GET['month_name'])) {
            $conditions[] = "month_name LIKE ?";
            $params[] = '%' . $_GET['month_name'] . '%';
        }

        // Combine conditions with AND
        $select_sql .= " AND " . implode(" AND ", $conditions);

        // Execute the SELECT query
        $select_stmt = $conn->prepare($select_sql);

        if ($select_stmt) {
            // Bind parameters and execute the query
            if (!empty($params)) {
                $types = str_repeat('s', count($params)); // Assume all parameters are strings
                $select_stmt->bind_param($types, ...$params);
            }

            $select_stmt->execute();

            // Get the result set
            $result = $select_stmt->get_result();

            $exercise_records = [];

            while ($row = $result->fetch_assoc()) {
                $exercise_records[] = $row;
            }

            $select_stmt->close();

            // Return JSON response
            header('Content-Type: application/json');
            echo json_encode(['status' => true, 'exercise_records' => $exercise_records]);
        } else {
            // Log the error for development purposes
            error_log("Error preparing SQL statement: " . $conn->error);

            // Return JSON response for error
            header('Content-Type: application/json');
            echo json_encode(['status' => false, 'message' => 'Internal server error']);
        }
    } else {
        // No search parameters provided
        $response = [
            'status' => false,
            'message' => 'No search parameters provided'
        ];

        // Return JSON response
        header('Content-Type: application/json');
        echo json_encode($response);
    }
} else {
    // Invalid request method
    $response = [
        'status' => false,
        'message' => 'Invalid request method'
    ];

    // Return JSON response
    header('Content-Type: application/json');
    echo json_encode($response);
}

$conn->close();
?>
