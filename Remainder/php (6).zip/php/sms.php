<?php
require_once "conn.php";
header("Content-Type: application/json");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    // Check if 'hospital_id' is set in the JSON data
    if (isset($data["hospital_id"])) {
        $hospital_id = $data["hospital_id"];
        
        // Extract boolean values from checkboxes
        $physio_morning = isset($data["physio_morning"]) ? 1 : 0;
        $physio_evening = isset($data["physio_evening"]) ? 1 : 0;

        // Extract day, month, and year from the current date
        $day = date('d');
        $month = date('m');
        $year = date('Y');

        // Check if the record with the same hospital ID, day, month, and year already exists
        $checkDuplicateSql = "SELECT * FROM patient_records WHERE hospital_id = '$hospital_id' AND day = '$day' AND month = '$month' AND year = '$year'";
        $result = $conn->query($checkDuplicateSql);

        if ($result && $result->num_rows > 0) {
            // Update the existing record
            $updateSql = "UPDATE patient_records SET physio_morning = '$physio_morning', physio_evening = '$physio_evening' WHERE hospital_id = '$hospital_id' AND day = '$day' AND month = '$month' AND year = '$year'";

            if ($conn->query($updateSql) === TRUE) {
                $response = array('status' => 'success', 'message' => 'Data updated successfully');
            } else {
                $response = array('status' => 'failure', 'message' => 'Error updating data: ' . $conn->error);
            }
        } else {
            // Insert the new record
            $insertSql = "INSERT INTO patient_records (hospital_id, day, month, year, physio_morning, physio_evening) 
                          VALUES ('$hospital_id', '$day', '$month', '$year', '$physio_morning', '$physio_evening')";

            if ($conn->query($insertSql) === TRUE) {
                $response = array('status' => 'success', 'message' => 'Data inserted successfully');
            } else {
                $response = array('status' => 'failure', 'message' => 'Error inserting data: ' . $conn->error);
            }
        }

        echo json_encode($response);
    } else {
        $response = array('status' => 'failure', 'message' => 'Missing hospital_id in the request');
        echo json_encode($response);
    }
} else {
    $response = array('status' => 'failure', 'message' => 'Invalid request method');
    echo json_encode($response);
}
?>
