<?php
// Include your database connection file
require "conn.php";

// Check if the necessary parameters are provided
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the JSON input
    $jsonInput = file_get_contents("php://input");

    // Decode JSON data into an associative array
    $postData = json_decode($jsonInput, true);

    // Check if JSON decoding was successful
    
        // Sanitize input data to prevent SQL injection
        $patient_name = $_POST['patient_name'];
        $gender = $_POST['gender'];
        $age = $_POST['age'];
        $patient_id = $_POST['patient_id'];
        $diagnosis = $_POST['diagnosis'];
        $mobileno= $_POST['mobileno'];
        $email= $_POST['email'];
        

        // Directory to save uploaded profile pictures
        $uploadDirectory = "profile_images/" . $patient_id . '.jpg';

        // Get the uploaded file details
        $profilePicBase64 = $_POST['profile_image'];
        $profilePicBinary = base64_decode($profilePicBase64);

        // Save the image
        if (file_put_contents($uploadDirectory, $profilePicBinary)) {
            // Update the database with the new information including the profile picture path
            $profilePicPath = $uploadDirectory;
            $query = "INSERT INTO patient_details_danesh (patient_id,patient_name, mobileno,age, gender,email, diagnosis, profile_image)
                      VALUES ('$patient_id','$patient_name', '$mobileno', '$age', '$gender', '$email', '$diagnosis', '$profilePicPath')";

            if (mysqli_query($conn, $query)) {
                echo json_encode(['status' => 'success']);
            } else {
                echo json_encode(['status' => 'error', 'message' => mysqli_error($conn)]);
            }
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to save the image']);
        }
    }
 else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method']);
}

// Close the database connection
mysqli_close($conn);
?>