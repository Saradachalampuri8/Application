<?php
// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Check if hospital_id, day, month_name, and year are provided in the request
    if(isset($_POST['hospital_id']) && isset($_POST['day']) && isset($_POST['month_name']) && isset($_POST['year'])) {
        // Get the provided values
        $hospital_id = $_POST['hospital_id'];
        $day = $_POST['day'];
        $month_name = $_POST['month_name'];
        $year = $_POST['year'];
        
        require_once('conn.php');

        // Prepare the SQL statement to fetch data from patient_records table based on hospital_id, day, month_name, and year
        $sql = "SELECT feeds_1, feeds_2, feeds_3, feeds_4, feeds_5, feeds_6 FROM patient_records WHERE hospital_id = ? AND day = ? AND month_name = ? AND year = ?";
        
        // Prepare the statement
        $stmt = $conn->prepare($sql);
        
        // Bind parameters
        $stmt->bind_param("ssss", $hospital_id, $day, $month_name, $year);
        
        // Execute the statement
        $stmt->execute();
        
        // Get the result
        $result = $stmt->get_result();
        
        // Initialize an array to store the patient records
        $patient_records = array();

        // Checking if there are any results
        if ($result->num_rows > 0) {
            // Fetching data row by row
            while($row = $result->fetch_assoc()) {
                // Adding each row to the patient_records array
                $patient_records[] = $row;
            }
            $response = array(
                "status" => "success",
                "message" => "Patient records found",
                "data" => $patient_records
            );
            echo json_encode($response);
        } else {
            // If no results found
            $response = array(
                "status" => "error",
                "message" => "No patient records found for the provided hospital_id, day, month_name, and year",
                "data" => array()
            );
            echo json_encode($response);
        }

        // Closing the statement
        $stmt->close();

        // Closing the connection
        $conn->close();
    } else {
        // If hospital_id, day, month_name, or year is not provided
        $response = array(
            "status" => "error",
            "message" => "hospital_id, day, month_name, and year not provided",
            "data" => array()
        );
        echo json_encode($response);
    }
} else {
    // Handle the case where the request method is not POST
    $response = array(
        "status" => "error",
        "message" => "Invalid request method",
        "data" => array()
    );
    echo json_encode($response);
}
?>
