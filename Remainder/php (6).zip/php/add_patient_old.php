<?php
// Include your database connection file
require "conn.php";

// Check if the necessary parameters are provided
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize input data to prevent SQL injection
    $name = $conn->real_escape_string($_POST['name']);
    $hospital_id = $conn->real_escape_string($_POST['hospital_id']);
    $password = $conn->real_escape_string($_POST['password']); // Store password as plain text
    $age = $conn->real_escape_string($_POST['age']);
    $gender = $conn->real_escape_string($_POST['gender']);
    $mobile_number = $conn->real_escape_string($_POST['mobile_number']);
    $diagnosis = $conn->real_escape_string($_POST['diagnosis']);
    $patient_status_rul = $conn->real_escape_string($_POST['patient_status_rul']);
    $patient_status_lul = $conn->real_escape_string($_POST['patient_status_lul']);
    $patient_status_rll = $conn->real_escape_string($_POST['patient_status_rll']);
    $patient_status_lll = $conn->real_escape_string($_POST['patient_status_lll']);

    // Check if 'profile_pic' and 'mri' keys exist in $_FILES
    if (isset($_FILES['profile_pic']['name']) && isset($_FILES['mri']['name'])) {
        // Directory to save uploaded files
        $profileImageName = "profile_images/" . $hospital_id . '_profile.jpg';
        $mriImageName = "mri_images/" . $hospital_id . '_mri.jpg';

        // Get the uploaded profile picture details
        $profilePicTmpName = $_FILES['profile_pic']['tmp_name'];

        // Move the uploaded profile picture to the desired location
        if (move_uploaded_file($profilePicTmpName, $profileImageName)) {
            // Profile picture moved successfully, continue with the rest of your script
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to save the profile picture']);
            exit;
        }

        // Get the uploaded MRI file details
        $mriFileTmpName = $_FILES['mri']['tmp_name'];

        // Move the uploaded MRI file to the desired location
        if (move_uploaded_file($mriFileTmpName, $mriImageName)) {
            // MRI file moved successfully, continue with the rest of your script
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to save the MRI file']);
            exit;
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Missing profile picture or MRI file in the request']);
        exit;
    }

    // Add database insert statement for the new columns
    $sql = "INSERT INTO patients (name, hospital_id, password, age, gender, mobile_number, diagnosis, patient_status_rul, patient_status_lul, patient_status_rll, patient_status_lll, mri, profile_image)
            VALUES ('$name', '$hospital_id', '$password', '$age', '$gender', '$mobile_number', '$diagnosis', '$patient_status_rul', '$patient_status_lul', '$patient_status_rll', '$patient_status_lll', '$mriImageName', '$profileImageName')";

    if ($conn->query($sql)) {
        echo json_encode(['status' => 'success', 'message' => 'Data inserted successfully']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Error inserting data into the database: ' . $conn->error]);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method']);
}

// Close the database connection
mysqli_close($conn);
?>
