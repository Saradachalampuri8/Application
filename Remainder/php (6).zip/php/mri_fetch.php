<?php
// Include your database connection file
require "conn.php";

// Set headers to ensure response is treated as JSON
header("Content-Type: application/json");

// Check if the necessary parameters are provided
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the hospital_id from POST data
    $hospital_id = $_POST['hospital_id'];

    // Check if hospital_id is provided
    if (!empty($hospital_id)) {
        // Query to check if the hospital_id exists in the database
        $check_query = "SELECT * FROM patients WHERE hospital_id = '$hospital_id'";
        $check_result = mysqli_query($conn, $check_query);

        // Check if the hospital_id exists
        if (mysqli_num_rows($check_result) > 0) {
            // Query to fetch MRI images for the given hospital_id
            $query = "SELECT mri FROM patients WHERE hospital_id = '$hospital_id'";

            // Execute the query
            $result = mysqli_query($conn, $query);

            // Check if the query was successful
            if ($result) {
                // Initialize an array to store the fetched MRI images
                $mri_images = array();

                // Fetch associative array
                while ($row = mysqli_fetch_assoc($result)) {
                    // Remove backslashes from the MRI image URL and add to the array
                    $mri_images[] = $row['mri'];
                }

                // Free result set
                mysqli_free_result($result);

                // Close the connection
                mysqli_close($conn);

                // If $mri_images is null or contains only null values, set it to an empty array
                if ($mri_images === null || array_filter($mri_images, function($value) { return $value !== null; }) === []) {
                    $mri_images = [];
                }

                // Encode the mri_images array to JSON format
                $json_response = json_encode(['status' => 'success', 'message' => 'Data retrieved successfully', 'mri_images' => $mri_images]);

                // Output the JSON response
                echo $json_response;
                exit; // Stop script execution after sending response
            } else {
                // If the query fails, return an error message
                echo json_encode(['status' => 'error', 'message' => 'Failed to fetch MRI images from the database', 'mri_images' => []]);
            }
        } else {
            // If hospital_id does not exist, return an error message
            echo json_encode(['status' => 'error', 'message' => 'Hospital ID not found', 'mri_images' => []]);
        }
    } else {
        // If hospital_id is not provided, return an error message
        echo json_encode(['status' => 'error', 'message' => 'Hospital ID is required', 'mri_images' => []]);
    }
} else {
    // If the request method is not POST, return an error message
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method', 'mri_images' => []]);
}
?>
