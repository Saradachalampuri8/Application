<?php
// Include your database connection file
require "conn.php";

// Check if the necessary parameters are provided
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the JSON input
    $jsonInput = file_get_contents("php://input");

    // Decode JSON data into an associative array
    $postData = json_decode($jsonInput, true);

    // Check if JSON decoding was successful
    
        // Sanitize input data to prevent SQL injection
        $name = $_POST['name'];
        $gender = $_POST['gender'];
        $age = $_POST['age'];
        $hospital_id = $_POST['hospital_id'];
        $diagnosis = $_POST['diagnosis'];
        $mobile_number= $_POST['mobile_number'];
        $password= $_POST['password'];
        

        // Directory to save uploaded profile pictures
        $uploadDirectory = "profile_images/" . $hospital_id . '.jpg';

        // Get the uploaded file details
        $profilePicBase64 = $_POST['profile_image'];
        $profilePicBinary = base64_decode($profilePicBase64);

        // Save the image
        if (file_put_contents($uploadDirectory, $profilePicBinary)) {
            // Update the database with the new information including the profile picture path
            $profilePicPath = $uploadDirectory;
            $query = "INSERT INTO patients (hospital_id,name, mobile_number,age, gender,password, diagnosis, profile_image)
                      VALUES ('$hospital_id','$name', '$mobile_number', '$age', '$gender', '$password', '$diagnosis', '$profilePicPath')";

            if (mysqli_query($conn, $query)) {
                // Insert hospital_id and password into plogin table
                $ploginQuery = "INSERT INTO plogin (hospital_id, password) VALUES ('$hospital_id', '$password')";
                if (mysqli_query($conn, $ploginQuery)) {
                    echo json_encode(['status' => 'success','message' => 'patient added successfully']);
                } else {
                    echo json_encode(['status' => 'error', 'message' => mysqli_error($conn)]);
                }
            } else {
                echo json_encode(['status' => 'error', 'message' => mysqli_error($conn)]);
            }
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to save the image']);
        }
    }
 else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method']);
}

// Close the database connection
mysqli_close($conn);
?>
