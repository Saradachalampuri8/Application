<?php
// Include your database connection file
require "conn.php";

// Check if the necessary parameters are provided
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the JSON input
    $jsonInput = file_get_contents("php://input");

    // Decode JSON data into an associative array
    $postData = json_decode($jsonInput, true);

    // Sanitize input data to prevent SQL injection
    $patient_status_rul = $_POST['rul'];
    $patient_status_lul = $_POST['lul'];
    $hospital_id = $_POST['hospital_id'];
    $patient_status_rll = $_POST['rll'];
    $patient_status_lll= $_POST['lll'];

    // Directory to save uploaded MRI images
    $uploadDirectory = "mri_images/" . $hospital_id . '.jpg';

    // Get the uploaded file details
    $profilePicBase64 = $_POST['mri'];
    $profilePicBinary = base64_decode($profilePicBase64);

    // Check if a record with the given hospital ID already exists
    $checkQuery = "SELECT * FROM patients WHERE hospital_id = '$hospital_id'";
    $checkResult = mysqli_query($conn, $checkQuery);

    if (mysqli_num_rows($checkResult) > 0) {
        // If a record exists, perform an UPDATE operation
        $query = "UPDATE patients 
                  SET patient_status_rul = '$patient_status_rul', 
                      patient_status_lul = '$patient_status_lul', 
                      patient_status_rll = '$patient_status_rll', 
                      patient_status_lll = '$patient_status_lll', 
                      mri = '$uploadDirectory' 
                  WHERE hospital_id = '$hospital_id'";
    } else {
        // If no record exists, perform an INSERT operation
        $query = "INSERT INTO patients (hospital_id, patient_status_rul, patient_status_lul, patient_status_rll, patient_status_lll, mri) 
                  VALUES ('$hospital_id', '$patient_status_rul', '$patient_status_lul', '$patient_status_rll', '$patient_status_lll', '$uploadDirectory')";
    }

    // Save the image and execute the query
    if (file_put_contents($uploadDirectory, $profilePicBinary) && mysqli_query($conn, $query)) {
        echo json_encode(['status' => 'success','message' => 'patient Status added successfully']);
    } else {
        echo json_encode(['status' => 'error', 'message' => mysqli_error($conn)]);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method']);
}

// Close the database connection
mysqli_close($conn);
?>
