<?php
require "conn.php"; // Include database connection file

// Initializing response array
$response = array();

// Get current date
$current_date = date("Y-m-d");

// Query to insert notifications based on certain conditions
$insert_query = "INSERT INTO notification (hospital_id, notification) 
                 SELECT pr.hospital_id, 
                    CASE 
                        WHEN ('$current_date' NOT IN (SELECT CONCAT(year,'-',LPAD(month,2,'0'),'-',LPAD(day,2,'0')) FROM patients WHERE hospital_id = pr.hospital_id)) THEN 'It\'s time to check patients for today.'
                        WHEN (CURTIME() >= '08:01:00' AND CURTIME() < '08:02:00' AND pr.physio_morning = 0) THEN 'It\'s time to do morning physiotherapy task.'
                        ELSE 'No notification at this time.'
                    END AS notification
                 FROM patient_records pr
                 WHERE pr.hospital_id = ?";

// Prepare the insertion query
$stmt_insert = $conn->prepare($insert_query);

// Retrieving hospital_id from POST request
$hospital_id = isset($_POST['hospital_id']) ? $_POST['hospital_id'] : '';

// Only execute insertion query if hospital_id is provided
if (!empty($hospital_id)) {
    // Execute the insertion query
    $stmt_insert->bind_param("s", $hospital_id); // assuming hospital_id is a string
    $stmt_insert->execute();

    // Check if insertion was successful
    if ($stmt_insert->affected_rows > 0) {
        $response['insert_status'] = 'success';
    } else {
        $response['insert_status'] = 'failure';
        $response['insert_message'] = 'No notifications inserted for the provided hospital ID';
    }
}

// Close the insertion statement
$stmt_insert->close();

// Query to delete notifications where current time is 00:00:00
$delete_query = "DELETE FROM notification WHERE TIME(CURTIME()) = '00:00:00'";
$conn->query($delete_query);

// Retrieving hospital_id from POST request
$hospital_id = isset($_POST['hospital_id']) ? $_POST['hospital_id'] : '';

// Only execute the fetch query if hospital_id is provided
if (!empty($hospital_id)) {
    // Query to fetch notifications for a specific hospital ID
    $query = "SELECT notification FROM notification WHERE hospital_id = ?";

    // Prepare and execute the query
    $stmt_fetch = $conn->prepare($query);
    $stmt_fetch->bind_param("s", $hospital_id); // assuming hospital_id is a string
    $stmt_fetch->execute();

    // Fetching result
    $result = $stmt_fetch->get_result();

    // Initializing an array to hold the notifications
    $notifications = array();

    // If hospital_id exists, fetch notification data
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $notifications[] = $row['notification'];
        }
        $response['fetch_status'] = 'success';
        $response['notifications'] = $notifications;
    } else {
        $response['fetch_status'] = 'failure';
        $response['fetch_message'] = 'No notifications found for the provided hospital ID';
    }

    // Closing statement
    $stmt_fetch->close();
}

// Output JSON
header('Content-Type: application/json');
echo json_encode($response);

// Close database connection
$conn->close();
?>
