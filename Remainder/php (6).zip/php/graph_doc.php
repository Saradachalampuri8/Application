<?php
// Initialize response array
$response = array();

// Include database connection file
require_once('conn.php');

// Check if hospital_id is provided in the request
if(isset($_POST['hospital_id'])) {
    // Sanitize hospital_id to prevent SQL injection
    $hospital_id = mysqli_real_escape_string($conn, $_POST['hospital_id']);

    // Check if hospital_id exists in the database
    $checkQuery = "SELECT COUNT(*) AS count FROM patient_records WHERE hospital_id = '$hospital_id'";
    $checkResult = mysqli_query($conn, $checkQuery);
    
    if ($checkResult) {
        $row = mysqli_fetch_assoc($checkResult);
        if ($row['count'] == 0) {
            // If hospital_id not found, return error response with empty data
            $response['status'] = "error";
            $response['message'] = "No records found for the provided hospital ID";
            $response['data'] = array();
            echo json_encode($response);
            exit;
        }
    } else {
        // If query execution fails, return error response
        $response['status'] = "error";
        $response['message'] = "Query execution failed";
        echo json_encode($response);
        exit;
    }

    // Array to hold the total_count for each date
    $totalCountData = array();

    // Get the current date
    $currentDay = date('d');

    // Loop through the past 7 days (including today)
    for ($i = 0; $i < 7; $i++) {
        // Calculate the date for the current iteration (going back in time)
        $targetDay = date('d', strtotime("-$i days"));
        $targetMonth = date('F', strtotime("-$i days"));
        $targetYear = date('Y', strtotime("-$i days"));

        // Query to get the total count for the current date and hospital_id
        $query = "SELECT COALESCE(SUM(total_count), 0) AS total_count FROM patient_records WHERE day = '$targetDay' AND month_name = '$targetMonth' AND year = '$targetYear' AND hospital_id = '$hospital_id'";
        $result = mysqli_query($conn, $query);

        if ($result) {
            $row = mysqli_fetch_assoc($result);
            $totalCount = $row['total_count'];

            // Store the total_count for the current date in the array
            $totalCountData[] = array('date' => $targetDay, 'total_count' => $totalCount);
        } else {
            // If query execution fails, return error response
            $response['status'] = "error";
            $response['message'] = "Query execution failed";
            echo json_encode($response);
            exit;
        }
    }

    // Check if any data was retrieved
    if (empty($totalCountData)) {
        // If no records found, return error response with empty data
        $response['status'] = "error";
        $response['message'] = "No records found for the provided hospital ID";
        $response['data'] = array();
        echo json_encode($response);
        exit;
    }

    // Close database connection
    mysqli_close($conn);

    // Return total_count data as JSON response
    $response['status'] = "success";
    $response['message'] = "Total count data retrieved successfully";
    $response['data'] = $totalCountData;
    header('Content-Type: application/json');
    echo json_encode($response);
} else {
    // If hospital_id is not provided in the request
    $response['status'] = "error";
    $response['message'] = "No records found for the provided hospital ID";
    echo json_encode($response);
}
?>
