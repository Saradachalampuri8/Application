<?php
// Include your database connection file
require "conn.php";

// Set the appropriate HTTP response headers
header('Content-Type: application/json');

// Check if all required fields are provided
if (
    isset($_POST['name']) && 
    isset($_POST['hospital_id']) && 
    isset($_POST['password']) && 
    isset($_POST['age']) && 
    isset($_POST['gender']) && 
    isset($_POST['diagnosis']) && 
    isset($_POST['mobile_number'])
) {
    // Sanitize input data to prevent SQL injection
    $name = $_POST['name'];
    $hospital_id = $_POST['hospital_id'];
    $password = $_POST['password'];
    $age = intval($_POST['age']);
    $gender = $_POST['gender'];
    $diagnosis = $_POST['diagnosis'];
    $mobile_number = $_POST['mobile_number'];

    // Check if a profile image is uploaded
    if (isset($_FILES['profile_image']['name']) && !empty($_FILES['profile_image']['name'])) {
        // Process the profile image
        $profile_image_tmp = $_FILES['profile_image']['tmp_name'];
        $profile_image_filename = $hospital_id . '.jpg';
        $profile_image_path = 'profile_images/' . $profile_image_filename;
        move_uploaded_file($profile_image_tmp, $profile_image_path);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Profile image is required']);
        exit();
    }

    // Insert patient information into the patients table
    $query_patients = "INSERT INTO patients (name, hospital_id, age, gender, diagnosis, mobile_number, password, profile_image) 
              VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        
    $stmt_patients = $conn->prepare($query_patients);
    $stmt_patients->bind_param('ssisssss', $name, $hospital_id, $age, $gender, $diagnosis, $mobile_number, $password, $profile_image_filename);

    // Execute the query to insert patient information
    $patients_inserted = $stmt_patients->execute();

    if ($patients_inserted) {
        // Insert successful
        // Now insert into plogin table
        $query_plogin = "INSERT INTO plogin (hospital_id, password) VALUES (?, ?)";
        $stmt_plogin = $conn->prepare($query_plogin);
        $stmt_plogin->bind_param('ss', $hospital_id, $password);
        
        // Execute the query to insert login information
        $plogin_inserted = $stmt_plogin->execute();

        if ($plogin_inserted) {
            // Both inserts successful
            echo json_encode(['status' => 'success', 'message' => 'Patient added successfully']);
        } else {
            // Insert into plogin failed
            echo json_encode(['status' => 'error', 'message' => 'Error inserting login information: ' . $stmt_plogin->error]);
        }
    } else {
        // Insert into patients failed
        echo json_encode(['status' => 'error', 'message' => 'Error inserting patient information: ' . $stmt_patients->error]);
    }

    // Close the prepared statements
    $stmt_patients->close();
    $stmt_plogin->close();
} else {
    echo json_encode(['status' => 'error', 'message' => 'Missing required fields']);
}

// Close the database connection
$conn->close();
?>
