-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 09, 2024 at 11:31 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sample`
--

-- --------------------------------------------------------

--
-- Table structure for table `app_notifications`
--

CREATE TABLE `app_notifications` (
  `s_no` int(11) NOT NULL,
  `timings` time DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `app_notifications`
--

INSERT INTO `app_notifications` (`s_no`, `timings`, `message`) VALUES
(1, '08:55:00', 'Sample notification message');

-- --------------------------------------------------------

--
-- Table structure for table `dlogin`
--

CREATE TABLE `dlogin` (
  `s_no` int(11) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dlogin`
--

INSERT INTO `dlogin` (`s_no`, `username`, `password`) VALUES
(1, 'D01', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `doc_profile`
--

CREATE TABLE `doc_profile` (
  `s_no` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `doc_id` varchar(200) NOT NULL,
  `age` int(11) DEFAULT NULL,
  `gender` varchar(100) DEFAULT NULL,
  `contact_no` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `doc_profile`
--

INSERT INTO `doc_profile` (`s_no`, `name`, `doc_id`, `age`, `gender`, `contact_no`) VALUES
(1, 'Dr.Vijay', 'D01', 30, 'Male', '9154467911'),
(3, 'saradha', 'D001', 22, 'female', '9856741235'),
(4, 'saradha', 'D001', 22, 'female', '9856741235'),
(5, 'saradha', 'D001', 22, 'female', '9856741235'),
(6, 'saradha', 'D002', 22, 'female', '9856741235');

-- --------------------------------------------------------

--
-- Table structure for table `exercise_records`
--

CREATE TABLE `exercise_records` (
  `record_id` int(11) NOT NULL,
  `exercise_name` varchar(255) NOT NULL,
  `hospital_id` int(11) NOT NULL,
  `day` int(11) NOT NULL,
  `month_name` varchar(20) NOT NULL,
  `year` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `exercise_records`
--

INSERT INTO `exercise_records` (`record_id`, `exercise_name`, `hospital_id`, `day`, `month_name`, `year`) VALUES
(1, 'Jogging', 123, 15, 'January', 2022),
(2, 'Weight Lifting', 2, 10, 'February', 2022),
(3, 'Yoga', 3, 5, 'March', 2022),
(4, 'Cycling', 1, 20, 'April', 2022),
(5, 'Swimming', 2, 15, 'May', 2022);

-- --------------------------------------------------------

--
-- Table structure for table `foleys_ryles`
--

CREATE TABLE `foleys_ryles` (
  `sno` int(11) NOT NULL,
  `hospital_id` varchar(255) NOT NULL,
  `foleys` date NOT NULL,
  `ryles` date NOT NULL,
  `date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `foleys_ryles`
--

INSERT INTO `foleys_ryles` (`sno`, `hospital_id`, `foleys`, `ryles`, `date`) VALUES
(75, 'P000081', '2024-04-24', '2024-04-24', '2024-04-24'),
(81, 'P00009', '0000-00-00', '2023-02-08', '2023-02-08'),
(82, 'P00009', '2024-04-24', '2023-03-19', '2024-04-24'),
(83, 'P000091', '2024-04-24', '2023-02-08', '2024-04-24'),
(84, 'P000001', '0000-00-00', '2023-02-08', '2023-02-08'),
(85, 'P0000011', '0000-00-00', '2023-02-08', '2024-04-24'),
(86, 'P00009', '2023-05-01', '2023-03-19', '2024-04-24'),
(87, 'P000012', '2023-05-01', '2023-04-29', '2024-04-24'),
(88, 'P000012', '2023-05-01', '2023-04-29', '2024-04-25'),
(89, 'P00001', '2024-04-25', '2024-04-25', '2024-04-25'),
(102, 'P00008', '2024-04-24', '2024-04-24', '2024-04-25'),
(103, 'P00008', '2024-05-04', '2024-05-04', '2024-05-04'),
(104, 'P000078', '2024-05-07', '2024-05-07', '2024-05-07');

-- --------------------------------------------------------

--
-- Table structure for table `medication`
--

CREATE TABLE `medication` (
  `s_no` int(11) NOT NULL,
  `patient_id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `medication_name` varchar(255) NOT NULL,
  `medication_form` varchar(255) NOT NULL,
  `morning` int(11) NOT NULL,
  `afternoon` int(11) NOT NULL,
  `night` int(11) NOT NULL,
  `before_food` int(11) NOT NULL,
  `after_food` int(11) NOT NULL,
  `first_intake` time DEFAULT NULL,
  `second_intake` time DEFAULT NULL,
  `third_intake` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `medication`
--

INSERT INTO `medication` (`s_no`, `patient_id`, `name`, `medication_name`, `medication_form`, `morning`, `afternoon`, `night`, `before_food`, `after_food`, `first_intake`, `second_intake`, `third_intake`) VALUES
(99, 'SMCP001', 'Rose', 'T.Tenegliptin-20mg', 'pill', 1, 0, 1, 1, 0, '08:30:00', '00:00:00', '08:00:00'),
(100, 'SMCP001', 'Rose', 'T.Metformin-500mg', 'pill', 1, 0, 1, 1, 0, '08:30:00', '12:00:00', '08:00:00'),
(104, 'SMCP001', 'Rose', 'T.Omez 20mg', 'Pill', 1, 0, 1, 1, 0, '08:25:00', '00:00:00', '08:00:00'),
(105, 'SMCP001', 'Rose', 'T.Melcovit Gold', 'Pill', 1, 0, 1, 0, 1, '09:00:00', '00:00:00', '08:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `new_patient_status`
--

CREATE TABLE `new_patient_status` (
  `s_no` int(11) NOT NULL,
  `hospital_id` varchar(255) DEFAULT NULL,
  `rul` varchar(255) DEFAULT NULL,
  `lul` varchar(255) DEFAULT NULL,
  `rll` varchar(255) DEFAULT NULL,
  `lll` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `new_patient_status`
--

INSERT INTO `new_patient_status` (`s_no`, `hospital_id`, `rul`, `lul`, `rll`, `lll`) VALUES
(1, '123456', '1', '1', '1', '1'),
(6, '123456', '4', '4', '3', '5'),
(7, 'P000021', '3', '3', '2', '4'),
(8, '123456', '2', '2', '2', '2'),
(9, '123456', '3', '4', '2', '1'),
(10, 'P00009', '3', '3', '3', '4'),
(11, '1234561', '3', '3', '3', '4'),
(12, 'P00008', '4', '3', '2', '3'),
(13, 'P00001', '3', '2', '1', '5');

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE `notification` (
  `s_no` int(11) NOT NULL,
  `hospital_id` varchar(255) DEFAULT NULL,
  `notification` varchar(755) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notification`
--

INSERT INTO `notification` (`s_no`, `hospital_id`, `notification`) VALUES
(1, 'example_hospital_id', 'It\'s time to do foleys and ryles.'),
(2, 'P001', 'It\'s time to do foleys and ryles.'),
(3, 'P00003', 'It\'s time for feeds_3 task.'),
(4, 'P00004', 'It\'s time for feeds_3 task.'),
(5, 'P00008', 'It\'s time for feeds_3 task.'),
(6, 'P2322', 'It\'s time for feeds_3 task.'),
(10, 'example_hospital_id', 'It\'s time to do foleys and ryles.'),
(11, 'P001', 'It\'s time to do foleys and ryles.'),
(12, 'example_hospital_id', 'It\'s time to do foleys and ryles.'),
(13, 'P001', 'It\'s time to do foleys and ryles.'),
(14, 'P00003', NULL),
(15, 'P00003', NULL),
(16, 'P00003', NULL),
(17, 'P00004', NULL),
(18, 'P00003', NULL),
(19, 'P00004', NULL),
(20, 'P00003', NULL),
(21, 'P00008', NULL),
(22, 'P2322', NULL),
(29, 'P00003', NULL),
(30, 'P00003', NULL),
(31, 'P00003', NULL),
(32, 'P00004', NULL),
(33, 'P00003', NULL),
(34, 'P00004', NULL),
(35, 'P00003', NULL),
(36, 'P00008', NULL),
(37, 'P2322', NULL),
(44, 'P00003', 'No notification at this time.'),
(45, 'P00003', 'No notification at this time.'),
(46, 'P00003', 'No notification at this time.'),
(47, 'P00004', 'No notification at this time.'),
(48, 'P00003', 'No notification at this time.'),
(49, 'P00004', 'No notification at this time.'),
(50, 'P00003', 'No notification at this time.'),
(51, 'P00008', 'No notification at this time.'),
(52, 'P2322', 'No notification at this time.'),
(59, 'P00003', 'No notification at this time.'),
(60, 'P00003', 'No notification at this time.'),
(61, 'P00003', 'No notification at this time.'),
(62, 'P00004', 'No notification at this time.'),
(63, 'P00003', 'No notification at this time.'),
(64, 'P00004', 'No notification at this time.'),
(65, 'P00003', 'No notification at this time.'),
(66, 'P00008', 'No notification at this time.'),
(67, 'P2322', 'No notification at this time.'),
(68, 'P00003', 'No notification at this time.'),
(69, 'P00003', 'No notification at this time.'),
(70, 'P00003', 'No notification at this time.'),
(71, 'P00004', 'No notification at this time.'),
(72, 'P00003', 'No notification at this time.'),
(73, 'P00004', 'No notification at this time.'),
(74, 'P00003', 'No notification at this time.'),
(75, 'P00008', 'No notification at this time.'),
(76, 'P2322', 'No notification at this time.'),
(83, 'P00003', 'It\'s time to check patients for today.'),
(84, 'P00003', 'It\'s time to check patients for today.'),
(85, 'P00003', 'It\'s time to check patients for today.'),
(86, 'P00004', 'It\'s time to check patients for today.'),
(87, 'P00003', 'It\'s time to check patients for today.'),
(88, 'P00004', 'It\'s time to check patients for today.'),
(89, 'P00003', 'It\'s time to check patients for today.'),
(90, 'P00008', 'It\'s time to check patients for today.'),
(91, 'P2322', 'It\'s time to check patients for today.'),
(92, 'example_hospital_id', 'It\'s time to do foleys and ryles.'),
(93, 'P001', 'It\'s time to do foleys and ryles.'),
(94, 'example_hospital_id', 'It\'s time to do foleys and ryles.'),
(95, 'P001', 'It\'s time to do foleys and ryles.'),
(96, 'example_hospital_id', 'It\'s time to do foleys and ryles.'),
(97, 'P001', 'It\'s time to do foleys and ryles.'),
(98, 'example_hospital_id', 'It\'s time to do foleys and ryles.'),
(99, 'P001', 'It\'s time to do foleys and ryles.');

-- --------------------------------------------------------

--
-- Table structure for table `notify`
--

CREATE TABLE `notify` (
  `id` int(11) NOT NULL,
  `message` varchar(255) NOT NULL,
  `timing` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notify`
--

INSERT INTO `notify` (`id`, `message`, `timing`) VALUES
(1, 'Physiotherapy and Feeds: Time for physiotherapy and feeding. Let\'s improve mobility and nourish your body!', '08:00:00'),
(2, 'Bed change positions: Adjust bed position for comfort', '09:00:00'),
(3, 'Bed sores:Prevent bed sores. Change positions regularly.', '10:00:00'),
(4, 'Feeds and Bed Change Positions: Time for feeds and adjusting bed position. Nourish your body and find comfort.', '01:00:00'),
(5, 'Feeds: Time for feeding. Replenish and energize your body.', '11:00:00'),
(6, 'Physiotherapy and Feeds: It\'s time for eating and physical treatment. Improve your range of motion while feeding your body!', '16:00:00'),
(7, 'Bed Change Positions: Time to change your sleeping setup! Adjust your bed for a comfy snooze', '17:00:00'),
(8, 'Feeds: It\'s mealtime! Fuel up with a delicious feast to power through the day.', '19:00:00'),
(9, 'Bed Sores: Stay comfy, stay healthy! Shift positions regularly to prevent bed sores.', '20:00:00'),
(10, 'Bed change positions and Feeds: Time for a change! Adjust your bed position and grab a bite to keep cozy and fueled.', '21:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE `patients` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `hospital_id` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `age` int(11) DEFAULT NULL,
  `gender` enum('Male','Female','Other') DEFAULT NULL,
  `mobile_number` varchar(15) DEFAULT NULL,
  `diagnosis` text DEFAULT NULL,
  `patient_status_rul` varchar(50) DEFAULT NULL,
  `patient_status_lul` varchar(50) NOT NULL,
  `patient_status_rll` varchar(50) NOT NULL,
  `patient_status_lll` varchar(50) NOT NULL,
  `mri` varchar(255) DEFAULT NULL,
  `profile_image` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`id`, `name`, `hospital_id`, `password`, `age`, `gender`, `mobile_number`, `diagnosis`, `patient_status_rul`, `patient_status_lul`, `patient_status_rll`, `patient_status_lll`, `mri`, `profile_image`) VALUES
(368, 'Elamaran', 'P00008', '0008', 47, 'Male', '123435233', 'cold', '3', '4', '5', '2', 'mri_images/P00008.jpg', 'profile_images/P00008.jpg'),
(371, 'manasa', '123456', '0009', 45, 'Female', '123435233', 'cold', '7', '3', '4', '3', 'mri_images/P00009.jpg', 'profile_images/P00009.jpg'),
(372, 'sarada', 'P00001', '0001', 34, 'Female', '123435233', 'cold', '4', '3', '3', '4', 'mri_images/P00001.jpg', 'profile_images/P00001.jpg'),
(374, 'manasa', '34532', '4532', 45, 'Female', '123435233', 'cold', '4', '5', '5', '4', 'mri_images/34532.jpg', 'profile_images/34532.jpg'),
(407, 'sahithi', 'P000022', '0022', 45, 'Female', '1478521478', 'cold', '3', '2', '3', '3', 'mri_images/P000022.jpg', 'profile_images/P000022.jpg'),
(408, 'ajay', 'P000078', '0078', 34, 'Male', '1478521452', 'cold', '4', '2', '3', '4', 'mri_images/P000078.jpg', 'profile_images/P000078.jpg'),
(423, 'tabahi', 'P000078', 'P000078', 45, 'Male', '5364424642', 'ggbdggr', '4', '2', '3', '4', 'mri_images/P000078.jpg', 'profile_images/P000078.jpg'),
(424, 'Hema', 'P000013', 'P000013', 45, 'Female', '1478521452', 'vgcfcd', '8', '5', '4', '1', 'mri_images/P000013.jpg', 'profile_images/P000013.jpg'),
(425, 'Trisha to', 'P000014', '0014', 34, 'Female', '1234512331', 'aweaw', '3', '2', '3', '2', 'mri_images/P000014.jpg', 'profile_images/P000014.jpg'),
(426, '', 'P000067', '0067', 0, '', '', '', '4', '3', '2', '2', 'mri_images/P000067.jpg', 'profile_images/P000067.jpg'),
(427, 'Saradha', 'p68547', '8547', 254, 'Male', '8574968571244', 'jhbsdchv', '4', '5', '5', '2', 'mri_images/p68547.jpg', 'profile_images/p68547.jpg'),
(428, 'sahithi', 'P000015', '0015', 23, 'Female', '147852014', 'cold', '3', '2', '1', '2', 'mri_images/P000015.jpg', 'profile_images/P000015.jpg'),
(429, 'Amar', 'P000016', '0016', 34, 'Male', '1232341232', 'cold', '3', '4', '2', '1', 'mri_images/P000016.jpg', 'profile_images/P000016.jpg'),
(430, 'Harshi', 'P000016', '0016', 45, 'Female', '1232342341', 'cold', '3', '4', '2', '1', 'mri_images/P000016.jpg', 'profile_images/P000016.jpg'),
(431, 'anu', 'P000018', '0018', 45, 'Female', '132343234', 'cold', '2', '3', '1', '3', 'mri_images/P000018.jpg', 'profile_images/P000018.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `patient_details_danesh`
--

CREATE TABLE `patient_details_danesh` (
  `s_no` int(11) NOT NULL,
  `patient_id` varchar(50) DEFAULT NULL,
  `patient_name` varchar(255) NOT NULL,
  `age` int(11) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `mobileno` varchar(15) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `profile_image` text DEFAULT NULL,
  `diagnosis` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patient_details_danesh`
--

INSERT INTO `patient_details_danesh` (`s_no`, `patient_id`, `patient_name`, `age`, `gender`, `mobileno`, `email`, `profile_image`, `diagnosis`) VALUES
(1, 'P0078654', 'anshu', 67, 'female', '987654321', 'saradachalampuri@gmail.com', 'profile_images/P0078654.jpg', 'fever'),
(2, 'P12345', 'sarada', 42, 'Male', '', 'saradachalampuri@gmail.com', 'profile_images/P12345.jpg', 'dtrc'),
(3, 'P09876', 'ex', 45, 'Female', '2123445666', 'ex@gmail.com', 'profile_images/P09876.jpg', 'gfdc'),
(4, 'P09876', 'ex', 45, 'Female', '2123445666', 'ex@gmail.com', 'profile_images/P09876.jpg', 'gfdc');

-- --------------------------------------------------------

--
-- Table structure for table `patient_records`
--

CREATE TABLE `patient_records` (
  `id` int(11) NOT NULL,
  `hospital_id` varchar(255) NOT NULL,
  `day` int(11) DEFAULT NULL,
  `month_name` varchar(255) DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  `physio_morning` tinyint(1) DEFAULT NULL,
  `physio_evening` tinyint(1) DEFAULT NULL,
  `bedpositions_1` tinyint(1) DEFAULT NULL,
  `bedpositions_2` tinyint(1) DEFAULT NULL,
  `bedpositions_3` tinyint(1) DEFAULT NULL,
  `bedpositions_4` tinyint(1) DEFAULT NULL,
  `bedsores_1` tinyint(1) DEFAULT NULL,
  `bedsores_2` tinyint(1) DEFAULT NULL,
  `feeds_1` tinyint(1) DEFAULT NULL,
  `feeds_2` tinyint(1) DEFAULT NULL,
  `feeds_3` tinyint(1) DEFAULT NULL,
  `feeds_4` tinyint(1) DEFAULT NULL,
  `feeds_5` tinyint(1) DEFAULT NULL,
  `feeds_6` tinyint(1) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `total_count` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patient_records`
--

INSERT INTO `patient_records` (`id`, `hospital_id`, `day`, `month_name`, `year`, `physio_morning`, `physio_evening`, `bedpositions_1`, `bedpositions_2`, `bedpositions_3`, `bedpositions_4`, `bedsores_1`, `bedsores_2`, `feeds_1`, `feeds_2`, `feeds_3`, `feeds_4`, `feeds_5`, `feeds_6`, `status`, `total_count`) VALUES
(85, 'P00003', 22, 'February', 2024, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, NULL, 'completed', 4),
(86, 'P00003', 23, 'February', 2024, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, 'not_completed', 0),
(87, 'P00003', 24, 'February', 2024, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, NULL, NULL, NULL, 'completed', 2),
(88, 'P00004', 25, 'February', 2024, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, 'not_completed', 0),
(89, 'P00003', 27, 'February', 2024, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, 'not_completed', 0),
(90, 'P00004', 27, 'February', 2024, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, 'not_completed', 0),
(91, 'P00003', 28, 'February', 2024, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, 'not_completed', 0),
(92, 'P00008', 28, 'February', 2024, 1, 1, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 'completed', 5),
(93, 'P2322', 12, 'March', 2024, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, 'completed', 1),
(94, 'P00008', 9, 'March', 2024, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, NULL, NULL, NULL, 'completed', 3),
(95, 'P2322', 12, 'March', 2024, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, 'completed', 1),
(96, 'ABC123', 1, 'April', 2024, 1, 0, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, NULL, 1, 'completed', 9),
(97, 'ABC122', 1, 'April', 2024, 1, 0, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 'completed', 10),
(98, 'ABC1202', 1, 'April', 2024, 1, 0, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 'completed', 9),
(100, 'P00008', 15, 'April', 2024, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 'completed', 2),
(104, 'P00008', 16, 'April', 2024, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'completed', 1),
(105, 'P00009', 16, 'April', 2024, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'completed', 1),
(112, 'P0045', 16, 'April', 2024, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'completed', 2),
(117, 'P00011', 17, 'April', 2024, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 'completed', 4),
(118, 'P00011', 18, 'April', 2024, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 'completed', 7),
(119, 'P0001', 18, 'April', 2024, 1, 1, 1, 1, 0, 0, 1, 0, 1, 1, 0, 0, 0, 0, 'completed', 7),
(120, 'P00009', 19, 'April', 2024, 1, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 0, 'completed', 5),
(121, 'P00008', 19, 'April', 2024, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'completed', 2),
(122, 'P00001', 19, 'April', 2024, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'completed', 2),
(123, 'P00008', 23, 'April', 2024, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'completed', 2),
(124, 'P00001', 23, 'April', 2024, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 'completed', 7),
(125, 'P00008', 27, 'April', 2024, 1, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 'completed', 3),
(126, 'P00008', 4, 'May', 2024, 1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 'completed', 4),
(127, 'P00008', 6, 'May', 2024, 1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 'completed', 3),
(128, 'P000078', 7, 'May', 2024, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 'completed', 7),
(129, 'P00008', 9, 'May', 2024, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'completed', 1);

-- --------------------------------------------------------

--
-- Table structure for table `plogin`
--

CREATE TABLE `plogin` (
  `hospital_id` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `plogin`
--

INSERT INTO `plogin` (`hospital_id`, `password`) VALUES
('p1', 'p123'),
('hospital2', 'securepass456'),
('hospital3', 'strongpass789'),
('p2', '12345'),
('123', 'p12345'),
('', ''),
('', ''),
('', ''),
('', ''),
('hospital123', 'securepassword'),
('hospital123', 'securepassword'),
('P09876', '9876'),
('P0098', '0098'),
('P00234', '0234'),
('P453455', '3455'),
('P00987', '0987'),
('67555343', '5343'),
('P0078', '23456'),
('P0078', '23456'),
('P00781', '23456'),
('P00142', '0142'),
('P00678', '0678'),
('P006780', '6780'),
('P875664', '5664'),
('P002341', '2341'),
('P0098761', '8761'),
('P0098761', '8761'),
('P0098761', '8761'),
('P0098761', '8761'),
('P004563', '4563'),
('P004563', '4563'),
('P0098767', '8767'),
('androidx.appcompat.widget.AppCompatEditText{5a2364d VFED..CL. ........ 0,168-1194,336 #7f09013d app:', '8675'),
('P0653526', '3526'),
('P6623', '6623'),
('P00003', '0003'),
('P00004', '0004'),
('P00005', '0005'),
('3542252', '2252'),
('3454', '3454'),
('2345', '2345'),
('22211', '2211'),
('542544', '2544'),
('21223', '1223'),
('33133', '3133'),
('P00001', '0001'),
('P00003', '0003'),
('P00002', '0002'),
('P00005', '0005'),
('P00006', '0006'),
('P00006', '0006'),
('P00006', '0006'),
('P00007', '0007'),
('P00008', '0008'),
('4567345', '7345'),
('12345', '2345'),
('P00009', '0009'),
('P00001', '0001'),
('23563', '3563'),
('34532', '4532'),
('P000021', '12342'),
('P000021', '12342'),
('P000021', '12342'),
('P000021', '12342'),
('d2024001', '4001'),
('', ''),
('3333', '3333'),
('ggdfg', 'ggdfg'),
('0001', '0001'),
('1111', '1111'),
('4444', '4444'),
('Goff', 'Goff'),
('hgh', 'hgh'),
('P2024002', 'P2024002'),
('113232', '113232'),
('h0008', 'h0008'),
('h0008', 'h0008'),
('s0023', 's0023'),
('r0034', 'r0034'),
('s0045', 's0045'),
('P000021', '12342'),
('0045', '0045'),
('P000021', '12342'),
('P00002143', '12342'),
('P000021430', '12342'),
('P000021430', '12342'),
('P000021430', '12342'),
('P0000214301', '12342'),
('234566', '4566'),
('', ''),
('D2024002', 'D2024002'),
('', ''),
('P000022', '0022'),
('P000078', '0078'),
('P0000214301', '12342'),
('P123412', '12342'),
('e1123', 'e1123'),
('P123412', '12342'),
('P1234120', '12342'),
('', ''),
('P1234120', '12342'),
('ffff', 'ffff'),
('ddddd', 'ddddd'),
('H0001', 'H0001'),
('Foch', 'Foch'),
('evwev', 'evwev'),
('P000015', 'P000015'),
('b2001', 'b2001'),
('P000078', 'P000078'),
('P000013', 'P000013'),
('P000014', '0014'),
('P000067', '0067'),
('p68547', '8547'),
('P000015', '0015'),
('P000016', '0016'),
('P000016', '0016'),
('P000018', '0018');

-- --------------------------------------------------------

--
-- Table structure for table `profiles`
--

CREATE TABLE `profiles` (
  `user_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(100) NOT NULL,
  `hospital_id` varchar(20) NOT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `contact` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `profiles`
--

INSERT INTO `profiles` (`user_id`, `username`, `password`, `hospital_id`, `gender`, `age`, `contact`) VALUES
(1, 'Rathan', '123', '346', 'male', 39, '9988999889');

-- --------------------------------------------------------

--
-- Table structure for table `videos`
--

CREATE TABLE `videos` (
  `id` int(11) NOT NULL,
  `video_url` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `videos`
--

INSERT INTO `videos` (`id`, `video_url`) VALUES
(12, 'uploads/videos/file_example_MP4_480_1_5MG.mp4');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `app_notifications`
--
ALTER TABLE `app_notifications`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `dlogin`
--
ALTER TABLE `dlogin`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `doc_profile`
--
ALTER TABLE `doc_profile`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `exercise_records`
--
ALTER TABLE `exercise_records`
  ADD PRIMARY KEY (`record_id`);

--
-- Indexes for table `foleys_ryles`
--
ALTER TABLE `foleys_ryles`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `new_patient_status`
--
ALTER TABLE `new_patient_status`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `notification`
--
ALTER TABLE `notification`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `notify`
--
ALTER TABLE `notify`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `patients`
--
ALTER TABLE `patients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `patient_details_danesh`
--
ALTER TABLE `patient_details_danesh`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `patient_records`
--
ALTER TABLE `patient_records`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `profiles`
--
ALTER TABLE `profiles`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `hospital_id` (`hospital_id`);

--
-- Indexes for table `videos`
--
ALTER TABLE `videos`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `app_notifications`
--
ALTER TABLE `app_notifications`
  MODIFY `s_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `dlogin`
--
ALTER TABLE `dlogin`
  MODIFY `s_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `doc_profile`
--
ALTER TABLE `doc_profile`
  MODIFY `s_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `exercise_records`
--
ALTER TABLE `exercise_records`
  MODIFY `record_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `foleys_ryles`
--
ALTER TABLE `foleys_ryles`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=105;

--
-- AUTO_INCREMENT for table `new_patient_status`
--
ALTER TABLE `new_patient_status`
  MODIFY `s_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `notification`
--
ALTER TABLE `notification`
  MODIFY `s_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=100;

--
-- AUTO_INCREMENT for table `notify`
--
ALTER TABLE `notify`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `patients`
--
ALTER TABLE `patients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=432;

--
-- AUTO_INCREMENT for table `patient_details_danesh`
--
ALTER TABLE `patient_details_danesh`
  MODIFY `s_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `patient_records`
--
ALTER TABLE `patient_records`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=130;

--
-- AUTO_INCREMENT for table `profiles`
--
ALTER TABLE `profiles`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `videos`
--
ALTER TABLE `videos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
